/* ============================================================ shared analytics: skills, features, pricing, segments, recommendations */
const TRAIN = [
  ['Workplace Communication Sprint', 'Live cohort + AI speaking coach'], ['Excel to Insights', 'Self-paced + graded projects'], ['Performance Marketing Bootcamp', 'Cohort + live ad-account project'],
  ['Financial Modelling Foundations', 'Self-paced + case assessments'], ['Python for Work', 'Project-based track + code reviews'], ['Applied AI for Every Role', 'Micro-credential: AI tools, prompting, automation'],
  ['Supply Chain & Logistics Ops', 'Employer-partner case work + simulation'], ['Sales Readiness Lab', 'Role-play with AI + field assignment'], ['Project Delivery Essentials', 'Agile/PM certification prep'],
  ['Business Analytics with SQL & Power BI', 'Project-based + portfolio'], ['First-time Manager Programme', 'Mentor-led cohort'], ['—', '—']];
function skillGap(ix) {
  const h = mfreq(D.q11, ix, 12), d = mfreq(D.q12, ix, 12); const gapN = new Array(12).fill(0);
  for (const i of ix) { if (D.q11[i] < 0) continue; const g = D.q12[i] & ~D.q11[i]; for (let b = 0; b < 12; b++) if (g >> b & 1) gapN[b]++; }
  return L.SKILLS.map((s, j) => ({ j, s, have: h.n ? h.c[j] / h.n : NaN, dem: d.n ? d.c[j] / d.n : NaN, haveN: h.c[j], demN: d.c[j], gapN: gapN[j], gap: h.n ? (d.c[j] - h.c[j]) / h.n * 100 : NaN, n: h.n }));
}
function gapBy(ix, col, k, base = 0) { // heatmap rows: skills x groups, value = gap pp
  const out = []; for (let g = 0; g < k; g++) { const s = sub(ix, i => D[col][i] === g + base); out.push({ g, n: s.length, sg: skillGap(s) }); } return out;
}
function featureStats(ix) {
  const q19 = mfreq(D.q19, ix, 9), q21 = freq(D.q21, ix, 7);
  const f19 = L.FEAT19.map((f, j) => { const p = q19.n ? q19.c[j] / q19.n : NaN; return { j, f, n: q19.c[j], p, cls: p >= .4 ? 'High' : p >= .3 ? 'Medium' : 'Low' }; });
  const f21 = L.FEAT21.map((f, j) => {
    const ch = sub(ix, i => D.q21[i] === j); const anyN = share(ix, i => FEAT_MAP[j].some(b => D.q19[i] >> b & 1));
    const pd = share(ch, i => isN(D.paid[i]) ? D.paid[i] : null), hard = share(ch, i => isN(D.diff[i]) ? D.diff[i] >= 4 : null);
    return { j, f, prim: ch.length, primP: q21.n ? ch.length / q21.n : NaN, intN: anyN.y, intP: anyN.p, paidP: pd.p, wtp: mean(D.wtp, ch), need: hard.p, top2: share(ch, i => isN(D.top2[i]) ? D.top2[i] : null).p };
  });
  const nz = (a, k) => { const v = a.map(x => x[k]).filter(isFinite), lo = Math.min(...v), hi = Math.max(...v); return x => hi > lo ? (x[k] - lo) / (hi - lo) : .5; };
  const a = nz(f21, 'intP'), b = nz(f21, 'primP'), c = nz(f21, 'paidP'), d = nz(f21, 'need');
  f21.forEach(x => { x.score = 100 * (.35 * a(x) + .3 * b(x) + .2 * c(x) + .15 * d(x)); x.cls = x.intP >= .4 ? 'High' : x.intP >= .3 ? 'Medium' : 'Low'; });
  return { f19, f21, n19: q19.n, n21: q21.n };
}
const WTP_RANGE = [[0, 0], [99, 199], [200, 499], [500, 999], [1000, 1999], [2000, 2999]];
function wtpStats(ix) {
  const f = freq(D.q22, ix, 6), n = f.n; const sh = f.c.map(c => n ? c / n : 0);
  const willing = p => sh.reduce((s, q, k) => { const [lo, hi] = WTP_RANGE[k]; const pr = p <= lo ? 1 : p > hi ? 0 : (hi - p) / Math.max(1, hi - lo); return s + q * pr; }, 0);
  const prices = [49, 99, 149, 199, 249, 299, 349, 399, 499, 599, 749, 999, 1249, 1499, 1999, 2499];
  const curve = prices.map(p => ({ p, d: willing(p), rev: p * willing(p) }));
  const best = curve.reduce((a, b) => b.rev > a.rev ? b : a, curve[0]);
  const payers = vals(D.wtp, ix).filter(v => v > 0).sort((a, b) => a - b);
  return { f, n, sh, paid: n ? 1 - sh[0] : NaN, curve, best, willing, medPayer: quant(payers, .5), meanAll: mean(D.wtp, ix) };
}
function segMetrics(ix, totN) {
  const n = ix.length, hard = share(ix, i => isN(D.diff[i]) ? D.diff[i] >= 4 : null).p, gf = share(ix, i => D.q14[i] >= 0 ? D.q14[i] === 0 : null).p,
    low = share(ix, i => isN(D.ready[i]) ? D.ready[i] <= 2 : null).p;
  const need = 100 * (.4 * (hard || 0) + .35 * (gf || 0) + .25 * (low || 0));
  return { n, share: totN ? n / totN : NaN, need, hard, gapFreq: gf, lowReady: low, gap: mean(D.gap, ix), ai: mean(D.ai, ix), interest: share(ix, i => isN(D.top2[i]) ? D.top2[i] : null).p,
    paid: share(ix, i => isN(D.paid[i]) ? D.paid[i] : null).p, wtp: mean(D.wtp, ix), nps: nps(ix).nps, prop: mean(D.prop, ix) };
}
const PERSONA_SOL = [
  'Neural Profile + AI resume builder and interview prep; free core with paid interview packs',
  'AI job matching with verified employers + salary benchmarking; priority applications as paid add-on',
  'Career-path guidance + personalised skill-gap roadmap tied to certification tracks',
  'Self-serve Neural Profile, salary estimation and premium job matching on subscription',
  'Mobile-first, vernacular career guidance; remote and regional job matching at the ₹99 tier',
  'Free tier funded by employer sponsorship or government skilling schemes; upsell later',
  'Paid learning roadmaps mapped to employer demand, with readiness score and placement tracking'];
const PERSONA_ACQ = ['College and university placement-cell partnerships', 'LinkedIn and job-fair outreach; referral bonuses', 'Content marketing on career change; LinkedIn',
  'Instagram / YouTube performance marketing', 'Regional-language WhatsApp communities; ITI and polytechnic tie-ups', 'Campus ambassadors; NGO and state skilling-mission partnerships', 'Retargeting high-intent sign-ups; webinars with employers'];
function personaTable(ix) {
  const tot = ix.length; return PERSONA.map((nm, k) => { const s = sub(ix, i => D.persona[i] >> k & 1); const m = segMetrics(s, tot), pr = profile(s); return { k, nm, ix: s, m, pr, rule: P.personas[k].rule, sol: PERSONA_SOL[k], acq: PERSONA_ACQ[k] }; });
}
function rankSegments(rows) { // rows with .m ; returns score using CFG.w
  const W = CFG.w, crit = [['need', r => r.m.need], ['size', r => r.m.share], ['interest', r => r.m.interest], ['wtp', r => r.m.wtp], ['feas', r => r.m.ai], ['evid', r => Math.sqrt(r.m.n)]];
  const ok = rows.filter(r => r.m.n >= CFG.minN);
  const nz = {}; crit.forEach(([k, f]) => { const v = ok.map(f).filter(isFinite); nz[k] = [Math.min(...v), Math.max(...v)]; });
  const sw = Object.values(W).reduce((a, b) => a + +b, 0) || 1;
  rows.forEach(r => { r.sc = {}; let t = 0; crit.forEach(([k, f]) => { const [lo, hi] = nz[k]; const s = hi > lo ? 100 * (f(r) - lo) / (hi - lo) : 50; r.sc[k] = isFinite(s) ? Math.max(0, Math.min(100, s)) : 0; t += r.sc[k] * W[k]; }); r.score = r.m.n >= CFG.minN ? t / sw : NaN; });
  return rows.slice().sort((a, b) => (isFinite(b.score) ? b.score : -1) - (isFinite(a.score) ? a.score : -1));
}
function cityTable(ix) {
  const tot = ix.length; return L.CITY.map((c, k) => { const s = sub(ix, i => D.q3[i] === k); return { k, nm: c, tier: L.TIER[P.tierOfCity[k]], ix: s, m: segMetrics(s, tot) }; });
}

/* ---- Data-to-Decision engine */
function recommendations(ix) {
  const tot = ix.length; if (tot < 30) return [];
  const all = segMetrics(ix, tot), recs = [];
  const evid = n => Math.round(100 * Math.min(1, Math.sqrt(n / 1000)));
  const mk = (o, m) => { o.m = m; o.n = m.n; o.pct = m.share; o.sc = { need: m.need, size: Math.min(100, m.share * 200), interest: 100 * (m.interest || 0), wtp: 100 * (m.paid || 0), feas: o.feas, evid: evid(m.n) };
    o.ev = evidence(m.n); recs.push(o); };
  const pers = rankSegments(personaTable(ix)); const top = pers[0];
  if (top && isFinite(top.score)) mk({ key: 'target', type: 'Target segment', title: `Launch with ${top.nm}`, segment: top.nm, feas: 70,
    finding: `${top.nm} are ${pct(top.m.share)} of the view. ${pct(top.m.interest)} would definitely or probably use JobSaathi and ${pct(top.m.paid)} state a willingness to pay ₹99+/month.`,
    interp: `Need index ${f1(top.m.need, 0)} vs ${f1(all.need, 0)} overall: this group combines a hard job search with stated purchase intent.`,
    opp: `A focused offer (${PERSONA_SOL[top.k].split(';')[0].toLowerCase()}) can be tested on a group large enough to read results quickly.`,
    action: `Run an 8-week paid pilot for ${top.nm}: ${PERSONA_SOL[top.k]}. Acquire via ${PERSONA_ACQ[top.k].toLowerCase()}.`,
    measure: 'Activation rate, profile completion, week-4 retention, trial-to-paid conversion vs stated WTP.',
    limit: 'Segment rules overlap; stated intent and WTP usually overstate real behaviour.' }, top.m);
  const fs = featureStats(ix); const ff = fs.f21.slice().sort((a, b) => b.score - a.score); const f0 = ff[0];
  mk({ key: 'feature', type: 'Product priority', title: `Build ${f0.f} first`, segment: 'Respondents choosing it as most valuable', feas: 65,
    finding: `${f0.f} ranks #1 on the feature priority score (${f1(f0.score, 0)}/100). ${pct(f0.primP)} pick it as the single most valuable feature; ${pct(f0.intP)} want the matching AI capability in Q19.`,
    interp: `Among those who chose it, ${pct(f0.paidP)} would pay and ${pct(f0.need)} report a hard job search.`,
    opp: 'An MVP built around one high-demand capability reduces build cost and sharpens positioning.',
    action: `Ship ${f0.f} as the MVP hero feature; keep ${ff[1].f} and ${ff[2].f} on the 90-day roadmap.`,
    measure: 'Feature usage per active user, repeat use within 14 days, contribution to paid conversion.', limit: 'Survey preference, not observed usage. Validate with a clickable prototype test.' },
    segMetrics(sub(ix, i => D.q21[i] === f0.j), tot));
  const sg = skillGap(ix).filter(x => x.j < 11).sort((a, b) => b.gap - a.gap); const g3 = sg.slice(0, 3);
  const gix = sub(ix, i => D.q11[i] >= 0 && g3.some(g => (D.q12[i] & ~D.q11[i]) >> g.j & 1));
  mk({ key: 'skills', type: 'Training focus', title: `Build learning tracks for ${g3.map(g => g.s).join(', ')}`, segment: 'Respondents missing one of these skills', feas: 75,
    finding: `Largest perceived gaps: ${g3.map(g => `${g.s} ${pp(g.gap)}`).join(' · ')}. ${fmtN(gix.length)} respondents (${pct(gix.length / tot)}) believe employers want at least one of these but do not have it.`,
    interp: 'Respondents see a clear distance between their skills and what they think employers want.',
    opp: 'Demand-led training programmes that end in an assessment and a readiness score.',
    action: `Launch ${g3.map(g => TRAIN[g.j][0]).join(', ')} as the first three JobSaathi tracks.`,
    measure: 'Enrolment, completion, assessment pass rate, readiness-score lift, interview rate after completion.',
    limit: 'Employer demand here is respondent-perceived, not an employer survey. Confirm with partner employers.' }, segMetrics(gix, tot));
  const cities = cityTable(ix).filter(c => c.m.n >= CFG.minN).map(c => ({ ...c, opp: c.m.n * (c.m.need / 100) * (c.m.interest || 0) })).sort((a, b) => b.opp - a.opp);
  if (cities.length) { const c3 = cities.slice(0, 3); const cix = sub(ix, i => c3.some(c => c.k === D.q3[i]));
    mk({ key: 'city', type: 'Go-to-market', title: `Concentrate launch marketing on ${c3.map(c => c.nm).join(', ')}`, segment: c3.map(c => c.nm).join(', '), feas: 60,
      finding: `These locations combine the most respondents with need and intent: ${c3.map(c => `${c.nm} (n=${fmtN(c.m.n)}, intent ${pct(c.m.interest, 0)})`).join(', ')}.`,
      interp: 'In-sample concentration × need × intent. This is respondent concentration, not market size.',
      opp: 'Local employer partnerships and campus tie-ups work better when concentrated in a few cities.',
      action: 'Sign 10–15 hiring partners per launch city before paid acquisition; run city-specific campaigns.',
      measure: 'Cost per sign-up by city, partner job postings, placements per city.', limit: 'The survey sample is not a census; city weights are synthetic assumptions.' }, segMetrics(cix, tot)); }
  const w = wtpStats(ix); const entry = sub(ix, i => D.q22[i] === 1);
  mk({ key: 'price', type: 'Pricing', title: 'Set the first paid tier in the ₹99–₹199 band', segment: 'All respondents in view (pricing applies to everyone)', feas: 85,
    finding: `${pct(w.sh[1])} choose ₹99–₹199, the most common paid answer; ${pct(w.paid)} accept any paid price. The revenue-maximising stated price is about ${inr(w.best.p)} (${pct(w.best.d)} willing).`,
    interp: 'Demand drops steeply above ₹499; a low entry price captures most stated payers.',
    opp: 'Freemium with a ₹149 entry plan, plus higher-priced add-ons for those who signal more.',
    action: 'Price the core plan at ₹149/month (₹1,499/year); test ₹199 and ₹249 variants in an A/B pricing page.',
    measure: 'Checkout conversion by price variant, refund rate, ARPU, month-2 retention.', limit: `Stated WTP is not purchasing behaviour; the dashboard applies a configurable discount in projections. ${fmtN(entry.length)} respondents chose ₹99–₹199.` }, segMetrics(ix, tot));
  const free = pers.filter(p => p.m.n >= CFG.minN).sort((a, b) => (b.m.need - b.m.paid * 100) - (a.m.need - a.m.paid * 100))[0];
  if (free) mk({ key: 'free', type: 'Free onboarding', title: `Offer free onboarding to ${free.nm}`, segment: free.nm, feas: 80,
    finding: `${free.nm}: need index ${f1(free.m.need, 0)}, but only ${pct(free.m.paid)} would pay. Intent to use is ${pct(free.m.interest)}.`,
    interp: 'High need with low ability to pay; charging upfront would block adoption.', opp: 'A free tier builds the candidate pool employers pay to access.',
    action: 'Make Neural Profile, readiness score and basic job matching free; monetise via employer-side fees and sponsored training.',
    measure: 'Free sign-ups, profile completion, employer-side revenue per active candidate.', limit: 'Employer willingness to pay is not measured in this survey.' }, free.m);
  const pf = fs.f21.filter(x => x.prim >= CFG.minN).sort((a, b) => b.paidP - a.paidP).slice(0, 2);
  if (pf.length) mk({ key: 'paidfeat', type: 'Monetisation', title: `Put ${pf.map(x => x.f).join(' and ')} behind the subscription`, segment: 'Choosers of these features', feas: 70,
    finding: pf.map(x => `${x.f}: ${pct(x.paidP)} of its ${fmtN(x.prim)} choosers would pay (avg stated ${inr(x.wtp)}/month)`).join('; ') + '.',
    interp: 'These features attract respondents with the highest paid intent.', opp: 'Premium features that justify a subscription without blocking free onboarding.',
    action: 'Gate advanced versions (unlimited, personalised, human review) behind the paid plan; keep a basic version free.',
    measure: 'Paywall view-to-upgrade rate by feature.', limit: 'Feature choice and WTP are both self-reported.' }, segMetrics(sub(ix, i => pf.some(x => x.j === D.q21[i])), tot));
  const low = sub(ix, i => isN(D.trust[i]) && D.trust[i] <= 2); const tf = freq(D.q23, ix, 8); const t1 = argmax(tf.c), t2 = argmax(tf.c.map((v, j) => j === t1 ? -1 : v));
  mk({ key: 'trust', type: 'Adoption barrier', title: `Lead with proof: ${L.TRUST[t1].toLowerCase()} and ${L.TRUST[t2].toLowerCase()}`, segment: 'Low-trust respondents (AI trust 1–2)', feas: 60,
    finding: `${pct(low.length / tot)} rate their trust in AI career recommendations at 1–2. Top trust builders: ${L.TRUST[t1]} (${pct(tf.c[t1] / tf.n)}), ${L.TRUST[t2]} (${pct(tf.c[t2] / tf.n)}).`,
    interp: 'Trust, not awareness, is the gating factor for a large minority.', opp: 'Verified outcomes become the core marketing asset.',
    action: 'Publish audited placement numbers, badge verified employers, and show how each skill score is calculated.',
    measure: 'Sign-up conversion on pages with and without proof elements; trust score in onboarding survey.', limit: 'Trust drivers are a single-choice question; secondary drivers are not captured.' }, segMetrics(low, tot));
  const aiLow = sub(ix, i => D.aiReady[i] === 0);
  mk({ key: 'ai', type: 'Adoption barrier', title: 'Add a human-assisted path for low-AI-familiarity users', segment: 'AI Adoption Index < 40', feas: 55,
    finding: `${fmtN(aiLow.length)} respondents (${pct(aiLow.length / tot)}) score below 40 on the AI Adoption Index; their intent to use is ${pct(segMetrics(aiLow, tot).interest)}.`,
    interp: 'A purely AI experience may lose experienced and less digital users.', opp: 'Hybrid human + AI counselling as a premium or partner-led service.',
    action: 'Offer a 20-minute human counselling call in onboarding for low-familiarity users; explain AI outputs in plain language.',
    measure: 'Onboarding completion for low-familiarity users vs others; counsellor cost per activated user.', limit: 'The index weights are an analyst assumption (editable in Settings).' }, segMetrics(aiLow, tot));
  const bh = sub(ix, i => D.q8[i] >= 3 && D.q9[i] === 0 && !(D.flags[i] & 2));
  if (bh.length >= 20) mk({ key: 'apps', type: 'Product priority', title: 'Fix the application black hole with resume and ATS tools', segment: '11+ applications, zero interviews', feas: 75,
    finding: `${fmtN(bh.length)} respondents (${pct(bh.length / tot)}) sent 11+ applications in three months and received no interview.`,
    interp: 'More applications do not translate into interviews; application quality is a bottleneck.', opp: 'AI resume builder, ATS check and application assistance as a paid add-on.',
    action: 'Bundle AI resume builder + ATS score + tailored applications into an "Interview Booster" pack.', measure: 'Interview rate per 10 applications before vs after use.',
    limit: 'Application and interview counts are banded self-reports.' }, segMetrics(bh, tot));
  const W = CFG.w, sw = Object.values(W).reduce((a, b) => a + +b, 0) || 1;
  recs.forEach(r => r.total = Object.keys(W).reduce((s, k) => s + (r.sc[k] || 0) * W[k], 0) / sw);
  return recs.sort((a, b) => b.total - a.total);
}
