/* ============================================================ ML engines in the browser */
function rng32(seed) { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
function clusterName(z) {
  const T = [[(z[0] - z[1] - z[2]) / 3, ['Struggling', 'strugglers'], ['Job-ready', 'achievers']], [z[4], ['AI-ready', 'AI adopters'], ['AI-hesitant', 'AI sceptics']], [z[5], ['High-intent', 'enthusiasts'], ['Disengaged', 'sceptics']],
    [z[6], ['Paying', 'payers'], ['Free-only', 'free-seekers']], [z[7], ['Experienced', 'veterans'], ['Early-career', 'early-careerists']], [z[3], ['Gap-aware', 'gap-spotters'], ['Well-matched', 'matched talent']], [z[8], ['Committed', 'long-haul learners'], ['Quick-fix', 'quick learners']]];
  const o = T.map(([v, p, n]) => ({ v, w: v >= 0 ? p : n })).sort((a, b) => Math.abs(b.v) - Math.abs(a.v));
  const s = o[1].w[0] + ' ' + o[0].w[1]; return s.charAt(0).toUpperCase() + s.slice(1);
}
function kmeansRun(ix, k, seed = 7, nInit = 3, maxIt = 60) {
  const n = ix.length, d = KMD; let best = null;
  for (let r = 0; r < nInit; r++) {
    const rnd = rng32(seed * 7919 + r * 104729 + k), C = new Float64Array(k * d), dist = new Float64Array(n).fill(Infinity);
    let f = ix[Math.floor(rnd() * n)]; for (let j = 0; j < d; j++) C[j] = KMZ[f * d + j];
    for (let c = 1; c < k; c++) { let tot = 0; for (let a = 0; a < n; a++) { const i = ix[a]; let s = 0; for (let j = 0; j < d; j++) { const t = KMZ[i * d + j] - C[(c - 1) * d + j]; s += t * t; } if (s < dist[a]) dist[a] = s; tot += dist[a]; }
      let u = rnd() * tot, a = 0; for (; a < n - 1; a++) { u -= dist[a]; if (u <= 0) break; } for (let j = 0; j < d; j++) C[c * d + j] = KMZ[ix[a] * d + j]; }
    const lab = new Int8Array(n); let wcss = 0;
    for (let it = 0; it < maxIt; it++) { let moved = 0; wcss = 0; const S = new Float64Array(k * d), cnt = new Int32Array(k);
      for (let a = 0; a < n; a++) { const i = ix[a]; let bd = Infinity, bc = 0; for (let c = 0; c < k; c++) { let s = 0; for (let j = 0; j < d; j++) { const t = KMZ[i * d + j] - C[c * d + j]; s += t * t; } if (s < bd) { bd = s; bc = c; } }
        if (lab[a] !== bc || it === 0) { moved++; lab[a] = bc; } wcss += bd; cnt[bc]++; for (let j = 0; j < d; j++) S[bc * d + j] += KMZ[i * d + j]; }
      for (let c = 0; c < k; c++) if (cnt[c]) for (let j = 0; j < d; j++) C[c * d + j] = S[c * d + j] / cnt[c];
      if (!moved && it) break; if (moved === 0) break; }
    if (!best || wcss < best.wcss) best = { lab: Int8Array.from(lab), C: Float64Array.from(C), wcss };
  }
  const cnt = new Array(k).fill(0); best.lab.forEach(l => cnt[l]++); const ord = cnt.map((v, c) => [v, c]).sort((a, b) => b[0] - a[0]).map(x => x[1]); const rm = new Int8Array(k); ord.forEach((c, r) => rm[c] = r);
  return { lab: best.lab.map(l => rm[l]), C: ord.map(c => Array.from(best.C.slice(c * d, c * d + d))), wcss: best.wcss, k, sizes: ord.map(c => cnt[c]) };
}
function silhouette(ix, lab, k, m = 600) { const n = ix.length, rnd = rng32(99), pick = []; for (let a = 0; a < Math.min(m, n); a++) pick.push(Math.floor(rnd() * n)); let tot = 0, cnt = 0;
  for (const a of pick) { const i = ix[a], sums = new Float64Array(k), ns = new Int32Array(k); for (const b of pick) { if (a === b) continue; const j = ix[b]; let s = 0; for (let t = 0; t < KMD; t++) { const q = KMZ[i * KMD + t] - KMZ[j * KMD + t]; s += q * q; } sums[lab[b]] += Math.sqrt(s); ns[lab[b]]++; }
    const own = lab[a], A = ns[own] ? sums[own] / ns[own] : 0; let B = Infinity; for (let c = 0; c < k; c++) if (c !== own && ns[c]) B = Math.min(B, sums[c] / ns[c]); if (isFinite(B)) { tot += (B - A) / Math.max(A, B); cnt++; } }
  return cnt ? tot / cnt : NaN; }
// association rules
function arUniverse(u) {
  if (u === 'q19') return { items: L.FEAT19, tx: i => D.q19[i] };
  if (u === 'q11') return { items: L.SKILLS.slice(0, 11).map(s => 'Has ' + s), tx: i => D.q11[i] < 0 ? -1 : D.q11[i] & 2047 };
  if (u === 'gap') return { items: L.SKILLS.slice(0, 11).map(s => 'Lacks ' + s), tx: i => D.q11[i] < 0 ? -1 : (D.q12[i] & ~D.q11[i]) & 2047 };
  const items = [...L.STATUS.map(s => 'Status: ' + s), ...L.TIER.map(t => 'Tier: ' + t), 'AI-ready', 'Would pay ₹99+', 'Definitely would use', ...L.FEAT19.map(f => '⇒ ' + f)];
  return { items, cons: 13, tx: i => { let m = 0; if (D.q4[i] >= 0) m |= 1 << D.q4[i]; if (D.tier[i] >= 0) m |= 1 << (7 + D.tier[i]); if (D.aiReady[i] === 2) m |= 1 << 10; if (D.paid[i] === 1) m |= 1 << 11; if (D.q20[i] === 0) m |= 1 << 12; return m | (D.q19[i] << 13); } };
}
function assocRules(u, ix, minSup = .05, minConf = .3, maxLen = 3) {
  const U = arUniverse(u), K = U.items.length, T = []; for (const i of ix) { const t = U.tx(i); if (t >= 0) T.push(t); } const n = T.length; if (!n) return [];
  const cnt = m => { let c = 0; for (const t of T) if ((t & m) === m) c++; return c; };
  const one = []; for (let a = 0; a < K; a++) { const c = cnt(1 << a); if (c / n >= minSup) one.push(a); }
  const sup = new Map(); one.forEach(a => sup.set(1 << a, cnt(1 << a)));
  const sets = [];
  for (let x = 0; x < one.length; x++) for (let y = x + 1; y < one.length; y++) { const m = (1 << one[x]) | (1 << one[y]); const c = cnt(m); if (c / n >= minSup) { sup.set(m, c); sets.push([one[x], one[y]]); } }
  if (maxLen >= 3) { const pairs = sets.slice(); for (const [a, b] of pairs) for (const z of one) if (z > b) { const m = (1 << a) | (1 << b) | (1 << z); if (!sup.has((1 << a) | (1 << z)) || !sup.has((1 << b) | (1 << z))) continue; const c = cnt(m); if (c / n >= minSup) { sup.set(m, c); sets.push([a, b, z]); } } }
  const out = []; const g = m => sup.has(m) ? sup.get(m) : cnt(m);
  for (const s of sets) { const full = s.reduce((m, a) => m | 1 << a, 0), cAB = sup.get(full);
    for (const b of s) { if (U.cons !== undefined && b < U.cons) continue; const A = s.filter(x => x !== b); if (U.cons !== undefined && A.some(a => a >= U.cons)) continue;
      const mA = A.reduce((m, a) => m | 1 << a, 0), cA = g(mA), cB = g(1 << b), conf = cAB / cA; if (conf < minConf) continue;
      out.push({ A: A.map(a => U.items[a]).join(' + '), B: U.items[b], sup: cAB / n, conf, lift: conf / (cB / n), nAB: cAB, nA: cA, nB: cB, n }); } }
  return out;
}
// regression
const REG_F = ['Job-search difficulty', 'Job confidence', 'Industry readiness', 'Skill gaps (count)', 'AI familiarity', 'AI tool usage', 'AI trust', 'Platform intent', 'Features wanted (count)', 'Learning commitment (mo)', 'Experience (yrs)', 'Age band', 'Education level', 'Metro city', 'Stated WTP (log ₹)'];
const EDU_ORD = [0, 1, 2, 3, 4, 3, 1];
function regX(i) { return [D.diff[i], D.conf[i], D.ready[i], D.gap[i], D.fam[i], D.use[i], D.trust[i], D.intent[i], pop(D.q19[i]), D.learn[i], D.expY[i], D.q1[i] >= 0 ? D.q1[i] : NaN, D.q2[i] >= 0 ? EDU_ORD[D.q2[i]] : NaN, D.tier[i] === 0 ? 1 : D.tier[i] > 0 ? 0 : NaN, isN(D.wtp[i]) ? Math.log1p(D.wtp[i]) : NaN]; }
const isTrain = i => ((Math.imul(i + 1, 2654435761) >>> 0) % 100) < 70;
function solve(A, b) { const n = b.length, M = A.map((r, i) => [...r, b[i]]); for (let c = 0; c < n; c++) { let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r; [M[c], M[p]] = [M[p], M[c]]; const v = M[c][c] || 1e-12; for (let r = 0; r < n; r++) if (r !== c) { const f = M[r][c] / v; for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k]; } } return M.map((r, i) => r[n] / (r[i] || 1e-12)); }
function inv(A) { const n = A.length; return Array.from({ length: n }, (_, j) => solve(A, Array.from({ length: n }, (_, i) => i === j ? 1 : 0))).reduce((acc, col, j) => { col.forEach((v, i) => { acc[i][j] = v; }); return acc; }, Array.from({ length: n }, () => new Array(n).fill(0))); }
function regData(target, ix, drop = []) {
  const ys = target === 'rec' ? D.rec : D.sal; const rows = [], y = [], tr = [];
  for (const i of ix) { const v = ys[i]; if (!isN(v)) continue; rows.push(regX(i)); y.push(target === 'sal' ? Math.log(v) : v); tr.push(isTrain(i)); }
  const p = REG_F.length, med = Array.from({ length: p }, (_, j) => quant(rows.map(r => r[j]).filter(isN).sort((a, b) => a - b), .5));
  rows.forEach(r => r.forEach((v, j) => { if (!isN(v)) r[j] = med[j]; }));
  const trI = tr.map((t, k) => t ? k : -1).filter(k => k >= 0), teI = tr.map((t, k) => !t ? k : -1).filter(k => k >= 0);
  const mu = Array.from({ length: p }, (_, j) => trI.reduce((s, k) => s + rows[k][j], 0) / trI.length), sd = mu.map((m, j) => Math.sqrt(trI.reduce((s, k) => s + (rows[k][j] - m) ** 2, 0) / trI.length) || 1);
  const Z = rows.map(r => r.map((v, j) => (v - mu[j]) / sd[j])); const ym = trI.reduce((s, k) => s + y[k], 0) / trI.length;
  return { Z, y, trI, teI, ym, p, n: rows.length };
}
function regFit(target, method, alpha, ix, R = null) {
  R = R || regData(target, ix); const { Z, y, trI, teI, ym, p } = R; if (trI.length < p + 5) return null; const n = trI.length;
  let beta;
  if (method === 'lasso') { beta = new Array(p).fill(0); const r = trI.map(k => y[k] - ym); const xs = Array.from({ length: p }, (_, j) => trI.reduce((s, k) => s + Z[k][j] ** 2, 0) / n);
    for (let it = 0; it < 300; it++) { let mx = 0; for (let j = 0; j < p; j++) { let rho = 0; trI.forEach((k, a) => rho += Z[k][j] * (r[a] + Z[k][j] * beta[j])); rho /= n;
      const nb = Math.sign(rho) * Math.max(0, Math.abs(rho) - alpha) / xs[j]; const d = nb - beta[j]; if (d) { trI.forEach((k, a) => r[a] -= Z[k][j] * d); beta[j] = nb; mx = Math.max(mx, Math.abs(d)); } } if (mx < 1e-6) break; } }
  else { const A = Array.from({ length: p }, (_, a) => Array.from({ length: p }, (_, b) => trI.reduce((s, k) => s + Z[k][a] * Z[k][b], 0) + (a === b && method === 'ridge' ? alpha : 0))); const bv = Array.from({ length: p }, (_, a) => trI.reduce((s, k) => s + Z[k][a] * (y[k] - ym), 0)); beta = solve(A, bv); }
  const pred = k => ym + Z[k].reduce((s, v, j) => s + v * beta[j], 0);
  const r2 = I => { const m = I.reduce((s, k) => s + y[k], 0) / I.length; let ss = 0, st = 0; I.forEach(k => { ss += (y[k] - pred(k)) ** 2; st += (y[k] - m) ** 2; }); return { r2: 1 - ss / st, rmse: Math.sqrt(ss / I.length) }; };
  const a = r2(trI), b = teI.length > 10 ? r2(teI) : { r2: NaN, rmse: NaN };
  let se = null; if (method === 'ols') { const XtX = Array.from({ length: p }, (_, u) => Array.from({ length: p }, (_, v) => trI.reduce((s, k) => s + Z[k][u] * Z[k][v], 0))); const Iv = inv(XtX); const s2 = trI.reduce((s, k) => s + (y[k] - pred(k)) ** 2, 0) / (n - p - 1); se = Iv.map((r, j) => Math.sqrt(s2 * r[j])); }
  return { coef: beta, r2tr: a.r2, r2te: b.r2, rmseTr: a.rmse, rmseTe: b.rmse, ntr: n, nte: teI.length, nz: beta.filter(v => Math.abs(v) > 1e-6).length, se, R };
}
// classifier helpers
const TEST = P.test, YT = P.ytest;
function roc(scores) { const o = scores.map((s, j) => [s, YT[j]]).sort((a, b) => b[0] - a[0]); const Pn = YT.reduce((a, b) => a + b, 0), Nn = YT.length - Pn; let tp = 0, fp = 0, auc = 0, pf = 0, pt = 0; const pts = [[0, 0]];
  for (let k = 0; k < o.length; k++) { if (o[k][1]) tp++; else fp++; if (k === o.length - 1 || o[k + 1][0] !== o[k][0]) { const x = fp / Nn, y = tp / Pn; auc += (x - pf) * (y + pt) / 2; pf = x; pt = y; pts.push([x, y]); } } return { pts, auc }; }
function confusion(scores, thr) { let tp = 0, fp = 0, tn = 0, fn = 0; scores.forEach((s, j) => { const pr = s >= thr; if (pr && YT[j]) tp++; else if (pr) fp++; else if (YT[j]) fn++; else tn++; }); const n = tp + fp + tn + fn;
  const prec = tp / Math.max(1, tp + fp), rec = tp / Math.max(1, tp + fn); return { tp, fp, tn, fn, acc: (tp + tn) / n, prec, rec, f1: prec + rec ? 2 * prec * rec / (prec + rec) : 0, fpr: fp / Math.max(1, fp + tn) }; }
const RFV = b64(P.rfVotes), RF_T = P.rfShape[0], RF_NB = Math.ceil(P.rfShape[1] / 8);
const rfVote = (t, j) => (RFV[t * RF_NB + (j >> 3)] >> (7 - (j & 7))) & 1;
const TEST_POS = new Map(TEST.map((i, j) => [i, j]));
const TRAIN_IX = (() => { const o = []; for (let i = 0; i < N; i++) if (P.split[i] === 0) o.push(i); return o; })();
const YALL = i => D.paid[i];
function knnLookup(i, K) { const d = []; for (const t of TRAIN_IX) { if (t === i) continue; let s = 0; for (let j = 0; j < CLD; j++) { const q = CLZ[i * CLD + j] - CLZ[t * CLD + j]; s += q * q; } d.push([Math.sqrt(s), t]); } d.sort((a, b) => a[0] - b[0]); return d.slice(0, K); }
function rawFeat(i, j) { return CLZ[i * CLD + j] * P.clfSd[j] + P.clfMu[j]; }
function treePath(i) { const path = []; let nd = P.tree; while (nd) { path.push(nd.id); if (nd.f === undefined) break; nd = rawFeat(i, nd.f) <= nd.thr ? nd.l : nd.r; } return path; }
const BIN = new Set([2, 3, 4, 5, 6, 7, 8, 9, 10]);
function splitText(nd) { const f = P.clfF[nd.f]; if (BIN.has(nd.f)) return `${f}?`; return `${f} ≤ ${f1(nd.thr, 1)}?`; }
function resolveId(s) { s = String(s || '').trim().toUpperCase(); const m = s.match(/(\d+)/); if (!m) return -1; const k = +m[1] - 1; return k >= 0 && k < N ? k : -1; }

/* ============================================================ LAB · Model Lab */
let LAB = { tab: 'clf', model: 'gb', thr: 50, algo: 'knn', knnK: P.bestK > 51 ? 25 : P.bestK, rid: '', trees: 25, poll: 0, rounds: P.gbBest, regT: 'rec', regM: 'ridge', regA: 1, km: null, kmK: P.kmK, kmLive: false, lcaId: '', ar: 'q19', arS: 6, arC: 40, arL: 1.05, arA: 'Has Communication', arB: '' };
page('lab', 'LAB', 'Model Lab', 'Model Lab · Machine-Learning Frameworks', 'Every framework from the course guide, trained on this survey: classification, scoring, clustering, association rules and regression.', 'prove', c => {
  c.insertAdjacentHTML('beforeend', `<nav class="tabs" role="tablist">${[['clf', 'Classification: who will pay?'], ['reg', 'Regression: Linear · Ridge · Lasso'], ['clu', 'Clustering: K-Means · Latent Class'], ['ar', 'Association rules']].map(([k, l]) => `<button data-t="${k}" aria-pressed="${LAB.tab === k}">${l}</button>`).join('')}</nav>`);
  $$('.tabs button', c).forEach(b => b.onclick = () => { LAB.tab = b.dataset.t; render(true); });
  ({ clf: labClf, reg: labReg, clu: labClu, ar: labAR })[LAB.tab](c);
});
function labClf(c) {
  const nTr = TRAIN_IX.length, base = YT.reduce((a, b) => a + b, 0) / YT.length;
  c.insertAdjacentHTML('beforeend', `<div class="s12 note info"><b>Supervised classification.</b> Target = stated willingness to pay ₹99+/month (Q22, label 1) vs free only (0). ${P.clfF.length} input features from the other answers, median-imputed. Stratified 70/30 split: ${fmtN(nTr)} train · ${fmtN(TEST.length)} test (base rate ${pct(base)}). Trained offline with scikit-learn; test-set scores are embedded so every metric below is recalculated live. Models use the full sample, not the filter view.</div>`);
  const rocs = Object.fromEntries(Object.keys(P.scores).map(k => [k, roc(P.scores[k].map(v => v / 1000))])); const names = Object.fromEntries(P.cmp.map(m => [m.key, m.name])); const keys = ['knn', 'dt', 'rf', 'gb'];
  panel({ parent: c, span: 7, title: 'Model comparison on the held-out test set', sub: 'Threshold 0.5 · a large train-minus-test AUC gap signals overfitting', prov: 'model',
    html: `<div class="tw">${tableHTML(['Model', 'Accuracy', 'Precision', 'Recall', 'F1', 'Test AUC', 'Train AUC', 'Gap'], P.cmp.map(m => [`<b>${esc(m.name)}</b>`, pct(m.acc), pct(m.prec), pct(m.rec), pct(m.f1), f1(m.auc, 3), f1(m.train_auc, 3), `${f1(m.train_auc - m.auc, 3)} ${m.train_auc - m.auc > .1 ? '<span class="pill limited">overfit</span>' : ''}`]))}</div>
    <p class="muted" style="font-size:12px;margin:8px 0 0">AUC 0.70–0.80 = acceptable, 0.80–0.90 = good (guide's scale). Survey answers explain only part of stated WTP, so moderate AUC is expected.</p>` });
  cpanel({ parent: c, span: 5, title: 'ROC curves', sub: 'True positive rate (y) vs false positive rate (x) across all thresholds', prov: 'model', h: 'tall',
    opt: () => ({ legend: { top: 0, icon: 'circle', itemWidth: 9, textStyle: { color: TC['ink-2'], fontSize: 10.5 } }, grid: { left: 8, right: 14, top: 52, bottom: 22, containLabel: true }, tooltip: { trigger: 'item', formatter: p => `${p.seriesName}<br>FPR ${f1(p.value[0], 2)} · TPR ${f1(p.value[1], 2)}` },
      xAxis: valAx({ min: 0, max: 1, name: 'False positive rate', nameLocation: 'middle', nameGap: 22, nameTextStyle: { color: TC.muted } }), yAxis: valAx({ min: 0, max: 1 }),
      series: [...keys.map((k, j) => ({ name: `${names[k].split(' (')[0]} · AUC ${f1(rocs[k].auc, 3)}`, type: 'line', showSymbol: false, data: rocs[k].pts.filter((_, q) => q % 4 === 0 || q === rocs[k].pts.length - 1), lineStyle: { width: 2, color: TC.cat[j] }, itemStyle: { color: TC.cat[j] } })),
        { name: 'Coin flip', type: 'line', data: [[0, 0], [1, 1]], showSymbol: false, lineStyle: { color: TC.muted, width: 1 }, itemStyle: { color: TC.muted }, silent: true }] }),
    table: () => ({ head: ['Model', 'AUC (recomputed)'], rows: keys.map(k => [names[k], f1(rocs[k].auc, 4)]) }) });
  // threshold lab
  const sc = P.scores[LAB.model].map(v => v / 1000), cm = confusion(sc, LAB.thr / 100);
  const tp = panel({ parent: c, span: 12, title: 'Threshold lab', sub: 'Everyone scoring above the threshold is flagged as a likely payer. Confusion matrix, metrics and ROC point move together.', prov: 'model',
    html: `<div class="flex" style="margin-bottom:10px"><div class="seg" id="tlm">${keys.map(k => `<button data-m="${k}" aria-pressed="${LAB.model === k}">${names[k].split(' (')[0]}</button>`).join('')}</div>
      <div class="ctl" style="flex:1;min-width:220px"><label for="thr">Flagging threshold <output id="thrO">${(LAB.thr / 100).toFixed(2)}</output></label><input type="range" id="thr" min="1" max="99" value="${LAB.thr}"></div>
      <button class="btn sm" data-g="rec">Max recall (≥ 95%)</button><button class="btn sm" data-g="prec">Max precision (≥ 85%)</button><button class="btn sm" data-g="f1">Best F1</button></div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px"><div><div class="cm" id="cmx"></div></div><div class="stack"><div class="metric-row" id="mrow"></div><div class="note info" id="biz"></div></div><div class="chart short" id="rocDot"></div></div>` });
  const rc = rocs[LAB.model];
  const dotC = mount($('#rocDot', tp), { grid: { left: 8, right: 10, top: 10, bottom: 8, containLabel: true }, xAxis: valAx({ min: 0, max: 1 }), yAxis: valAx({ min: 0, max: 1 }), tooltip: { show: false },
    series: [{ type: 'line', showSymbol: false, data: rc.pts.filter((_, q) => q % 3 === 0), lineStyle: { color: TC.c1, width: 2 }, areaStyle: { color: TC.c1, opacity: .07 } }, { type: 'scatter', symbolSize: 14, data: [[cm.fpr, cm.rec]], itemStyle: { color: TC.c2, borderColor: TC.panel, borderWidth: 2 } }] });
  const upd = () => { const m = confusion(sc, LAB.thr / 100);
    $('#cmx', tp).innerHTML = `<div class="h"></div><div class="h">Predicted pay</div><div class="h">Predicted free</div><div class="h">Actually pays</div><div class="tp"><b>${fmtN(m.tp)}</b>True positive</div><div class="fn"><b>${fmtN(m.fn)}</b>False negative · missed</div><div class="h">Actually free</div><div class="fp"><b>${fmtN(m.fp)}</b>False positive · false alarm</div><div class="tn"><b>${fmtN(m.tn)}</b>True negative</div>`;
    $('#mrow', tp).innerHTML = [['Accuracy', m.acc], ['Precision', m.prec], ['Recall', m.rec], ['F1', m.f1]].map(([l, v]) => `<div><b>${pct(v)}</b><span>${l}</span></div>`).join('');
    $('#biz', tp).innerHTML = `If JobSaathi sent a paid-trial offer to the <b>${fmtN(m.tp + m.fp)}</b> flagged test respondents, <b>${fmtN(m.tp)}</b> (${pct(m.prec, 0)}) would be stated payers and <b>${fmtN(m.fn)}</b> stated payers would be missed. AUC ${f1(rc.auc, 3)} is threshold-independent.`;
    $('#thrO', tp).textContent = (LAB.thr / 100).toFixed(2); dotC.setOption({ series: [{}, { data: [[m.fpr, m.rec]] }] }); };
  upd(); $('#thr', tp).oninput = e => { LAB.thr = +e.target.value; upd(); };
  $$('#tlm button', tp).forEach(b => b.onclick = () => { LAB.model = b.dataset.m; render(true); });
  $$('[data-g]', tp).forEach(b => b.onclick = () => { let best = LAB.thr, bv = -1; for (let t = 1; t < 100; t++) { const m = confusion(sc, t / 100); const v = b.dataset.g === 'f1' ? m.f1 : b.dataset.g === 'rec' ? (m.rec >= .95 ? t : -1) : (m.prec >= .85 ? -t : -1); if (v > bv) { bv = v; best = t; } } LAB.thr = best; $('#thr', tp).value = best; upd(); });
  // per-algorithm deep dives
  c.insertAdjacentHTML('beforeend', `<nav class="tabs" style="margin-top:6px">${[['knn', 'K-Nearest Neighbours'], ['dt', 'Decision Tree'], ['rf', 'Random Forest'], ['gb', 'Gradient Boosted Trees']].map(([k, l]) => `<button data-a="${k}" aria-pressed="${LAB.algo === k}">${l}</button>`).join('')}</nav>`);
  $$('[data-a]', c).forEach(b => b.onclick = () => { LAB.algo = b.dataset.a; render(true); });
  const rid = resolveId(LAB.rid) >= 0 ? resolveId(LAB.rid) : TEST[3];
  const pick = `<div class="flex" style="margin-bottom:8px"><label class="flabel" for="rid">Respondent</label><input class="inp mono" id="rid" style="width:130px" value="${D.id[rid]}"><button class="btn sm" id="ridR">Random test respondent</button><span class="muted" style="font-size:12px">actual: <b>${isN(YALL(rid)) ? (YALL(rid) ? 'would pay' : 'free only') : 'unknown'}</b> · ${esc(L.WTP[D.q22[rid]] || 'blank')}</span></div>`;
  const wirePick = el => { $('#rid', el).onchange = e => { LAB.rid = e.target.value; render(true); }; $('#ridR', el).onclick = () => { LAB.rid = D.id[TEST[Math.floor(Math.random() * TEST.length)]]; render(true); }; };
  if (LAB.algo === 'knn') {
    cpanel({ parent: c, span: 6, title: 'Choosing K', sub: `Train vs test AUC by number of neighbours · best test AUC at K = ${P.bestK}`, prov: 'model', opt: () => lineTT(P.knnCurve.map(r => 'K=' + r.k), P.knnCurve.map(r => r.train_auc), P.knnCurve.map(r => r.test_auc), 'AUC'),
      table: () => ({ head: ['K', 'Train acc', 'Test acc', 'Train AUC', 'Test AUC'], rows: P.knnCurve.map(r => [String(r.k), pct(r.train_acc), pct(r.test_acc), f1(r.train_auc, 3), f1(r.test_auc, 3)]) }) });
    const nb = knnLookup(rid, LAB.knnK); const yes = nb.filter(([, t]) => YALL(t) === 1).length;
    const kp = panel({ parent: c, span: 6, title: 'Ask the lookalikes', sub: 'Live K-NN on 27 standardised features: the K most similar training respondents vote', prov: 'model',
      html: pick + `<div class="ctl"><label for="kk">Neighbours (K) <output>${LAB.knnK}</output></label><input type="range" id="kk" min="1" max="75" value="${LAB.knnK}"></div>
      <div class="flex" style="margin:10px 0"><span class="pill ${yes / LAB.knnK >= .5 ? 'hi' : 'lo'}">Vote: ${yes} of ${LAB.knnK} would pay → predict ${yes / LAB.knnK >= .5 ? 'PAY' : 'FREE'}</span><span class="muted" style="font-size:12px">${pct(yes / LAB.knnK, 0)} payer share among neighbours</span></div>
      <div class="tw" style="max-height:220px">${tableHTML(['Neighbour', 'Distance', 'Status', 'Age', 'Stated WTP'], nb.slice(0, 15).map(([d, t]) => [`<span class="mono">${D.id[t]}</span>`, f1(d, 2), L.STATUS[D.q4[t]], L.AGE[D.q1[t]], `<span style="color:${YALL(t) ? 'var(--good-ink)' : 'var(--muted)'}">${esc(L.WTP[D.q22[t]])}</span>`]), { autoRight: false, right: [1] })}</div>` });
    wirePick(kp); $('#kk', kp).onchange = e => { LAB.knnK = +e.target.value; render(true); }; $('#kk', kp).oninput = e => e.target.previousElementSibling.querySelector('output').textContent = e.target.value;
  }
  if (LAB.algo === 'dt') {
    const dtCurveP = () => cpanel({ parent: c, span: 12, h: 'short', title: 'Tree depth vs overfitting', sub: `Training accuracy keeps rising; test accuracy peaks then falls · best test AUC at depth ${P.bestDepth}`, prov: 'model', opt: () => lineTT(P.dtCurve.map(r => 'd' + r.depth), P.dtCurve.map(r => r.train_acc), P.dtCurve.map(r => r.test_acc), 'Accuracy'),
      table: () => ({ head: ['Depth', 'Train acc', 'Test acc', 'Test AUC'], rows: P.dtCurve.map(r => [String(r.depth), pct(r.train_acc), pct(r.test_acc), f1(r.test_auc, 3)]) }) });
    const path = new Set(treePath(rid)); const lv = []; (function walk(nd, d) { (lv[d] = lv[d] || []).push(nd); if (nd.l) { walk(nd.l, d + 1); walk(nd.r, d + 1); } })(P.tree, 0);
    const box = nd => `<div class="tnode ${nd.f === undefined ? 'leaf' : ''} ${path.has(nd.id) ? 'lit' : ''}"><div class="q">${nd.f === undefined ? (nd.p >= .5 ? 'Predict: PAY' : 'Predict: FREE') : esc(splitText(nd))}</div><div class="m">n ${fmtN(nd.n)} · ${pct(nd.p, 0)} pay</div><div class="pbar"><i style="width:${nd.p * 100}%"></i></div></div>`;
    const tpn = panel({ parent: c, span: 12, title: 'Read the tree like a flowchart', sub: `Depth-3 tree (min 40 per leaf) on training data · left branch = "No" / "≤", right = "Yes" / ">" · test AUC ${f1(P.tree3Test.auc, 3)}`, prov: 'model',
      html: pick + `<div class="tree">${lv.map(row => `<div class="trow">${row.map(box).join('')}</div>`).join('')}</div><p class="muted" style="font-size:12px;margin:6px 0 0">The highlighted path is the selected respondent's route. Top splits are the strongest separators of payers vs free-only in this sample.</p>` });
    wirePick(tpn); dtCurveP();
  }
  if (LAB.algo === 'rf') {
    const j = TEST_POS.has(rid) ? TEST_POS.get(rid) : 3, i = TEST[j]; const rnd = rng32(LAB.poll * 31 + 7); const ids = Array.from({ length: RF_T }, (_, t) => t).sort(() => rnd() - .5).slice(0, LAB.trees);
    const yes = ids.filter(t => rfVote(t, j)).length;
    const rp = panel({ parent: c, span: 6, title: 'Poll the committee', sub: `Each of ${RF_T} trees saw a different bootstrap sample and random features. Small committees flip-flop; large ones agree.`, prov: 'model',
      html: pick.replace(D.id[rid], D.id[i]) + `<div class="ctl"><label for="nt">Trees polled <output>${LAB.trees}</output></label><input type="range" id="nt" min="1" max="${RF_T}" value="${LAB.trees}"></div>
      <div class="flex" style="margin:10px 0"><button class="btn pri" id="repoll">Re-poll a random committee</button><span class="pill ${yes / LAB.trees >= .5 ? 'hi' : 'lo'}">${yes} pay · ${LAB.trees - yes} free → ${yes / LAB.trees >= .5 ? 'PAY' : 'FREE'}</span></div>
      <div style="display:flex;flex-wrap:wrap;gap:3px">${ids.map(t => `<span title="Tree ${t + 1}" style="width:12px;height:12px;border-radius:2px;background:${rfVote(t, j) ? TC.c1 : TC['line']}"></span>`).join('')}</div>
      <p class="muted" style="font-size:12px">${TEST_POS.has(rid) ? '' : 'Votes exist for test respondents only; showing a test respondent. '}Forest probability (all ${RF_T} trees): <b>${pct(P.scores.rf[j] / 1000)}</b></p>` });
    wirePick(rp); $('#nt', rp).onchange = e => { LAB.trees = +e.target.value; render(true); }; $('#repoll', rp).onclick = () => { LAB.poll++; render(true); };
    cpanel({ parent: c, span: 6, title: 'Permutation importance', sub: 'Drop in test AUC when a feature is shuffled (top 12) · more honest than impurity importance', prov: 'model', h: 'tall',
      opt: () => hbar(P.rfImp.slice(0, 12).map(r => r.f), P.rfImp.slice(0, 12).map(r => +(r.perm * 1000).toFixed(1)), { sort: false, fmt: v => (v / 1000).toFixed(3), tipFmt: (v, d) => `ΔAUC ${(v / 1000).toFixed(4)} ± ${P.rfImp[d.code].perm_sd.toFixed(4)}` }),
      table: () => ({ head: ['Feature', 'Permutation ΔAUC', 'SD', 'Impurity (MDI)'], rows: P.rfImp.map(r => [r.f, f1(r.perm, 4), f1(r.perm_sd, 4), f1(r.mdi, 4)]) }) });
    cpanel({ parent: c, span: 12, title: 'Committee size vs accuracy', sub: 'Test AUC as more trees vote', prov: 'model', h: 'short', opt: () => lineTT(P.rfCurve.map(r => r.trees + ' trees'), null, P.rfCurve.map(r => r.test_auc), 'Test AUC'), table: () => ({ head: ['Trees', 'Test AUC', 'Test acc'], rows: P.rfCurve.map(r => [String(r.trees), f1(r.test_auc, 3), pct(r.test_acc)]) }) });
  }
  if (LAB.algo === 'gb') {
    const cur = P.gbCurve.reduce((a, b) => Math.abs(b.rounds - LAB.rounds) < Math.abs(a.rounds - LAB.rounds) ? b : a);
    const gp = cpanel({ parent: c, span: 8, title: 'More rounds is not always better', sub: `Training log-loss keeps falling; test log-loss bottoms out at ${P.gbBest} rounds then rises (overfitting) · learning rate 0.12, depth 4`, prov: 'model', h: 'tall',
      pre: `<div class="ctl" style="max-width:420px"><label for="gbr">Boosting rounds <output>${LAB.rounds}</output></label><input type="range" id="gbr" min="1" max="400" value="${LAB.rounds}"></div><div class="flex" style="margin:6px 0"><span class="pill">Train loss ${f1(cur.train_loss, 3)}</span><span class="pill">Test loss ${f1(cur.test_loss, 3)}</span><span class="pill">Test AUC ${f1(cur.test_auc, 3)}</span><span class="pill">Test error ${pct(cur.test_err)}</span></div>`,
      opt: () => { const o = lineTT(P.gbCurve.map(r => r.rounds), P.gbCurve.map(r => r.train_loss), P.gbCurve.map(r => r.test_loss), 'Log-loss'); o.series[1].markLine = { silent: true, symbol: 'none', lineStyle: { color: TC.c2 }, label: { formatter: 'selected', color: TC['ink-2'] }, data: [{ xAxis: String(cur.rounds) }] }; o.yAxis.scale = true; return o; },
      table: () => ({ head: ['Rounds', 'Train loss', 'Test loss', 'Test AUC', 'Test error'], rows: P.gbCurve.map(r => [String(r.rounds), f1(r.train_loss, 4), f1(r.test_loss, 4), f1(r.test_auc, 3), pct(r.test_err)]) }) });
    $('#gbr', gp).onchange = e => { LAB.rounds = +e.target.value; render(true); }; $('#gbr', gp).oninput = e => e.target.previousElementSibling.querySelector('output').textContent = e.target.value;
    cpanel({ parent: c, span: 4, title: 'What the boosted model uses', sub: 'Impurity-based importance (top 10)', prov: 'model', h: 'tall', opt: () => hbar(P.gbImp.slice(0, 10).map(r => r.f), P.gbImp.slice(0, 10).map(r => +(r.v * 100).toFixed(1)), { sort: false, fmt: v => v.toFixed(1) + '%', lw: 130 }), table: () => ({ head: ['Feature', 'Importance'], rows: P.gbImp.map(r => [r.f, f1(r.v, 4)]) }) });
    const dp = panel({ parent: c, span: 12, title: 'Propensity distribution (out-of-fold)', sub: 'Gradient-boosting probability of paying for every respondent, from 5-fold cross-validation, so no respondent is scored by a model that saw it', prov: 'model', html: '<div class="chart"></div>' });
    const ix = IX(); const bins = new Array(20).fill(0), binsP = new Array(20).fill(0); for (const i of ix) { const b = Math.min(19, Math.floor(D.prop[i] * 20)); bins[b]++; if (D.paid[i] === 1) binsP[b]++; }
    mount($('.chart', dp), { legend: { top: 0, icon: 'circle', itemWidth: 9, textStyle: { color: TC['ink-2'] } }, grid: { left: 8, right: 10, top: 30, bottom: 6, containLabel: true }, tooltip: { trigger: 'axis' }, xAxis: catAx(bins.map((_, k) => (k / 20).toFixed(2))), yAxis: valAx({}),
      series: [{ name: 'All in view', type: 'bar', barGap: '-100%', data: bins, itemStyle: { color: TC['line'] } }, { name: 'Stated payers', type: 'bar', data: binsP, itemStyle: { color: TC.c1 } }] });
  }
}
function lineTT(x, tr, te, yname) {
  const s = []; if (tr) s.push({ name: 'Training', type: 'line', data: tr.map(v => +v.toFixed(4)), lineStyle: { color: TC.c3, width: 2 }, itemStyle: { color: TC.c3 }, symbolSize: 5 });
  s.push({ name: 'Test (what matters)', type: 'line', data: te.map(v => +v.toFixed(4)), lineStyle: { color: TC.c2, width: 2 }, itemStyle: { color: TC.c2 }, symbolSize: 5 });
  return { legend: { top: 0, icon: 'circle', itemWidth: 9, textStyle: { color: TC['ink-2'] } }, grid: { left: 8, right: 16, top: 30, bottom: 6, containLabel: true }, tooltip: { trigger: 'axis' }, xAxis: catAx(x.map(String)), yAxis: valAx({ scale: true, name: yname, nameTextStyle: { color: TC.muted } }), series: s };
}
function labReg(c) {
  const ix = IX(); const R = regData(LAB.regT, ix); const tLab = LAB.regT === 'rec' ? 'Likelihood to recommend (Q24, 0–10)' : 'Expected salary (log ₹ \'000/month)';
  const rng = LAB.regM === 'lasso' ? [-3.3, 0.3] : [-2, 4]; const la = Math.log10(Math.max(1e-6, LAB.regA)); const aOk = LAB.regM === 'ols' ? 0 : Math.min(rng[1], Math.max(rng[0], la));
  if (LAB.regM !== 'ols') LAB.regA = Math.pow(10, aOk);
  const fit = regFit(LAB.regT, LAB.regM, LAB.regM === 'ols' ? 0 : LAB.regA, ix, R); if (!fit) return emptyState(c);
  const ols = regFit(LAB.regT, 'ols', 0, ix, R);
  const cp = panel({ parent: c, span: 12, title: 'Regression set-up', sub: `Refits live on the current filter view · ${fmtN(R.n)} respondents with the target · deterministic 70/30 split (${fmtN(fit.ntr)} / ${fmtN(fit.nte)}) · features standardised on the training rows`, prov: 'model',
    html: `<div class="flex"><span class="flabel">Predict</span><div class="seg" id="rgT"><button data-v="rec" aria-pressed="${LAB.regT === 'rec'}">Likelihood to recommend</button><button data-v="sal" aria-pressed="${LAB.regT === 'sal'}">Expected salary</button></div>
      <span class="flabel">Method</span><div class="seg" id="rgM">${[['ols', 'Linear (OLS)'], ['ridge', 'Ridge (L2)'], ['lasso', 'Lasso (L1)']].map(([k, l]) => `<button data-v="${k}" aria-pressed="${LAB.regM === k}">${l}</button>`).join('')}</div>
      ${LAB.regM !== 'ols' ? `<div class="ctl" style="flex:1;min-width:240px"><label for="rgA">Penalty strength λ (log scale) <output>${LAB.regA < .01 ? LAB.regA.toExponential(1) : f1(LAB.regA, LAB.regA < 1 ? 3 : 1)}</output></label><input type="range" id="rgA" min="${rng[0]}" max="${rng[1]}" step="0.05" value="${aOk}"></div>` : ''}</div>
      <div class="metric-row" style="margin-top:12px"><div><b>${f1(fit.r2tr, 3)}</b><span>Train R²</span></div><div><b>${f1(fit.r2te, 3)}</b><span>Test R²</span></div><div><b>${f1(fit.rmseTe, 3)}</b><span>Test RMSE</span></div><div><b>${fit.nz} / ${REG_F.length}</b><span>Non-zero coefficients</span></div></div>` });
  $$('#rgT button', cp).forEach(b => b.onclick = () => { LAB.regT = b.dataset.v; render(true); }); $$('#rgM button', cp).forEach(b => b.onclick = () => { LAB.regM = b.dataset.v; LAB.regA = b.dataset.v === 'lasso' ? .02 : 10; render(true); });
  if ($('#rgA', cp)) { $('#rgA', cp).onchange = e => { LAB.regA = Math.pow(10, +e.target.value); render(true); }; $('#rgA', cp).oninput = e => { const v = Math.pow(10, +e.target.value); e.target.previousElementSibling.querySelector('output').textContent = v < .01 ? v.toExponential(1) : f1(v, v < 1 ? 3 : 1); }; }
  const ord = REG_F.map((f, j) => j).sort((a, b) => Math.abs(ols.coef[b]) - Math.abs(ols.coef[a]));
  cpanel({ parent: c, span: 7, title: 'Standardised coefficients', sub: `${tLab} · grey = OLS (λ = 0), colour = ${LAB.regM.toUpperCase()} at the chosen λ · Lasso drops weak drivers to exactly zero`, prov: 'model', h: 'xtall',
    pre: legendHTML([[TC.line, 'OLS reference'], [TC['div-pos'], 'Positive effect'], [TC['div-neg'], 'Negative effect']]),
    opt: () => ({ grid: { left: 8, right: 40, top: 6, bottom: 6, containLabel: true }, tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } }, xAxis: valAx({}), yAxis: catAx(ord.map(j => REG_F[j]), { inverse: true }),
      series: [{ name: 'OLS', type: 'bar', barGap: '-100%', barMaxWidth: 16, data: ord.map(j => +ols.coef[j].toFixed(4)), itemStyle: { color: TC.line } },
        { name: LAB.regM.toUpperCase(), type: 'bar', barMaxWidth: 9, data: ord.map(j => ({ value: +fit.coef[j].toFixed(4), itemStyle: { color: fit.coef[j] >= 0 ? TC['div-pos'] : TC['div-neg'] } })), label: { show: true, position: 'right', fontSize: 10, color: TC['ink-2'], formatter: p => Math.abs(p.value) < 1e-6 ? '0 (dropped)' : p.value.toFixed(3) } }] }),
    table: () => ({ head: ['Feature', 'OLS β', 'SE', 't', 'p', LAB.regM.toUpperCase() + ' β'], rows: ord.map(j => [REG_F[j], f1(ols.coef[j], 4), f1(ols.se[j], 4), f1(ols.coef[j] / ols.se[j], 2), pv(tsf2(ols.coef[j] / ols.se[j], ols.ntr - REG_F.length - 1)), f1(fit.coef[j], 4)]) }) });
  const grid = LAB.regM === 'lasso' ? Array.from({ length: 22 }, (_, k) => Math.pow(10, -3.3 + k * 3.6 / 21)) : Array.from({ length: 22 }, (_, k) => Math.pow(10, -2 + k * 6 / 21));
  const path = LAB.regM === 'ols' ? null : grid.map(a => regFit(LAB.regT, LAB.regM, a, ix, R));
  if (path) cpanel({ parent: c, span: 5, title: 'Coefficient path', sub: 'Every coefficient as λ grows · top 6 OLS drivers coloured, the rest grey', prov: 'model', h: 'xtall',
    opt: () => ({ grid: { left: 8, right: 14, top: 40, bottom: 26, containLabel: true }, legend: { top: 0, icon: 'circle', itemWidth: 8, textStyle: { color: TC['ink-2'], fontSize: 10 } }, tooltip: { trigger: 'axis', valueFormatter: v => v.toFixed(3) },
      xAxis: catAx(grid.map(a => a < .01 ? a.toExponential(0) : a < 10 ? a.toFixed(2) : a.toFixed(0)), { name: 'λ', nameLocation: 'middle', nameGap: 22, nameTextStyle: { color: TC.muted }, axisLabel: { interval: 4, color: TC['ink-2'] } }), yAxis: valAx({}),
      series: REG_F.map((f, j) => { const r = ord.indexOf(j); const col = r < 6 ? TC.cat[r] : TC.line; return { name: r < 6 ? f : undefined, type: 'line', showSymbol: false, data: path.map(p => +p.coef[j].toFixed(4)), lineStyle: { width: r < 6 ? 2 : 1, color: col }, itemStyle: { color: col }, z: r < 6 ? 3 : 1 }; }),
      markLine: undefined }),
    table: () => ({ head: ['λ', 'Test R²', 'Non-zero'], rows: grid.map((a, k) => [f1(a, 4), f1(path[k].r2te, 3), String(path[k].nz)]) }) });
  if (!path) panel({ parent: c, span: 5, title: 'OLS inference', sub: 'Standard errors, t and p on the training rows', prov: 'model', html: `<div class="tw">${tableHTML(['Feature', 'β', 'p'], ord.map(j => [REG_F[j], f1(ols.coef[j], 3), pv(tsf2(ols.coef[j] / ols.se[j], ols.ntr - REG_F.length - 1))]))}</div><p class="muted" style="font-size:12px">p-values assume independent, normal residuals; Q24 is a bounded 0–10 scale, so treat them as approximate.</p>` });
  c.insertAdjacentHTML('beforeend', `<div class="s12 note"><b>Reading this.</b> Coefficients are change in ${LAB.regT === 'rec' ? 'Q24 points' : 'log salary'} per one standard deviation of each driver, holding the others fixed. AI familiarity, usage and trust are correlated: Ridge shares credit across them, Lasso tends to keep one. Associations only; the survey cannot show causation.</div>`);
}
function labClu(c) {
  const ix = IX(); const n = ix.length; if (n < 60) return emptyState(c);
  const live = LAB.kmLive; const K = LAB.kmK;
  let res; if (live) { if (!LAB.km || LAB.km.key !== fkey() + K) { const r = kmeansRun(Array.from(ix), K); LAB.km = { key: fkey() + K, ...r, ix: Array.from(ix), sil: silhouette(Array.from(ix), r.lab, K) }; } res = LAB.km; }
  else { res = { lab: Int8Array.from(ix, i => D.km[i]), C: P.kmCent, k: P.kmK, ix: Array.from(ix), sizes: Array.from({ length: P.kmK }, (_, k) => sub(ix, i => D.km[i] === k).length) }; }
  const kp = panel({ parent: c, span: 12, title: 'K-Means set-up', sub: `9 standardised behavioural variables: ${P.kmF.join(', ')}`, prov: 'model',
    html: `<div class="flex"><div class="seg" id="kmM"><button data-v="0" aria-pressed="${!live}">Reference solution (Python, full sample, k = ${P.kmK})</button><button data-v="1" aria-pressed="${live}">Re-run live on current view</button></div>
      ${live ? `<div class="ctl" style="min-width:220px"><label for="kmK">Number of clusters K <output>${K}</output></label><input type="range" id="kmK" min="2" max="8" value="${K}"></div><span class="pill">WCSS ${fmtN(res.wcss)}</span><span class="pill">Silhouette ≈ ${f1(res.sil, 3)} (sample of 600)</span>` : '<span class="muted" style="font-size:12px">Reference labels shown for respondents in view.</span>'}</div>` });
  $$('#kmM button', kp).forEach(b => b.onclick = () => { LAB.kmLive = b.dataset.v === '1'; render(true); }); if ($('#kmK', kp)) $('#kmK', kp).onchange = e => { LAB.kmK = +e.target.value; render(true); };
  cpanel({ parent: c, span: 4, title: 'Elbow method', sub: 'Within-cluster sum of squares (full sample, Python) · no sharp elbow, so k = 5 was chosen for interpretability', prov: 'model', h: 'tall',
    opt: () => ({ grid: { left: 8, right: 30, top: 30, bottom: 6, containLabel: true }, legend: { top: 0, icon: 'circle', itemWidth: 9, textStyle: { color: TC['ink-2'] } }, tooltip: { trigger: 'axis' }, xAxis: catAx(P.kmElbow.map(e => 'k=' + e.k)), yAxis: [valAx({ scale: true, axisLabel: { formatter: v => fmtN(v / 1000) + 'k', color: TC['ink-2'] } })],
      series: [{ name: 'WCSS', type: 'line', data: P.kmElbow.map(e => Math.round(e.wcss)), lineStyle: { color: TC.c1, width: 2 }, itemStyle: { color: TC.c1 }, symbolSize: 7, markPoint: { symbol: 'circle', symbolSize: 14, itemStyle: { color: TC.c2 }, label: { show: false }, data: [{ coord: ['k=' + P.kmK, Math.round(P.kmElbow.find(e => e.k === P.kmK).wcss)] }] } }] }),
    table: () => ({ head: ['k', 'WCSS', 'Silhouette'], rows: P.kmElbow.map(e => [String(e.k), Math.round(e.wcss), f1(e.sil, 3)]) }) });
  const samp = res.ix.filter((_, a) => a % Math.max(1, Math.ceil(res.ix.length / 1800)) === 0);
  const pos = new Map(res.ix.map((i, a) => [i, a]));
  cpanel({ parent: c, span: 8, title: 'Clusters on the first two principal components', sub: `PCA of the 9 variables (PC1 ${pct(P.pcaVar[0], 0)}, PC2 ${pct(P.pcaVar[1], 0)} of variance) · up to 1,800 points`, prov: 'model', h: 'tall',
    pre: legendHTML(res.C.map((cz, k) => [TC.cat[k], `C${k + 1} ${clusterName(cz)} (${fmtN(res.sizes[k])})`])),
    opt: () => ({ grid: { left: 8, right: 10, top: 10, bottom: 6, containLabel: true }, tooltip: { formatter: p => `${D.id[p.data[2]]} · C${p.data[3] + 1}` }, xAxis: valAx({ axisLabel: { show: false } }), yAxis: valAx({ axisLabel: { show: false } }),
      series: Array.from({ length: res.k }, (_, k) => ({ type: 'scatter', symbolSize: 5, data: samp.filter(i => res.lab[pos.get(i)] === k).map(i => [P.pca[0][i], P.pca[1][i], i, k]), itemStyle: { color: TC.cat[k], opacity: .7 } })) }),
    table: () => ({ head: ['Cluster', 'Name', 'n'], rows: res.C.map((cz, k) => ['C' + (k + 1), clusterName(cz), res.sizes[k]]) }), click: p => openRespondent(p.data[2]) });
  const hd = []; res.C.forEach((cz, k) => cz.forEach((v, j) => hd.push([j, k, +v.toFixed(2)])));
  cpanel({ parent: c, span: 12, title: 'Cluster profiles', sub: 'Centroids in standard deviations from the mean · blue = above average, red = below', prov: 'model', h: res.k > 5 ? 'tall' : '',
    opt: () => heat(P.kmF, res.C.map((cz, k) => `C${k + 1} ${clusterName(cz)}`), hd, { diverging: true, min: -1.5, max: 1.5, fmt: v => (v > 0 ? '+' : '') + v, cell: v => (v > 0 ? '+' : '') + v.toFixed(1), rot: 20 }),
    table: () => ({ head: ['Cluster', ...P.kmF], rows: res.C.map((cz, k) => ['C' + (k + 1), ...cz.map(v => f1(v, 2))]) }) });
  // LCA
  const fits = P.lca.fits;
  cpanel({ parent: c, span: 4, title: 'Latent Class: how many classes?', sub: 'BIC (lower is better) and classification entropy', prov: 'model',
    opt: () => ({ grid: { left: 8, right: 10, top: 20, bottom: 6, containLabel: true }, tooltip: { trigger: 'axis' }, xAxis: catAx(fits.map(f => 'C=' + f.C)), yAxis: valAx({ scale: true, axisLabel: { formatter: v => fmtN(v), color: TC['ink-2'] } }),
      series: [{ type: 'line', data: fits.map(f => Math.round(f.bic)), lineStyle: { color: TC.c7, width: 2 }, itemStyle: { color: TC.c7 }, symbolSize: 7 }] }),
    table: () => ({ head: ['Classes', 'Log-likelihood', 'BIC', 'AIC', 'Entropy'], rows: fits.map(f => [String(f.C), Math.round(f.ll), Math.round(f.bic), Math.round(f.aic), f1(f.entropy, 3)]) }) });
  const items = P.lca.items; const rowsL = [], hd2 = []; let r = 0; items.forEach(([nm, cats], j) => cats.forEach((ct, v) => { rowsL.push(`${nm}: ${ct}`); for (let k = 0; k < LCA_C; k++) hd2.push([k, r, Math.round(P.lca.th[j][k][v] * 100)]); r++; }));
  cpanel({ parent: c, span: 8, title: 'Latent Class profiles', sub: 'Probability that a member of each hidden class gives each answer · columns sum to 100% within each question', prov: 'model', h: 'xtall',
    opt: () => { const o = heat(LCA_NAMES.map((n_, k) => `L${k + 1} ${n_} (${pct(P.lca.pi[k], 0)})`), rowsL, hd2, { min: 0, max: 100, fmt: v => v + '%', cell: v => v, rot: 0, vm: false }); o.grid.top = 30; o.xAxis.axisLabel.width = 120; o.xAxis.axisLabel.overflow = 'break'; return o; },
    table: () => ({ head: ['Answer', ...LCA_NAMES], rows: rowsL.map((rl, y) => [rl, ...LCA_NAMES.map((_, k) => hd2.find(d => d[0] === k && d[1] === y)[2] + '%')]) }) });
  const lid = resolveId(LAB.lcaId) >= 0 ? resolveId(LAB.lcaId) : ix[0]; const pr = lcaRow(lid);
  const certs = new Array(10).fill(0); for (const i of ix) { const m = Math.max(...lcaRow(i)); certs[Math.min(9, Math.floor(m * 10))]++; }
  const lp = panel({ parent: c, span: 6, title: 'Soft membership explorer', sub: 'Unlike K-Means, each respondent gets a probability for every class', prov: 'model',
    html: `<div class="flex" style="margin-bottom:10px"><label class="flabel" for="lid">Respondent</label><input class="inp mono" id="lid" style="width:130px" value="${D.id[lid]}"><button class="btn sm" id="lidR">Random</button><button class="btn sm" id="lidF">Find a fence-sitter</button></div>
    ${LCA_NAMES.map((nm, k) => `<div style="display:grid;grid-template-columns:170px 1fr 48px;gap:8px;align-items:center;margin:5px 0;font-size:12.5px"><span><i class="dot" style="background:${TC.cat[k + 4]}"></i> ${nm}</span><span style="background:var(--line-2);border-radius:3px;height:12px;overflow:hidden"><i style="display:block;height:100%;width:${pr[k] * 100}%;background:${TC.cat[k + 4]}"></i></span><b class="num" style="text-align:right">${pct(pr[k], 0)}</b></div>`).join('')}
    <p class="muted" style="font-size:12px;margin:8px 0 0">${esc(L.STATUS[D.q4[lid]])} · gap ${esc(L.GAPQ[D.q14[lid]])} · AI use ${esc(L.AIUSE[D.q17[lid]])} · intent ${esc(L.INTENT[D.q20[lid]])} · WTP ${esc(L.WTP[D.q22[lid]] || 'blank')}</p>` });
  $('#lid', lp).onchange = e => { LAB.lcaId = e.target.value; render(true); }; $('#lidR', lp).onclick = () => { LAB.lcaId = D.id[ix[Math.floor(Math.random() * ix.length)]]; render(true); };
  $('#lidF', lp).onclick = () => { const f = Array.from(ix).filter(i => { const s = lcaRow(i).sort((a, b) => b - a); return s[0] - s[1] < .15; }); if (f.length) { LAB.lcaId = D.id[f[Math.floor(Math.random() * f.length)]]; render(true); } };
  cpanel({ parent: c, span: 6, title: 'Classification certainty', sub: 'Highest class probability per respondent in view', prov: 'model', opt: () => vbar(certs.map((_, k) => `${k * 10}–${k * 10 + 10}%`), certs, { colors: ordRamp(10) }), table: () => tblCount(certs.map((_, k) => `${k * 10}–${k * 10 + 10}%`), certs, n) });
  const xt = Array.from({ length: P.kmK }, (_, a) => Array.from({ length: LCA_C }, (_, b) => 0)); for (const i of ix) xt[D.km[i]][D.lca[i]]++;
  const hd3 = []; xt.forEach((rw, y) => rw.forEach((v, x) => hd3.push([x, y, v])));
  cpanel({ parent: c, span: 12, title: 'Do the two methods agree?', sub: 'K-Means reference clusters (rows) × Latent Class modal class (columns) · counts', prov: 'model', h: 'short',
    opt: () => { const o = heat(LCA_NAMES, P.kmCent.map((cz, k) => `C${k + 1} ${clusterName(cz)}`), hd3, { rot: 0, vm: false }); o.grid.top = 26; return o; }, table: () => ({ head: ['Cluster', ...LCA_NAMES], rows: xt.map((rw, k) => ['C' + (k + 1), ...rw]) }) });
}
function labAR(c) {
  const ix = IX(); const U = { q19: 'AI features wanted (Q19)', q11: 'Skills held (Q11)', gap: 'Skill gaps (Q12 − Q11)', profile: 'Profile → feature (who wants what)' };
  const rules = assocRules(LAB.ar, ix, LAB.arS / 100, LAB.arC / 100).filter(r => r.lift >= LAB.arL).sort((a, b) => b.lift - a.lift);
  const ap = panel({ parent: c, span: 12, title: 'Association rule mining (Apriori)', sub: `Rules A → B scored by support, confidence and lift · live on the ${fmtN(ix.length)} respondents in view · itemsets up to 3`, prov: 'model',
    html: `<div class="flex"><div class="seg" id="arU">${Object.entries(U).map(([k, l]) => `<button data-v="${k}" aria-pressed="${LAB.ar === k}">${l}</button>`).join('')}</div></div>
    <div class="ctl-grid" style="margin-top:10px">${[['arS', 'Min support (%)', 1, 40], ['arC', 'Min confidence (%)', 5, 95], ['arL', 'Min lift', .8, 3, .05]].map(([k, l, lo, hi, st]) => `<div class="ctl"><label for="${k}">${l} <output>${LAB[k]}</output></label><input type="range" id="${k}" min="${lo}" max="${hi}" step="${st || 1}" value="${LAB[k]}"></div>`).join('')}</div>
    <p class="muted" style="font-size:12px;margin:8px 0 0">Support = share of respondents with A and B. Confidence = P(B | A). Lift = confidence ÷ P(B); lift > 1 means A makes B more likely than chance. ${fmtN(rules.length)} rules pass.</p>` });
  $$('#arU button', ap).forEach(b => b.onclick = () => { LAB.ar = b.dataset.v; if (b.dataset.v === 'profile') { LAB.arS = 3; LAB.arC = 40; } render(true); });
  ['arS', 'arC', 'arL'].forEach(k => { const el = $('#' + k, ap); el.oninput = () => el.previousElementSibling.querySelector('output').textContent = el.value; el.onchange = () => { LAB[k] = +el.value; render(true); }; });
  const top = rules.slice(0, 300);
  cpanel({ parent: c, span: 6, title: 'Rules map', sub: 'Support vs confidence · bubble size and colour = lift', prov: 'model', h: 'tall',
    opt: () => ({ grid: { left: 8, right: 20, top: 16, bottom: 40, containLabel: true }, tooltip: { formatter: p => { const r = top[p.dataIndex]; return `<b>${esc(r.A)}</b> → <b>${esc(r.B)}</b><br>support ${pct(r.sup)} · confidence ${pct(r.conf)} · lift ${f1(r.lift, 2)}`; } },
      xAxis: valAx({ name: 'Support', nameLocation: 'middle', nameGap: 22, nameTextStyle: { color: TC.muted }, axisLabel: { formatter: v => (v * 100).toFixed(0) + '%', color: TC['ink-2'] } }), yAxis: valAx({ name: 'Confidence', nameTextStyle: { color: TC.muted }, axisLabel: { formatter: v => (v * 100).toFixed(0) + '%', color: TC['ink-2'] }, scale: true }),
      visualMap: { dimension: 2, min: 1, max: Math.max(1.5, ...top.map(r => r.lift)), orient: 'horizontal', left: 'center', bottom: 0, itemHeight: 120, itemWidth: 10, text: ['higher lift', 'lift 1'], textStyle: { color: TC['ink-2'], fontSize: 10 }, inRange: { color: [TC['seq-lo'], TC['seq-hi']] } },
      series: [{ type: 'scatter', data: top.map(r => [r.sup, r.conf, r.lift]), symbolSize: d => 6 + 10 * Math.min(2, d[2] - .8), itemStyle: { borderColor: TC.panel, borderWidth: 1 } }] }),
    table: () => ({ head: ['A', 'B', 'Support', 'Confidence', 'Lift'], rows: top.map(r => [esc(r.A), esc(r.B), pct(r.sup), pct(r.conf), f1(r.lift, 2)]) }) });
  panel({ parent: c, span: 6, title: 'Strongest rules', sub: 'Sorted by lift', prov: 'model', html: rules.length ? `<div class="tw" style="max-height:380px">${tableHTML(['If…', '…then', 'Support', 'Conf.', 'Lift', 'n'], rules.slice(0, 40).map(r => [esc(r.A), esc(r.B), pct(r.sup), pct(r.conf), `<b>${f1(r.lift, 2)}</b>`, r.nAB]))}</div>` : '<div class="empty">No rules pass these thresholds. Lower support or confidence.</div>' });
  const Uo = arUniverse(LAB.ar); const opts = Uo.items;
  const A = opts.includes(LAB.arA) ? LAB.arA : opts[0], B = opts.includes(LAB.arB) && LAB.arB !== A ? LAB.arB : opts[1];
  const ai = opts.indexOf(A), bi = opts.indexOf(B); let nA = 0, nB = 0, nAB = 0, nn = 0; for (const i of ix) { const t = Uo.tx(i); if (t < 0) continue; nn++; const a = t >> ai & 1, b = t >> bi & 1; nA += a; nB += b; nAB += a & b; }
  const conf = nAB / Math.max(1, nA), lift = conf / Math.max(1e-9, nB / nn);
  const bp = panel({ parent: c, span: 12, title: 'Build a rule and score it', sub: 'Pick any two items, as in the guide\'s basket demo', prov: 'calc',
    html: `<div class="flex"><span>If a respondent has</span><select class="inp" id="arA" style="width:auto">${opts.map(o => `<option ${o === A ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select><span>then they also have</span><select class="inp" id="arB" style="width:auto">${opts.map(o => `<option ${o === B ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select></div>
    <div class="metric-row" style="margin-top:12px"><div><b>${pct(nAB / Math.max(1, nn))}</b><span>Support (${fmtN(nAB)} of ${fmtN(nn)})</span></div><div><b>${pct(conf)}</b><span>Confidence</span></div><div><b>${f1(lift, 2)}</b><span>Lift</span></div><div><b>${lift > 1.1 ? 'Positive' : lift < .9 ? 'Negative' : 'No real link'}</b><span>Verdict</span></div></div>
    <p class="muted" style="font-size:12px;margin:8px 0 0">${pct(nB / nn)} of respondents have "${esc(B)}" anyway; lift compares the rule against that baseline.</p>` });
  $('#arA', bp).onchange = e => { LAB.arA = e.target.value; render(true); }; $('#arB', bp).onchange = e => { LAB.arB = e.target.value; render(true); };
}

/* ============================================================ STA · Statistics Lab */
const SVARS = { cat: [['q1', 'Age group', L.AGE], ['q2', 'Education', L.EDU], ['q4', 'Employment status', L.STATUS], ['q5', 'Experience', L.EXP], ['tier', 'City tier', L.TIER], ['q7', 'Biggest challenge', L.CHAL], ['q14', 'Skill-gap experience', L.GAPQ], ['q17', 'AI tool usage', L.AIUSE],
  ['q20', 'Platform intent', L.INTENT], ['q22', 'Willingness to pay', L.WTP], ['q23', 'Trust driver', L.TRUST], ['npsCat', 'NPS group', ['Detractor', 'Passive', 'Promoter']], ['aiReady', 'AI readiness', ['Needs awareness', 'Developing', 'AI-ready']], ['sent', 'Feedback sentiment', ['Negative', 'Neutral', 'Positive']], ['km', 'K-Means cluster', Array.from({ length: P.kmK }, (_, k) => 'C' + (k + 1))], ['lca', 'Latent class', LCA_NAMES]],
  num: [['diff', 'Job-search difficulty (Q6)'], ['conf', 'Job confidence (Q10)'], ['ready', 'Industry readiness (Q13)'], ['fam', 'AI familiarity (Q16)'], ['trust', 'AI trust (Q18)'], ['rec', 'Likelihood to recommend (Q24)'], ['ai', 'AI Adoption Index'], ['gap', 'Skill gaps (count)'], ['nSk', 'Skills held (count)'], ['wtp', 'Stated WTP (₹ midpoint)'], ['sal', "Expected salary (₹'000)"], ['expY', 'Experience (yrs)'], ['learn', 'Learning commitment (months)'], ['apps', 'Applications (midpoint)'], ['intv', 'Interviews (midpoint)'], ['prop', 'Paid propensity (model)']] };
let STA = { a: 'q4', b: 'diff' };
function vinfo(k) { const c = SVARS.cat.find(v => v[0] === k); if (c) return { k, t: 'cat', lab: c[1], opts: c[2] }; const n = SVARS.num.find(v => v[0] === k); return { k, t: 'num', lab: n[1] }; }
function autoTest(a, b, ix) {
  const A = vinfo(a), B = vinfo(b);
  if (A.t === 'cat' && B.t === 'cat') { const m = Array.from({ length: A.opts.length }, () => new Array(B.opts.length).fill(0)); for (const i of ix) { const x = D[a][i], y = D[b][i]; if (x >= 0 && y >= 0) m[x][y]++; } const r = chi2test(m); return { ...r, test: 'Pearson χ² test of independence', h0: `${A.lab} and ${B.lab} are independent`, h1: `${A.lab} and ${B.lab} are associated`, tab: m, A, B }; }
  if (A.t === 'num' && B.t === 'num') { const x = [], y = []; for (const i of ix) if (isN(D[a][i]) && isN(D[b][i])) { x.push(D[a][i]); y.push(D[b][i]); } const r = spearman(x, y), rp = pearson(x, y); return { ...r, test: 'Spearman rank correlation', h0: `ρ = 0 (no monotonic association)`, h1: 'ρ ≠ 0', extra: `Pearson r = ${f1(rp?.r, 3)}`, A, B }; }
  const [C, Nm] = A.t === 'cat' ? [A, B] : [B, A]; const groups = C.opts.map((_, k) => { const o = []; for (const i of ix) if (D[C.k][i] === k && isN(D[Nm.k][i])) o.push(D[Nm.k][i]); return o; });
  if (groups.filter(g => g.length >= 2).length === 2) { const g2 = groups.filter(g => g.length >= 2); const r = welch(g2[0], g2[1]); return { ...r, test: "Welch's t-test", h0: `Mean ${Nm.lab} is equal in both groups`, h1: 'Means differ', groups, C, Nm, A, B }; }
  const r = anova(groups), k = kruskal(groups); return { ...r, test: 'One-way ANOVA (F)', h0: `Mean ${Nm.lab} is equal across ${C.lab} groups`, h1: 'At least one group mean differs', extra: k ? `Kruskal–Wallis H = ${f1(k.stat, 1)}, p ${pv(k.p)} (rank-based check)` : '', groups, C, Nm, A, B };
}
function testCard(t, title, caveat) { if (!t || !isFinite(t.stat)) return `<div class="ins"><div class="q">${title}</div><div class="e">Not enough data in this view.</div></div>`;
  const rej = t.p < CFG.alpha; return `<div class="ins"><div class="q">${title}</div><div class="e"><b>H₀:</b> ${esc(t.h0)}<br><b>H₁:</b> ${esc(t.h1)}</div>
  <div class="kv" style="margin:4px 0"><span>Test</span><b>${t.test}</b><span>n</span><b>${fmtN(t.n)}</b><span>Statistic</span><b>${f1(t.stat, 2)}${t.df !== undefined ? ` (df ${typeof t.df === 'number' ? f1(t.df, t.df % 1 ? 1 : 0) : t.df})` : ''}</b><span>p-value</span><b>${pv(t.p)}</b><span>Effect size</span><b>${t.effName} = ${f1(t.effect, 3)} · ${effLabel(t.effName, t.effect)}</b>${t.ci ? `<span>95% CI of difference</span><b>${f1(t.ci[0], 2)} to ${f1(t.ci[1], 2)}</b>` : ''}</div>
  <div class="a" style="font-size:13px">${rej ? `<span class="pill strong">Reject H₀ at α = ${CFG.alpha}</span>` : `<span class="pill">Fail to reject H₀ at α = ${CFG.alpha}</span>`}</div>${t.extra ? `<div class="e">${t.extra}</div>` : ''}${t.lowE ? `<div class="e">${t.lowE} of ${t.cells} cells have expected count < 5.</div>` : ''}<div class="e muted">${caveat}</div></div>`; }
page('stats', 'STA', 'Statistics Lab', 'Statistical Analysis & Significance Testing', 'Descriptive statistics, hypothesis tests with p-values and effect sizes, correlation and cross-tabulation, all recomputed on the current view.', 'prove', c => {
  const ix = Array.from(IX()); if (ix.length < 30) return emptyState(c);
  const ap = panel({ parent: c, span: 12, title: 'Significance level', prov: '', html: `<div class="flex"><div class="seg" id="alp">${[.01, .05, .1].map(a => `<button data-a="${a}" aria-pressed="${CFG.alpha === a}">α = ${a}</button>`).join('')}</div><span class="muted" style="font-size:12px">With n in the thousands, tiny differences become "significant"; read the effect size before the p-value. All tests are on synthetic data and show association, not causation.</span></div>` });
  $$('#alp button', ap).forEach(b => b.onclick = () => { CFG.alpha = +b.dataset.a; saveCfg(); render(true); });
  const cav = 'Synthetic data; association only.';
  const H = [];
  H.push(['H1 · AI tool usage differs by age group', autoTest('q1', 'q17', ix)]);
  { const a = vals(D.ready, sub(ix, i => D.tier[i] === 0)), b = vals(D.ready, sub(ix, i => D.tier[i] > 0)); const t = welch(a, b); if (t) Object.assign(t, { test: "Welch's t-test", h0: 'Mean industry readiness is equal in metro and non-metro cities', h1: 'Means differ', extra: `Metro ${f1(t.ma, 2)} (n ${fmtN(t.na)}) vs non-metro ${f1(t.mb, 2)} (n ${fmtN(t.nb)})` }); H.push(['H2 · Readiness: metro vs Tier 2/3', t]); }
  { const g = L.STATUS.map((_, k) => vals(D.q22.constructor === Int8Array ? fromCode(D.q22) : D.wtp, sub(ix, i => D.q4[i] === k))); const t = kruskal(g); if (t) Object.assign(t, { test: 'Kruskal–Wallis H (ordinal WTP band)', h0: 'Willingness-to-pay bands have the same distribution across employment statuses', h1: 'At least one status differs' }); H.push(['H3 · WTP differs by employment status', t]); }
  { const t = autoTest('q5', 'diff', ix); H.push(['H4 · Job-search difficulty differs by experience', t]); }
  { const m = [[0, 0], [0, 0]]; for (const i of ix) { if (D.q14[i] < 0 || !isN(D.top2[i])) continue; m[D.q14[i] === 0 ? 0 : 1][D.top2[i] ? 0 : 1]++; } const t = chi2test(m); const or = (m[0][0] * m[1][1]) / Math.max(1, m[0][1] * m[1][0]); const se = Math.sqrt(1 / m[0][0] + 1 / m[0][1] + 1 / m[1][0] + 1 / m[1][1]);
    Object.assign(t, { test: 'χ² test (2 × 2)', effName: 'φ', h0: 'Frequent skill-gap experience is unrelated to platform intent', h1: 'They are associated', extra: `Odds ratio ${f1(or, 2)} (95% CI ${f1(Math.exp(Math.log(or) - 1.96 * se), 2)}–${f1(Math.exp(Math.log(or) + 1.96 * se), 2)}): frequent gap-hitters vs others, would use top-2` }); H.push(['H5 · Skill gaps and product intent', t]); }
  { const x = [], y = []; for (const i of ix) if (!(D.flags[i] & 2) && D.apps[i] > 0 && isN(D.intv[i])) { x.push(D.apps[i]); y.push(D.intv[i]); } const t = spearman(x, y);
    const rate = b => { const s = sub(ix, i => D.q8[i] === b && !(D.flags[i] & 2) && isN(D.intv[i])); const a = s.reduce((q, i) => q + D.apps[i], 0); return a ? 10 * s.reduce((q, i) => q + D.intv[i], 0) / a : NaN; };
    if (t) Object.assign(t, { test: 'Spearman rank correlation (applicants only)', h0: 'Among applicants, applications and interviews are not monotonically related', h1: 'ρ ≠ 0', extra: `Interviews per 10 applications: ${f1(rate(1), 1)} at 1–5 apps vs ${f1(rate(5), 1)} at 50+. Volume rises faster than interviews.` }); H.push(['H6 · More applications, more interviews?', t]); }
  { const a = sub(ix, i => D.tier[i] === 0 && D.npsCat[i] >= 0), b = sub(ix, i => D.tier[i] > 0 && D.npsCat[i] >= 0); const t = prop2(a.filter(i => D.npsCat[i] === 2).length, a.length, b.filter(i => D.npsCat[i] === 2).length, b.length);
    Object.assign(t, { test: 'Two-proportion z-test', h0: 'Promoter share is equal in metro and non-metro cities', h1: 'Promoter shares differ', extra: `Metro ${pct(t.p1)} vs non-metro ${pct(t.p2)}` }); H.push(['H7 · Promoter share: metro vs non-metro', t]); }
  panel({ parent: c, span: 12, title: 'Pre-registered hypothesis tests', sub: `Live on ${fmtN(ix.length)} respondents`, prov: 'calc', html: `<div class="insights">${H.map(([t, r]) => testCard(r, t, cav)).join('')}</div>` });
  const all = [...SVARS.cat, ...SVARS.num]; const tr = autoTest(STA.a, STA.b, ix);
  let detail = '';
  if (tr.tab) { const rs = tr.tab.map(r => r.reduce((a, b) => a + b, 0)); detail = `<div class="tw">${tableHTML([tr.A.lab + ' \\ ' + tr.B.lab, ...tr.B.opts, 'n'], tr.tab.map((r, k) => [esc(tr.A.opts[k]), ...r.map(v => `${fmtN(v)} <span class="muted">${pct(v / Math.max(1, rs[k]), 0)}</span>`), rs[k]]), { right: tr.B.opts.map((_, k) => k + 1).concat([tr.B.opts.length + 1]) })}</div><p class="muted" style="font-size:11.5px">Cells show count and row %.</p>`; }
  else if (tr.groups) detail = `<div class="tw">${tableHTML([tr.C.lab, 'n', 'Mean', 'SD', 'Median', '95% CI ±'], tr.C.opts.map((o, k) => { const d = describe(tr.groups[k], tr.groups[k].map((_, q) => q)); return [esc(o), d.n || 0, f1(d.mean, 2), f1(d.sd, 2), f1(d.median, 2), f1(d.ci, 2)]; }))}</div>`;
  const bp = panel({ parent: c, span: 12, title: 'Cross-tab & test builder', sub: 'Pick any two variables; the right test is chosen automatically (χ² for two categories, t-test / ANOVA for number by category, Spearman for two numbers)', prov: 'calc',
    html: `<div class="flex" style="margin-bottom:10px"><select class="inp" id="sa" style="width:auto">${all.map(v => `<option value="${v[0]}" ${STA.a === v[0] ? 'selected' : ''}>${v[1]}</option>`).join('')}</select><span>vs</span><select class="inp" id="sb" style="width:auto">${all.map(v => `<option value="${v[0]}" ${STA.b === v[0] ? 'selected' : ''}>${v[1]}</option>`).join('')}</select>
      <button class="btn sm" data-q="q1,q17">Age × AI adoption</button><button class="btn sm" data-q="q2,ready">Education × readiness</button><button class="btn sm" data-q="q4,q22">Employment × WTP</button><button class="btn sm" data-q="tier,q7">City × challenges</button><button class="btn sm" data-q="gap,q20">Skill gaps × interest</button></div>
      <div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,2fr);gap:14px" class="stb">${testCard(tr, `${tr.A.lab} × ${tr.B.lab}`, cav)}<div style="min-width:0">${detail || '<div class="empty">Correlation between two numeric variables; see the matrix below.</div>'}</div></div>` });
  $('#sa', bp).onchange = e => { STA.a = e.target.value; render(true); }; $('#sb', bp).onchange = e => { STA.b = e.target.value; render(true); };
  $$('[data-q]', bp).forEach(b => b.onclick = () => { [STA.a, STA.b] = b.dataset.q.split(','); if (STA.b === 'q20' && STA.a === 'gap') { STA.a = 'q20'; STA.b = 'gap'; } render(true); });
  const NV = SVARS.num; panel({ parent: c, span: 12, title: 'Descriptive statistics', sub: 'Outliers = values beyond 1.5 × IQR from the quartiles', prov: 'calc', html: `<div class="tw">${tableHTML(['Variable', 'n', 'Missing', 'Mean', 'Median', 'SD', 'Min', 'Q1', 'Q3', 'Max', 'Outliers', '95% CI ±'],
    NV.map(([k, l]) => { const d = describe(D[k], ix); return [l, d.n, d.miss, f1(d.mean, 2), f1(d.median, 2), f1(d.sd, 2), f1(d.min, 1), f1(d.q1, 1), f1(d.q3, 1), f1(d.max, 1), d.out, f1(d.ci, 3)]; }))}</div>` });
  const cv = NV.filter(v => v[0] !== 'prop'); const hd = [];
  const cmat = cv.map(([a]) => cv.map(([b]) => { const x = [], y = []; for (const i of ix) if (isN(D[a][i]) && isN(D[b][i])) { x.push(D[a][i]); y.push(D[b][i]); } return pearson(x, y)?.r ?? NaN; }));
  cmat.forEach((r, y) => r.forEach((v, x) => hd.push([x, y, +v.toFixed(2)])));
  cpanel({ parent: c, span: 12, title: 'Correlation matrix', sub: 'Pearson r, pairwise complete · blue positive, red negative · correlation is not causation', prov: 'calc', h: 'xtall',
    opt: () => heat(cv.map(v => v[1].replace(/ \(.*\)/, '')), cv.map(v => v[1]), hd, { diverging: true, min: -1, max: 1, fmt: v => 'r = ' + v, cell: v => Math.abs(v) >= .1 ? v.toFixed(1) : '', rot: 35 }),
    table: () => ({ head: ['', ...cv.map(v => v[1])], rows: cmat.map((r, k) => [cv[k][1], ...r.map(v => f1(v, 3))]) }) });
});
