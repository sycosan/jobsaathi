'use strict';
/* ============================================================ JobSaathi BI · core engine
   Data layer, filters, statistics, chart + panel helpers, router, exports. */
const P = JSON.parse(document.getElementById('jsdata').textContent);
const L = P.labels, N = P.meta.n;
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = { get(k, d) { try { const v = localStorage.getItem('js.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('js.' + k, JSON.stringify(v)); } catch (e) {} } };

/* ---------------- decode payload */
function dec(s) { const a = new Int8Array(s.length); for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); a[i] = c === 46 ? -1 : (c < 58 ? c - 48 : c - 87); } return a; }
function b64(s) { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
const pop = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
const D = {};
for (const k in P.cols) D[k] = dec(P.cols[k]);
D.q11 = Int16Array.from(P.q11); D.q12 = Int16Array.from(P.q12); D.q19 = Int16Array.from(P.q19);
D.themes = Int16Array.from(P.themes); D.persona = Int16Array.from(P.persona); D.flags = Int8Array.from(P.flags);
D.tier = Int8Array.from(D.q3, c => c < 0 ? -1 : P.tierOfCity[c]);
D.id = Array.from({ length: N }, (_, i) => 'JS-' + String(i + 1).padStart(5, '0'));
const nanArr = () => new Float64Array(N).fill(NaN);
D.nSk = nanArr(); D.nDem = nanArr(); D.gap = nanArr();
for (let i = 0; i < N; i++) if (D.q11[i] >= 0) { D.nSk[i] = pop(D.q11[i]); D.nDem[i] = pop(D.q12[i]); D.gap[i] = pop(D.q12[i] & ~D.q11[i]); }
const fromCode = (col, map) => { const a = nanArr(); for (let i = 0; i < N; i++) if (col[i] >= 0) a[i] = map ? map[col[i]] : col[i]; return a; };
D.diff = fromCode(D.q6); D.conf = fromCode(D.q10); D.ready = fromCode(D.q13); D.fam = fromCode(D.q16); D.trust = fromCode(D.q18); D.rec = fromCode(D.q24);
D.intent = fromCode(D.q20, [4, 3, 2, 1, 0]); D.wtp = fromCode(D.q22, L.WTP_MID); D.paid = fromCode(D.q22, [0, 1, 1, 1, 1, 1]);
D.expY = fromCode(D.q5, L.EXP_YRS); D.learn = fromCode(D.q15, L.LEARN_MO); D.apps = fromCode(D.q8, L.APPS_MID); D.intv = fromCode(D.q9, L.INTV_MID);
D.use = fromCode(D.q17, [3, 2, 1, 0]); D.top2 = fromCode(D.q20, [1, 1, 0, 0, 0]);
D.sal = Float64Array.from(P.sal, v => v == null ? NaN : v); D.prop = Float64Array.from(P.prop, v => v / 1000);
D.npsCat = Int8Array.from(D.q24, v => v < 0 ? -1 : v >= 9 ? 2 : v >= 7 ? 1 : 0);
D.dq = Int8Array.from({ length: N }, (_, i) => (D.flags[i] & 31) ? 2 : 0);
{ const core = ['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7', 'q8', 'q9', 'q10', 'q13', 'q14', 'q15', 'q16', 'q17', 'q18', 'q20', 'q21', 'q22', 'q23', 'q24'];
  D.nMiss = new Int8Array(N);
  for (let i = 0; i < N; i++) { let m = 0; for (const c of core) if (D[c][i] < 0) m++; if (D.q11[i] < 0) m += 2; if (P.texts[P.text[i]] === '') m++; D.nMiss[i] = m; if (D.dq[i] === 0 && (m > 0 || (D.flags[i] & 32))) D.dq[i] = 1; } }
const LCA_C = P.lca.C; const LCAP = (() => { const u = b64(P.lcaPost), f = new Float32Array(u.length); for (let i = 0; i < u.length; i++) f[i] = u[i] / 250; return f; })();
const KMZ = (() => { const u = new Int8Array(b64(P.kmZ).buffer), f = new Float32Array(u.length); for (let i = 0; i < u.length; i++) f[i] = u[i] / 25; return f; })();
const KMD = P.kmF.length;
const CLZ = (() => { const u = new Int8Array(b64(P.clfZ).buffer), f = new Float32Array(u.length); for (let i = 0; i < u.length; i++) f[i] = u[i] / 20; return f; })();
const CLD = P.clfF.length;
const LCA_NAMES = ['Urgent job seekers', 'Settled professionals', 'Free-only explorers', 'Paying career climbers'];
const PERSONA = P.personas.map(p => p.name);
const WTP_S = ['Free', '₹99–199', '₹200–499', '₹500–999', '₹1k–2k', '₹2k+'];
const EDU_S = ['Class 10', 'Class 12', 'Diploma', 'Undergraduate', 'Postgraduate', 'Prof. certification', 'Other'];
const FEAT_MAP = [[0], [3, 7], [4], [5], [6], [2], [8, 1]]; // Q21 feature -> Q19 items
const FLAGS = ['Inconsistent age/experience', 'Inconsistent applications/interviews', 'Straight-liner', 'Speeder (< 120 s)', 'Possible duplicate', 'Invalid code corrected'];

/* ---------------- configuration (per viewer) */
const CFG = Object.assign({ theme: 'system', numfmt: 'in', aiW: [35, 35, 30], haircut: 60, minN: 80, alpha: 0.05,
  ex: { dup: false, speeder: false, inconsistent: false, straight: false },
  w: { need: 25, size: 15, interest: 20, wtp: 20, feas: 10, evid: 10 } }, store.get('cfg', {}));
const saveCfg = () => store.set('cfg', CFG);
function computeAI() {
  const w = CFG.aiW.map(Number), sw = w[0] + w[1] + w[2] || 1; D.ai = nanArr();
  for (let i = 0; i < N; i++) {
    const c = [D.fam[i] >= 1 ? (D.fam[i] - 1) / 4 : NaN, D.use[i] / 3, D.trust[i] >= 1 ? (D.trust[i] - 1) / 4 : NaN];
    let s = 0, ws = 0, k = 0; for (let j = 0; j < 3; j++) if (!isNaN(c[j])) { s += c[j] * w[j]; ws += w[j]; k++; }
    if (k >= 2 && ws > 0) D.ai[i] = 100 * s / ws;
  }
  D.aiReady = Int8Array.from(D.ai, v => isNaN(v) ? -1 : v >= 65 ? 2 : v >= 40 ? 1 : 0);
}
computeAI();

/* ---------------- filters */
const S15 = lo => ['1' + lo, '2', '3', '4', '5'];
const FDEF = [
  { k: 'q1', lab: 'Age', opts: L.AGE }, { k: 'q2', lab: 'Education', opts: L.EDU }, { k: 'q4', lab: 'Employment', opts: L.STATUS },
  { k: 'q5', lab: 'Experience', opts: L.EXP }, { k: 'tier', lab: 'City tier', opts: L.TIER }, { k: 'q3', lab: 'City', opts: L.CITY },
  { k: 'q6', lab: 'Job-search difficulty', opts: ['1 · Very easy', '2', '3', '4', '5 · Extremely difficult'], base: 1 },
  { k: 'q13', lab: 'Industry readiness', opts: ['1 · Low', '2', '3', '4', '5 · High'], base: 1 },
  { k: 'q16', lab: 'AI familiarity', opts: ['1 · Not familiar', '2', '3', '4', '5 · Very familiar'], base: 1 },
  { k: 'q20', lab: 'Product interest', opts: L.INTENT }, { k: 'q22', lab: 'Willingness to pay', opts: L.WTP },
  { k: 'q19', lab: 'Feature interest', opts: L.FEAT19, mask: true }, { k: 'persona', lab: 'Persona', opts: PERSONA, mask: true },
];
const F = {}; FDEF.forEach(d => F[d.k] = new Set());
const PRESETS = [
  { name: 'Unemployed graduates 22–30 in Tier 2/3, low readiness, want AI career guidance', f: { q4: [3, 4], q2: [3, 4], q1: [1, 2], tier: [1, 2], q13: [1, 2], q19: [0] } },
  { name: 'Freshers in Tier 2/3 cities', f: { q4: [1], tier: [1, 2] } },
  { name: 'Career switchers who would definitely use JobSaathi', f: { q4: [6], q20: [0] } },
  { name: 'AI-familiar respondents (4–5) willing to pay', f: { q16: [4, 5], q22: [1, 2, 3, 4, 5] } },
  { name: 'Experienced (5+ yrs) and not AI-familiar', f: { q5: [4, 5], q16: [1, 2] } },
  { name: 'Students and freshers, free-only', f: { q4: [0, 1], q22: [0] } },
];
function passEx(i) {
  const f = D.flags[i];
  if (CFG.ex.dup && (f & 16)) return false; if (CFG.ex.speeder && (f & 8)) return false;
  if (CFG.ex.inconsistent && (f & 3)) return false; if (CFG.ex.straight && (f & 4)) return false; return true;
}
let _memo = { key: null, base: null, idx: null };
function fkey() { return JSON.stringify([FDEF.map(d => [...F[d.k]].sort()), CFG.ex]); }
function getIdx() {
  const k = fkey(); if (_memo.key === k) return _memo;
  const base = [], idx = []; const act = FDEF.filter(d => F[d.k].size);
  for (let i = 0; i < N; i++) {
    if (!passEx(i)) continue; base.push(i);
    let ok = true;
    for (const d of act) {
      const s = F[d.k];
      if (d.mask) { let any = false; for (const b of s) if (D[d.k][i] >= 0 && (D[d.k][i] >> b & 1)) { any = true; break; } if (!any) { ok = false; break; } }
      else { const v = D[d.k][i]; if (v < 0 || !s.has(v - (d.base || 0))) { ok = false; break; } }
    }
    if (ok) idx.push(i);
  }
  _memo = { key: k, base: Uint32Array.from(base), idx: Uint32Array.from(idx) }; return _memo;
}
const IX = () => getIdx().idx, BASE = () => getIdx().base;
function filterSentence() {
  const act = FDEF.filter(d => F[d.k].size); if (!act.length) return 'All respondents';
  return act.map(d => `<b>${esc(d.lab)}</b>: ${[...F[d.k]].sort((a, b) => a - b).map(v => esc(d.opts[v])).join(' or ')}`).join(' · ');
}

/* ---------------- stats */
const isN = v => v === v; // not NaN
function sub(ix, fn) { const o = []; for (const i of ix) if (fn(i)) o.push(i); return o; }
function mean(a, ix) { let s = 0, n = 0; for (const i of ix) { const v = a[i]; if (v === v) { s += v; n++; } } return n ? s / n : NaN; }
function nValid(a, ix) { let n = 0; for (const i of ix) if (a[i] === a[i] && a[i] !== -1) n++; return n; }
function vals(a, ix) { const o = []; for (const i of ix) { const v = a[i]; if (v === v) o.push(v); } return o; }
function quant(sorted, q) { if (!sorted.length) return NaN; const p = (sorted.length - 1) * q, lo = Math.floor(p), hi = Math.ceil(p); return sorted[lo] + (sorted[hi] - sorted[lo]) * (p - lo); }
function describe(a, ix) {
  const v = vals(a, ix).sort((x, y) => x - y), n = v.length; if (!n) return { n: 0 };
  const m = v.reduce((s, x) => s + x, 0) / n, sd = Math.sqrt(v.reduce((s, x) => s + (x - m) ** 2, 0) / Math.max(1, n - 1));
  const q1 = quant(v, .25), q3 = quant(v, .75), iqr = q3 - q1, lo = q1 - 1.5 * iqr, hi = q3 + 1.5 * iqr;
  return { n, miss: ix.length - n, mean: m, median: quant(v, .5), sd, min: v[0], max: v[n - 1], q1, q3, out: v.filter(x => x < lo || x > hi).length, ci: 1.96 * sd / Math.sqrt(n) };
}
function freq(col, ix, k) { const c = new Array(k).fill(0); let miss = 0; for (const i of ix) { const v = col[i]; if (v >= 0 && v < k) c[v]++; else miss++; } return { c, n: ix.length - miss, miss }; }
function freqBase(col, ix, k, base) { const c = new Array(k).fill(0); let miss = 0; for (const i of ix) { const v = col[i] - base; if (col[i] >= 0 && v >= 0 && v < k) c[v]++; else miss++; } return { c, n: ix.length - miss, miss }; }
function mfreq(col, ix, k) { const c = new Array(k).fill(0); let n = 0; for (const i of ix) { const v = col[i]; if (v < 0) continue; n++; for (let b = 0; b < k; b++) if (v >> b & 1) c[b]++; } return { c, n }; }
function share(ix, fn) { let n = 0, y = 0; for (const i of ix) { const r = fn(i); if (r === null || r === undefined) continue; n++; if (r) y++; } return { n, y, p: n ? y / n : NaN }; }
function wilson(y, n, z = 1.96) { if (!n) return [NaN, NaN]; const p = y / n, d = 1 + z * z / n, c = p + z * z / (2 * n), m = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)); return [(c - m) / d, (c + m) / d]; }
function nps(ix) {
  let P_ = 0, Pa = 0, De = 0; for (const i of ix) { const c = D.npsCat[i]; if (c === 2) P_++; else if (c === 1) Pa++; else if (c === 0) De++; }
  const n = P_ + Pa + De; if (!n) return { n: 0, nps: NaN };
  const pp = P_ / n, pd = De / n, v = (pp + pd - (pp - pd) ** 2) / n;
  return { n, P: P_, Pa, De, pp, pa: Pa / n, pd, nps: 100 * (pp - pd), ci: 196 * Math.sqrt(v) };
}
function argmax(a) { let b = 0; for (let i = 1; i < a.length; i++) if (a[i] > a[b]) b = i; return b; }
function ranks(arr) { const o = arr.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]); const r = new Array(arr.length); let i = 0; while (i < o.length) { let j = i; while (j + 1 < o.length && o[j + 1][0] === o[i][0]) j++; const rk = (i + j) / 2 + 1; for (let k = i; k <= j; k++) r[o[k][1]] = rk; i = j + 1; } return r; }
// special functions
function lgamma(x) { const g = 7, c = [0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7];
  if (x < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * x)) - lgamma(1 - x); x -= 1; let a = c[0]; const t = x + g + 0.5; for (let i = 1; i < 9; i++) a += c[i] / (x + i); return 0.5 * Math.log(2 * Math.PI) + (x + 0.5) * Math.log(t) - t + Math.log(a); }
function gammaQ(a, x) { // upper regularized
  if (x <= 0) return 1; if (x < a + 1) { let s = 1 / a, t = s; for (let n = 1; n < 500; n++) { t *= x / (a + n); s += t; if (Math.abs(t) < Math.abs(s) * 1e-14) break; } return 1 - s * Math.exp(-x + a * Math.log(x) - lgamma(a)); }
  let b = x + 1 - a, c = 1e300, d = 1 / b, h = d; for (let i = 1; i < 500; i++) { const an = -i * (i - a); b += 2; d = an * d + b; if (Math.abs(d) < 1e-300) d = 1e-300; c = b + an / c; if (Math.abs(c) < 1e-300) c = 1e-300; d = 1 / d; const del = d * c; h *= del; if (Math.abs(del - 1) < 1e-14) break; }
  return Math.exp(-x + a * Math.log(x) - lgamma(a)) * h; }
function betacf(a, b, x) { let qab = a + b, qap = a + 1, qam = a - 1, c = 1, d = 1 - qab * x / qap; if (Math.abs(d) < 1e-300) d = 1e-300; d = 1 / d; let h = d;
  for (let m = 1; m < 300; m++) { const m2 = 2 * m; let aa = m * (b - m) * x / ((qam + m2) * (a + m2)); d = 1 + aa * d; if (Math.abs(d) < 1e-300) d = 1e-300; c = 1 + aa / c; if (Math.abs(c) < 1e-300) c = 1e-300; d = 1 / d; h *= d * c;
    aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2)); d = 1 + aa * d; if (Math.abs(d) < 1e-300) d = 1e-300; c = 1 + aa / c; if (Math.abs(c) < 1e-300) c = 1e-300; d = 1 / d; const del = d * c; h *= del; if (Math.abs(del - 1) < 1e-13) break; } return h; }
function ibeta(x, a, b) { if (x <= 0) return 0; if (x >= 1) return 1; const bt = Math.exp(lgamma(a + b) - lgamma(a) - lgamma(b) + a * Math.log(x) + b * Math.log(1 - x));
  return x < (a + 1) / (a + b + 2) ? bt * betacf(a, b, x) / a : 1 - bt * betacf(b, a, 1 - x) / b; }
const chi2sf = (x, df) => gammaQ(df / 2, x / 2);
const tsf2 = (t, df) => ibeta(df / (df + t * t), df / 2, 0.5); // two-sided
const fsf = (f, d1, d2) => f <= 0 ? 1 : ibeta(d2 / (d2 + d1 * f), d2 / 2, d1 / 2);
const normsf2 = z => { const t = 1 / (1 + 0.2316419 * Math.abs(z)), d = 0.3989423 * Math.exp(-z * z / 2); const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274)))); return 2 * p; };
function chi2test(tab) { // tab: rows x cols counts
  const R = tab.length, C = tab[0].length, rs = tab.map(r => r.reduce((a, b) => a + b, 0)), cs = Array.from({ length: C }, (_, j) => tab.reduce((a, r) => a + r[j], 0)), n = rs.reduce((a, b) => a + b, 0);
  let x2 = 0, rr = 0, cc = 0, lowE = 0; const ri = rs.map(v => v > 0), ci = cs.map(v => v > 0);
  for (let i = 0; i < R; i++) if (ri[i]) for (let j = 0; j < C; j++) if (ci[j]) { const e = rs[i] * cs[j] / n; if (e < 5) lowE++; x2 += (tab[i][j] - e) ** 2 / e; }
  rr = ri.filter(Boolean).length; cc = ci.filter(Boolean).length; const df = (rr - 1) * (cc - 1);
  const v = Math.sqrt(x2 / (n * Math.max(1, Math.min(rr, cc) - 1)));
  return { stat: x2, df, p: df > 0 ? chi2sf(x2, df) : NaN, n, effect: v, effName: "Cramér's V", lowE, cells: rr * cc };
}
function welch(a, b) { const da = describe(a, a.map((_, i) => i)), db = describe(b, b.map((_, i) => i)); if (da.n < 2 || db.n < 2) return null;
  const va = da.sd ** 2 / da.n, vb = db.sd ** 2 / db.n, t = (da.mean - db.mean) / Math.sqrt(va + vb), df = (va + vb) ** 2 / (va * va / (da.n - 1) + vb * vb / (db.n - 1));
  const sp = Math.sqrt(((da.n - 1) * da.sd ** 2 + (db.n - 1) * db.sd ** 2) / (da.n + db.n - 2)); const diff = da.mean - db.mean, se = Math.sqrt(va + vb);
  return { stat: t, df, p: tsf2(t, df), effect: diff / sp, effName: "Cohen's d", ma: da.mean, mb: db.mean, na: da.n, nb: db.n, n: da.n + db.n, ci: [diff - 1.96 * se, diff + 1.96 * se], diff }; }
function anova(groups) { const g = groups.filter(x => x.length >= 2); if (g.length < 2) return null; const all = g.flat(), n = all.length, gm = all.reduce((a, b) => a + b, 0) / n;
  let ssb = 0, ssw = 0; for (const x of g) { const m = x.reduce((a, b) => a + b, 0) / x.length; ssb += x.length * (m - gm) ** 2; for (const v of x) ssw += (v - m) ** 2; }
  const d1 = g.length - 1, d2 = n - g.length, f = (ssb / d1) / (ssw / d2); return { stat: f, df: `${d1}, ${d2}`, p: fsf(f, d1, d2), effect: ssb / (ssb + ssw), effName: 'η²', n }; }
function kruskal(groups) { const g = groups.filter(x => x.length >= 1); if (g.length < 2) return null; const all = g.flat(), n = all.length, r = ranks(all); let off = 0, H = 0;
  for (const x of g) { let s = 0; for (let i = 0; i < x.length; i++) s += r[off + i]; off += x.length; H += s * s / x.length; } H = 12 / (n * (n + 1)) * H - 3 * (n + 1);
  // tie correction
  const cnt = {}; for (const v of all) cnt[v] = (cnt[v] || 0) + 1; let T = 0; for (const k in cnt) T += cnt[k] ** 3 - cnt[k]; const C = 1 - T / (n ** 3 - n); if (C > 0) H /= C;
  return { stat: H, df: g.length - 1, p: chi2sf(H, g.length - 1), effect: (H - g.length + 1) / (n - g.length), effName: 'ε²', n }; }
function pearson(x, y) { const n = x.length; if (n < 3) return null; const mx = x.reduce((a, b) => a + b, 0) / n, my = y.reduce((a, b) => a + b, 0) / n; let sxy = 0, sx = 0, sy = 0;
  for (let i = 0; i < n; i++) { const a = x[i] - mx, b = y[i] - my; sxy += a * b; sx += a * a; sy += b * b; } const r = sxy / Math.sqrt(sx * sy); const t = r * Math.sqrt((n - 2) / Math.max(1e-12, 1 - r * r));
  return { r, stat: t, df: n - 2, p: tsf2(t, n - 2), n, effect: r, effName: 'r' }; }
function spearman(x, y) { const o = pearson(ranks(x), ranks(y)); if (o) { o.effName = 'ρ'; } return o; }
function prop2(y1, n1, y2, n2) { const p1 = y1 / n1, p2 = y2 / n2, p = (y1 + y2) / (n1 + n2), z = (p1 - p2) / Math.sqrt(p * (1 - p) * (1 / n1 + 1 / n2));
  const h = 2 * Math.asin(Math.sqrt(p1)) - 2 * Math.asin(Math.sqrt(p2)); return { stat: z, df: '–', p: normsf2(z), effect: h, effName: "Cohen's h", n: n1 + n2, p1, p2 }; }
function effLabel(name, e) { const a = Math.abs(e);
  if (name === "Cramér's V" || name === 'φ' || name === 'r' || name === 'ρ') return a < .1 ? 'negligible' : a < .3 ? 'small' : a < .5 ? 'medium' : 'large';
  if (name === "Cohen's d" || name === "Cohen's h") return a < .2 ? 'negligible' : a < .5 ? 'small' : a < .8 ? 'medium' : 'large';
  if (name === 'η²' || name === 'ε²') return a < .01 ? 'negligible' : a < .06 ? 'small' : a < .14 ? 'medium' : 'large'; return ''; }
function evidence(n, extra = 1) { // Strong / Moderate / Limited based on sample size and margin
  const s = n * extra; return s >= 400 ? 'strong' : s >= CFG.minN ? 'moderate' : 'limited'; }
const EVL = { strong: 'Strong evidence', moderate: 'Moderate evidence', limited: 'Limited evidence' };
const evPill = e => `<span class="pill ${e}">${e === 'strong' ? '●●●' : e === 'moderate' ? '●●○' : '●○○'} ${EVL[e]}</span>`;

/* ---------------- formatting */
const fmtN = v => !isFinite(v) ? '–' : Math.round(v).toLocaleString(CFG.numfmt === 'in' ? 'en-IN' : 'en-US');
const pct = (v, d = 1) => !isFinite(v) ? '–' : (v * 100).toFixed(d) + '%';
const f1 = (v, d = 1) => !isFinite(v) ? '–' : (+v).toFixed(d);
const pv = p => !isFinite(p) ? '–' : p < 0.001 ? '< 0.001' : p.toFixed(3);
function inr(v, compact = true) {
  if (!isFinite(v)) return '–'; const s = v < 0 ? '−' : ''; v = Math.abs(v);
  if (CFG.numfmt === 'in') { if (compact && v >= 1e7) return s + '₹' + (v / 1e7).toFixed(2) + ' Cr'; if (compact && v >= 1e5) return s + '₹' + (v / 1e5).toFixed(2) + ' L'; return s + '₹' + Math.round(v).toLocaleString('en-IN'); }
  if (compact && v >= 1e6) return s + '₹' + (v / 1e6).toFixed(2) + 'M'; if (compact && v >= 1e4) return s + '₹' + (v / 1e3).toFixed(1) + 'K'; return s + '₹' + Math.round(v).toLocaleString('en-US');
}
const pp = v => !isFinite(v) ? '–' : (v > 0 ? '+' : '') + v.toFixed(1) + ' pp';

/* ---------------- theme + colors */
function cssv(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
let TC = {};
function readColors() { TC = {}; ['bg', 'panel', 'panel-2', 'ink', 'ink-2', 'muted', 'line', 'line-2', 'navy', 'teal', 'teal-fill', 'teal-soft', 'amber', 'good', 'warn', 'serious', 'crit', 'div-neg', 'div-mid', 'div-pos', 'seq-lo', 'seq-hi', 'c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8'].forEach(k => TC[k] = cssv('--' + k)); TC.cat = [1, 2, 3, 4, 5, 6, 7, 8].map(i => TC['c' + i]); }
function applyTheme() { const r = document.documentElement; if (CFG.theme === 'system') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', CFG.theme); readColors(); }
function mix(a, b, t) { const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); const A = p(a), B = p(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); }
const seq = t => mix(TC['seq-lo'], TC['seq-hi'], Math.max(0, Math.min(1, t)));
const div = t => t < 0 ? mix(TC['div-mid'], TC['div-neg'], Math.min(1, -t)) : mix(TC['div-mid'], TC['div-pos'], Math.min(1, t));
const ordRamp = k => Array.from({ length: k }, (_, i) => mix(mix(TC['seq-lo'], TC['seq-hi'], .28), TC['seq-hi'], i / Math.max(1, k - 1)));
const likert5 = () => [mix(TC['div-mid'], TC['div-neg'], .95), mix(TC['div-mid'], TC['div-neg'], .5), TC['div-mid'], mix(TC['div-mid'], TC['div-pos'], .5), mix(TC['div-mid'], TC['div-pos'], .95)];

/* ---------------- charts */
const CHARTS = []; const RO = new ResizeObserver(es => es.forEach(e => { const c = echarts.getInstanceByDom(e.target); if (c) c.resize(); }));
function disposeCharts() { while (CHARTS.length) { const c = CHARTS.pop(); try { RO.unobserve(c.getDom()); c.dispose(); } catch (e) {} } }
function baseOpt(o) {
  const t = { fontFamily: 'IBM Plex Sans, Segoe UI, sans-serif', color: TC['ink-2'], fontSize: 11.5 };
  return Object.assign({ textStyle: t, animationDuration: 260, grid: { left: 8, right: 22, top: 28, bottom: 8, containLabel: true },
    tooltip: { trigger: 'item', confine: true, backgroundColor: TC.panel, borderColor: TC.line, textStyle: { color: TC.ink, fontSize: 12, fontFamily: t.fontFamily }, extraCssText: 'box-shadow:0 6px 18px rgba(0,0,0,.15);border-radius:6px;' } }, o);
}
const axC = () => ({ axisLine: { lineStyle: { color: TC.line } }, axisTick: { show: false }, axisLabel: { color: TC['ink-2'], fontSize: 11 }, splitLine: { lineStyle: { color: TC['line-2'] } } });
const catAx = (data, o = {}) => Object.assign({ type: 'category', data, ...axC(), splitLine: { show: false } }, o);
const valAx = (o = {}) => Object.assign({ type: 'value', ...axC(), axisLine: { show: false } }, o);
function mount(el, opt, onClick) { const c = echarts.init(el, null, { renderer: 'canvas' }); c.setOption(baseOpt(opt)); if (onClick) { c.on('click', onClick); el.style.cursor = 'pointer'; } CHARTS.push(c); RO.observe(el); return c; }
const labW = (labels, max = 160) => Math.min(max, Math.max(30, ...labels.map(s => String(s).length * 6.4)));
const niceStep = r => { const p = Math.pow(10, Math.floor(Math.log10(r || 1))), m = r / p; return (m < 2 ? .2 : m < 5 ? .5 : 1) * p; };
const padAx = (lo = .1, hi = .25) => ({ min: v => { const st = niceStep(v.max - v.min), x = Math.floor((v.min - (v.max - v.min) * lo) / st) * st; return v.min >= 0 ? Math.max(0, x) : x; }, max: v => { const st = niceStep(v.max - v.min); return Math.ceil((v.max + (v.max - v.min) * hi) / st) * st; } });
function legendHTML(items) { return `<div class="legend">${items.map(([c, l]) => `<span><i class="dot" style="background:${c}"></i>${esc(l)}</span>`).join('')}</div>`; }

/* ---------------- panels */
const PROV = { raw: 'Raw data', clean: 'Cleaned data', calc: 'Calculated', model: 'Model output', inferred: 'Inferred', projection: 'Projection' };
const provChip = p => p ? `<span class="prov ${p}" title="${PROV[p]}">${p === 'calc' ? 'Calculated' : p === 'model' ? 'Model' : p === 'inferred' ? 'Inferred' : p === 'projection' ? 'Projection' : p}</span>` : '';
function panel(o) {
  const s = document.createElement('section'); s.className = 'panel s' + (o.span || 6); if (o.id) s.id = o.id;
  s.innerHTML = `<div class="ph"><h3>${o.title}${o.sub ? `<small>${o.sub}</small>` : ''}</h3><div class="ptools">${o.tools || ''}${provChip(o.prov ?? 'calc')}</div></div><div class="pb">${o.html || ''}</div>${o.foot ? `<div class="pf">${o.foot}</div>` : ''}`;
  if (o.parent) o.parent.appendChild(s); return s;
}
/** chart panel with Table toggle + PNG export. o.opt(): ECharts option; o.table(): {head:[], rows:[[]]} */
function cpanel(o) {
  const s = panel({ ...o, tools: `<button class="icon-btn" data-act="tbl" aria-pressed="false" title="Show the numbers as a table">Table</button><button class="icon-btn" data-act="png" title="Save chart as PNG">PNG</button>` });
  const pb = $('.pb', s); pb.innerHTML = (o.pre || '') + `<div class="chart ${o.h || ''}"></div><div class="tw" hidden></div>` + (o.post || '');
  const el = $('.chart', pb), tw = $('.tw', pb);
  const c = mount(el, o.opt(), o.click ? p => o.click(p) : null);
  $('[data-act=tbl]', s).onclick = e => { const on = e.currentTarget.getAttribute('aria-pressed') !== 'true'; e.currentTarget.setAttribute('aria-pressed', on); el.hidden = on; tw.hidden = !on;
    if (on) { const t = o.table ? o.table() : null; tw.innerHTML = t ? tableHTML(t.head, t.rows) : '<div class="empty">No table view</div>'; } else c.resize(); };
  $('[data-act=png]', s).onclick = () => savePNG(c, (o.file || o.title).replace(/<[^>]+>/g, ''));
  s._chart = c; return s;
}
function tableHTML(head, rows, opt = {}) {
  return `<table class="t">${head ? `<thead><tr>${head.map((h, j) => `<th class="${opt.right?.includes(j) || (j > 0 && opt.autoRight !== false && typeof rows[0]?.[j] !== 'string') ? 'r' : ''}">${h}</th>`).join('')}</tr></thead>` : ''}<tbody>${rows.map(r => `<tr>${r.map((v, j) => `<td class="${(opt.right?.includes(j) || (j > 0 && opt.autoRight !== false && typeof v !== 'string')) ? 'r' : ''}">${typeof v === 'number' ? (Number.isInteger(v) ? fmtN(v) : f1(v, 2)) : v}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
}
function kpi(o) { // {l, v, s, trace:{f, num, den, note}, hero}
  const d = document.createElement('div'); d.className = 'kpi' + (o.hero ? ' hero' : '');
  d.innerHTML = `<div class="l">${o.l}</div><div class="v">${o.v}</div><div class="s">${o.s || ''}</div>${o.trace ? '<button class="icon-btn tr" title="Show how this is calculated" aria-label="Show calculation">ƒx</button>' : ''}`;
  if (o.trace) $('.tr', d).onclick = e => showTrace(e.currentTarget, o.l, o.trace);
  return d;
}
function kpiRow(parent, items) { const w = document.createElement('div'); w.className = 's12 kpis'; items.forEach(k => w.appendChild(kpi(k))); parent.appendChild(w); return w; }
function showTrace(anchor, label, t) {
  openPop(anchor, `<div class="trace-pop"><div class="pophead"><span>${label}</span></div><div>${t.f}</div>${t.code ? `<code>${esc(t.code)}</code>` : ''}<div class="kv" style="margin-top:6px">${(t.rows || []).map(([a, b]) => `<span>${a}</span><b>${b}</b>`).join('')}</div>${t.note ? `<p class="muted" style="margin:8px 0 0">${t.note}</p>` : ''}</div>`);
}
let _pop = null;
function closePop() { if (_pop) { _pop.remove(); _pop = null; } }
function openPop(anchor, html) {
  closePop(); const p = document.createElement('div'); p.className = 'pop'; p.innerHTML = html; document.body.appendChild(p);
  const r = anchor.getBoundingClientRect(), w = p.offsetWidth; let x = Math.min(r.left, innerWidth - w - 16), y = r.bottom + 6; if (y + p.offsetHeight > innerHeight - 10) y = Math.max(10, r.top - p.offsetHeight - 6);
  p.style.left = Math.max(16, x) + 'px'; p.style.top = y + 'px'; _pop = p; setTimeout(() => document.addEventListener('mousedown', outside, { once: false }), 0);
  function outside(e) { if (_pop && !_pop.contains(e.target) && e.target !== anchor) { closePop(); document.removeEventListener('mousedown', outside); } }
  return p;
}
function toast(msg, ms = 2600) { const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), ms); }

/* ---------------- drawer + drill-down */
function drawer(title, html, sub = '') {
  closeDrawer(); const sc = document.createElement('div'); sc.className = 'scrim'; sc.onclick = closeDrawer;
  const d = document.createElement('aside'); d.className = 'drawer'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-label', title);
  d.innerHTML = `<header><h3>${title}${sub ? `<small class="muted" style="display:block;font:400 12px var(--f-body);margin-top:3px">${sub}</small>` : ''}</h3><button class="btn sm" data-x>Close</button></header><div class="body">${html}</div>`;
  document.body.append(sc, d); requestAnimationFrame(() => d.classList.add('open')); $('[data-x]', d).onclick = closeDrawer; return d;
}
function closeDrawer() { $$('.drawer,.scrim').forEach(e => e.remove()); }
function profile(ix) {
  const n = ix.length; const ch = freq(D.q7, ix, 9), f21 = freq(D.q21, ix, 7), g = mfreq(D.q12, ix, 12), h = mfreq(D.q11, ix, 12);
  const gapPP = g.c.map((v, j) => g.n ? (v - h.c[j]) / g.n : NaN), ns = nps(ix), pd = share(ix, i => isN(D.paid[i]) ? D.paid[i] : null);
  const payers = vals(D.wtp, ix).filter(v => v > 0).sort((a, b) => a - b);
  return { n, diff: mean(D.diff, ix), ready: mean(D.ready, ix), conf: mean(D.conf, ix), ai: mean(D.ai, ix), top2: share(ix, i => isN(D.top2[i]) ? D.top2[i] : null), paid: pd,
    nps: ns, gap: mean(D.gap, ix), wtp: mean(D.wtp, ix), wtpPayers: quant(payers, .5), topChal: argmax(ch.c), topChalP: ch.n ? ch.c[argmax(ch.c)] / ch.n : NaN,
    topF: argmax(f21.c), topFP: f21.n ? f21.c[argmax(f21.c)] / f21.n : NaN, topGap: argmax(gapPP), topGapPP: gapPP[argmax(gapPP)] * 100,
    gapFreq: share(ix, i => D.q14[i] >= 0 ? D.q14[i] === 0 : null), hard: share(ix, i => isN(D.diff[i]) ? D.diff[i] >= 4 : null) };
}
function profileHTML(pr, tot) {
  const d = (a, b, f = 1) => isFinite(a) && isFinite(b) ? `<small class="muted"> (${a - b >= 0 ? '+' : ''}${(a - b).toFixed(f)})</small>` : '';
  return `<div class="kv">
    <span>Respondents</span><b>${fmtN(pr.n)} ${tot ? `<small class="muted">(${pct(pr.n / tot)} of view)</small>` : ''}</b>
    <span>Avg job-search difficulty (1–5)</span><b>${f1(pr.diff, 2)}</b>
    <span>Avg industry readiness (1–5)</span><b>${f1(pr.ready, 2)}</b>
    <span>AI Adoption Index (0–100)</span><b>${f1(pr.ai)}</b>
    <span>Would use JobSaathi (top-2)</span><b>${pct(pr.top2.p)}</b>
    <span>Willing to pay ≥ ₹99/month</span><b>${pct(pr.paid.p)}</b>
    <span>Median stated WTP (payers)</span><b>${inr(pr.wtpPayers)}</b>
    <span>NPS (n = ${fmtN(pr.nps.n)})</span><b>${f1(pr.nps.nps)}</b>
    <span>Top challenge</span><b>${esc(L.CHAL[pr.topChal])} · ${pct(pr.topChalP, 0)}</b>
    <span>Most valued feature</span><b>${esc(L.FEAT21[pr.topF])} · ${pct(pr.topFP, 0)}</b>
    <span>Largest perceived skill gap</span><b>${esc(L.SKILLS[pr.topGap])} · ${pp(pr.topGapPP)}</b></div>`;
}
/** Drill-down: open the segment behind a clicked chart category */
function drill(field, code, label) {
  const ix = IX(); const dd = FDEF.find(d => d.k === field);
  const seg = dd?.mask ? sub(ix, i => D[field][i] >= 0 && (D[field][i] >> code & 1)) : sub(ix, i => D[field][i] === code + (dd?.base || 0));
  const pr = profile(seg); const tot = ix.length;
  const d = drawer(esc(label), `${profileHTML(pr, tot)}
    <div class="note info">Segment = current view (${fmtN(tot)} respondents) where <b>${esc(dd?.lab || field)}</b> = ${esc(label)}. ${pr.n < CFG.minN ? `<b>n is below ${CFG.minN}</b>; treat as directional.` : ''}</div>
    <div class="flex">${dd ? '<button class="btn pri" data-apply>Apply as filter</button>' : ''}<button class="btn" data-ex>Open in Data Explorer</button></div>`, 'Drill-down · ' + (dd?.lab || field));
  if (dd) $('[data-apply]', d).onclick = () => { F[field].add(code); closeDrawer(); refresh(); };
  $('[data-ex]', d).onclick = () => { if (dd) F[field].add(code); closeDrawer(); go('explorer'); };
}

/* ---------------- downloads */
let _dl; async function dlcap() { if (_dl !== undefined) return _dl; try { _dl = window.claude?.use ? await window.claude.use('downloads') : null; } catch (e) { _dl = null; } return _dl; }
async function saveFile(filename, data) {
  const dl = await dlcap();
  if (!dl) {
    if (!window.claude) { // standalone hosting (GitHub Pages, local file): plain browser download
      try { const ext = filename.split('.').pop(), mime = { csv: 'text/csv', html: 'text/html', pdf: 'application/pdf', png: 'image/png', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }[ext] || 'application/octet-stream';
        const blob = data instanceof Blob ? data : new Blob([data], { type: mime }), a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click();
        setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000); toast('Downloaded ' + filename); return true; } catch (e) { toast('Download failed: ' + e.message); return false; } }
    toast('Saving files is not available in this view. Open the artifact on claude.ai to export.'); return false; }
  try { await dl.save({ filename, data }); toast('Saved ' + filename); return true; }
  catch (e) { if (e?.code === 'declined') toast('Save cancelled'); else if (e?.code === 'rate_limited') toast('A save prompt is already open'); else toast('Could not save: ' + (e?.message || e?.code || 'unknown error')); return false; }
}
function savePNG(c, name) { const url = c.getDataURL({ type: 'png', pixelRatio: 2, backgroundColor: TC.panel }); fetch(url).then(r => r.blob()).then(b => saveFile(slug(name) + '.png', b)); }
const slug = s => 'jobsaathi-' + String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60);
function csv(head, rows) { const q = v => { v = v == null ? '' : String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }; return '﻿' + [head, ...rows].map(r => r.map(q).join(',')).join('\n'); }

/* ---------------- respondent records (raw / cleaned / analytical) */
const lab = (arr, i, L_, base = 0) => arr[i] < 0 ? '' : L_[arr[i] - base];
const sc = (arr, i) => arr[i] < 0 ? '' : arr[i];
const ml = (v, L_) => v < 0 ? '' : L_.filter((_, b) => v >> b & 1).join('; ');
const RAWO = {}; P.rawOver.forEach(([r, c, v]) => { (RAWO[r] = RAWO[r] || {})[c] = v; });
const COLMAP = { q6_difficulty: 'q6', q10_confidence: 'q10', q24_nps: 'q24', q13_readiness: 'q13' };
function recordHead(kind) {
  const h = ['respondent_id', 'submitted_at', 'duration_sec', 'channel', 'Q1_age_group', 'Q2_education', 'Q3_city'];
  if (kind !== 'raw') h.push('Q3_other_city_name', 'city_tier');
  h.push('Q4_employment_status', 'Q5_experience', 'Q6_job_search_difficulty_1to5', 'Q7_biggest_challenge', 'Q8_applications_3m', 'Q9_interviews', 'Q10_confidence_1to5',
    'Q11_skills_possessed', 'Q12_skills_employers_demand', 'Q13_industry_readiness_1to5', 'Q14_skill_gap_experienced', 'Q15_learning_time', 'Q16_ai_familiarity_1to5',
    'Q17_ai_tool_usage', 'Q18_ai_trust_1to5', 'Q19_useful_ai_features', 'Q20_would_use_platform', 'Q21_most_valuable_feature', 'Q22_willingness_to_pay_monthly',
    'Q23_trust_driver', 'Q24_likelihood_to_recommend_0to10', 'Q25_biggest_improvement_open_text', 'derived_expected_salary_k_per_month');
  if (kind !== 'raw') h.push(...FLAGS.map(f => 'flag_' + f.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/_$/, '')), 'missing_answer_count', 'data_quality');
  if (kind === 'analytical') h.push('skills_possessed_count', 'skill_gap_count', 'ai_adoption_index', 'platform_intent_top2', 'wtp_midpoint_inr', 'paid_intent', 'nps_category',
    'sentiment_model', 'themes_model', 'personas', 'kmeans_cluster', 'lca_class', 'lca_max_probability', 'paid_propensity_gbt');
  return h;
}
const DQL = ['Complete', 'Usable – partial', 'Flagged'];
function record(i, kind) {
  const ts = new Date(Date.UTC(2026, 8, 1, 8, 0) + P.day[i] * 60000).toISOString().slice(0, 16).replace('T', ' ');
  const ro = RAWO[i] || {}; const rv = (col, k) => kind === 'raw' && ro[k] !== undefined ? ro[k] : sc(D[col], i);
  const r = [D.id[i], ts, P.dur[i], L.CHANNEL[D.ch[i]], lab(D.q1, i, L.AGE), lab(D.q2, i, L.EDU), kind === 'raw' ? P.rawCityU[P.rawCity[i]] : lab(D.q3, i, L.CITY)];
  if (kind !== 'raw') r.push(P.otherCity[i] >= 0 ? P.otherCityU[P.otherCity[i]] : '', lab(D.tier, i, L.TIER));
  r.push(lab(D.q4, i, L.STATUS), lab(D.q5, i, L.EXP), rv('q6', 'q6_difficulty'), lab(D.q7, i, L.CHAL), lab(D.q8, i, L.APPS), lab(D.q9, i, L.INTV), rv('q10', 'q10_confidence'),
    ml(D.q11[i], L.SKILLS), ml(D.q12[i], L.SKILLS), rv('q13', 'q13_readiness'), lab(D.q14, i, L.GAPQ), lab(D.q15, i, L.LEARN), sc(D.q16, i), lab(D.q17, i, L.AIUSE), sc(D.q18, i),
    ml(D.q19[i], L.FEAT19), lab(D.q20, i, L.INTENT), lab(D.q21, i, L.FEAT21), lab(D.q22, i, L.WTP), lab(D.q23, i, L.TRUST), rv('q24', 'q24_nps'), P.texts[P.text[i]], isN(D.sal[i]) ? D.sal[i] : '');
  if (kind !== 'raw') r.push(...FLAGS.map((_, b) => (D.flags[i] >> b & 1) ? 'TRUE' : 'FALSE'), D.nMiss[i], DQL[D.dq[i]]);
  if (kind === 'analytical') r.push(isN(D.nSk[i]) ? D.nSk[i] : '', isN(D.gap[i]) ? D.gap[i] : '', isN(D.ai[i]) ? D.ai[i].toFixed(1) : '', isN(D.top2[i]) ? D.top2[i] : '', isN(D.wtp[i]) ? D.wtp[i] : '',
    isN(D.paid[i]) ? D.paid[i] : '', ['Detractor', 'Passive', 'Promoter'][D.npsCat[i]] || '', ['Negative', 'Neutral', 'Positive'][D.sent[i]] || '',
    P.themeKeys.filter((_, b) => D.themes[i] >> b & 1).join('; '), ml(D.persona[i], PERSONA), D.km[i] + 1, D.lca[i] + 1, Math.max(...lcaRow(i)).toFixed(3), D.prop[i].toFixed(3));
  return r;
}
const lcaRow = i => Array.from({ length: LCA_C }, (_, c) => LCAP[i * LCA_C + c]);

/* ---------------- router */
const PAGES = [];
let CUR = null;
function go(key) { if (location.hash.slice(1) !== key) location.hash = key; else render(); }
function refresh() { const sy = $('.main')?.scrollTop ?? 0; render(true); }
function pageByKey(k) { return PAGES.find(p => p.key === k) || PAGES[0]; }
