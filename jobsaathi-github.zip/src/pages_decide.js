/* ============================================================ chart option builders */
function hbar(cats, vals, o = {}) {
  const idx = cats.map((_, i) => i); if (o.sort !== false) idx.sort((a, b) => vals[b] - vals[a]);
  const tot = o.total ?? vals.reduce((a, b) => a + b, 0); const fmt = o.fmt || (v => o.pctLabel === false ? fmtN(v) : pct(v / tot, 1));
  const lw = labW(cats, o.lw || 160);
  return { grid: { left: lw + 14, right: 58, top: o.top ?? 6, bottom: 6, containLabel: false },
    tooltip: { formatter: p => `${esc(p.name)}<br><b>${o.tipFmt ? o.tipFmt(p.value, p.data) : fmtN(p.value) + ' · ' + pct(p.value / tot)}</b>` },
    xAxis: valAx({ axisLabel: { show: false }, max: o.max }), yAxis: catAx(idx.map(i => cats[i]), { inverse: true, axisLabel: { color: TC['ink-2'], width: lw, overflow: 'truncate', fontSize: 11 } }),
    series: [{ type: 'bar', data: idx.map(i => ({ value: vals[i], code: i, itemStyle: { color: o.colors ? o.colors[i] : TC.c1, borderRadius: [0, 4, 4, 0] } })), barMaxWidth: 16, barCategoryGap: '28%',
      label: { show: true, position: 'right', color: TC['ink-2'], fontSize: 11, formatter: p => fmt(p.value) } }] };
}
function vbar(cats, vals, o = {}) {
  const tot = o.total ?? vals.reduce((a, b) => a + b, 0);
  return { grid: { left: 8, right: 10, top: 22, bottom: 6, containLabel: true }, tooltip: { formatter: p => `${esc(p.name)}<br><b>${o.tipFmt ? o.tipFmt(p.value) : fmtN(p.value) + ' · ' + pct(p.value / tot)}</b>` },
    xAxis: catAx(cats, { axisLabel: { color: TC['ink-2'], fontSize: 10.5, interval: 0, width: o.lw || 64, overflow: 'break', lineHeight: 13 } }), yAxis: valAx({ axisLabel: { show: false }, splitLine: { lineStyle: { color: TC['line-2'] } } }),
    series: [{ type: 'bar', data: vals.map((v, i) => ({ value: v, code: i, itemStyle: { color: o.colors ? o.colors[i] : TC.c1, borderRadius: [4, 4, 0, 0] } })), barMaxWidth: 34,
      label: { show: true, position: 'top', color: TC['ink-2'], fontSize: 11, formatter: p => o.fmt ? o.fmt(p.value) : pct(p.value / tot, 0) } }] };
}
const tblCount = (cats, vals, tot) => ({ head: ['Category', 'Respondents', '% of answered'], rows: cats.map((c, i) => [esc(c), vals[i], pct(vals[i] / tot)]) });
function emptyState(c) { panel({ parent: c, span: 12, title: 'No respondents match these filters', html: '<div class="empty">Remove a filter or choose a saved view to see results.</div>', prov: '' }); }
function deltaS(a, b, fmt, show) { return show && isFinite(a) && isFinite(b) ? `all: ${fmt(b)}` : ''; }

/* ============================================================ EXE · Executive Overview */
page('exec', 'EXE', 'Executive Overview', 'Executive Command Centre', 'Who responded, how hard is their job search, and how strongly do they want JobSaathi?', 'decide', c => {
  const ix = IX(), bs = BASE(), n = ix.length, fl = n < bs.length; if (!n) return emptyState(c);
  const st = freq(D.q4, ix, 7), stB = freq(D.q4, bs, 7);
  const ps = (k) => ({ v: `${fmtN(st.c[k])} <small>${pct(st.c[k] / st.n)}</small>`, s: deltaS(st.c[k] / st.n, stB.c[k] / stB.n, pct, fl) });
  const dd = describe(D.diff, ix), rd = describe(D.ready, ix);
  const aw = share(ix, i => isN(D.fam[i]) ? D.fam[i] >= 4 : null), ad = share(ix, i => D.q17[i] >= 0 ? D.q17[i] <= 1 : null), it = share(ix, i => isN(D.top2[i]) ? D.top2[i] : null);
  const w = wtpStats(ix), ns = nps(ix), nsB = nps(bs);
  kpiRow(c, [
    { hero: true, l: 'Total respondents', v: fmtN(n), s: fl ? `${pct(n / bs.length)} of ${fmtN(bs.length)}` : `${fmtN(N)} unique IDs`, trace: { f: 'Count of respondent records in the current view after data-quality exclusion rules and filters.', rows: [['Records in dataset', fmtN(N)], ['After exclusion rules', fmtN(bs.length)], ['After filters', fmtN(n)]] } },
    { l: 'Currently employed', ...ps(2), trace: { f: 'Q4 = "Employed" ÷ respondents who answered Q4.', rows: [['Numerator', fmtN(st.c[2])], ['Denominator', fmtN(st.n)]] } },
    { l: 'Unemployed', ...ps(3), trace: { f: 'Q4 = "Unemployed" ÷ answered Q4.', rows: [['Numerator', fmtN(st.c[3])], ['Denominator', fmtN(st.n)]] } },
    { l: 'Active job seekers', ...ps(4), trace: { f: 'Q4 = "Actively looking for a job" ÷ answered Q4. Unemployed respondents are counted separately.', rows: [['Numerator', fmtN(st.c[4])], ['Denominator', fmtN(st.n)]] } },
    { l: 'Avg job-search difficulty', v: `${f1(dd.mean, 2)} <small>/ 5</small>`, s: fl ? deltaS(dd.mean, mean(D.diff, bs), v => f1(v, 2), true) : `±${f1(dd.ci, 2)} (95% CI)`, trace: { f: 'Mean of Q6 (1 = very easy, 5 = extremely difficult). Invalid raw codes (0, 6, 9) were set to blank and excluded.', rows: [['n answered', fmtN(dd.n)], ['Excluded (blank/invalid)', fmtN(dd.miss)], ['Median', f1(dd.median, 1)], ['Std. dev.', f1(dd.sd, 2)]] } },
    { l: 'Avg industry readiness', v: `${f1(rd.mean, 2)} <small>/ 5</small>`, s: fl ? deltaS(rd.mean, mean(D.ready, bs), v => f1(v, 2), true) : `±${f1(rd.ci, 2)} (95% CI)`, trace: { f: 'Mean of Q13 self-rated industry readiness (1–5).', rows: [['n answered', fmtN(rd.n)], ['Excluded', fmtN(rd.miss)], ['Std. dev.', f1(rd.sd, 2)]] } },
    { l: 'AI awareness', v: pct(aw.p), s: 'Q16 familiarity 4–5', trace: { f: 'Share rating AI familiarity (Q16) at 4 or 5.', rows: [['Numerator', fmtN(aw.y)], ['Denominator', fmtN(aw.n)]] } },
    { l: 'AI adoption', v: pct(ad.p), s: 'use AI tools often / sometimes', trace: { f: 'Q17 = "Frequently" or "Occasionally" ÷ answered Q17.', rows: [['Numerator', fmtN(ad.y)], ['Denominator', fmtN(ad.n)]] } },
    { l: 'JobSaathi product interest', v: pct(it.p), s: fl ? deltaS(it.p, share(bs, i => isN(D.top2[i]) ? D.top2[i] : null).p, pct, true) : 'Definitely + Probably', trace: { f: 'Top-2 box of Q20 (Definitely + Probably would use).', rows: [['Numerator', fmtN(it.y)], ['Denominator', fmtN(it.n)]] } },
    { l: 'Willing to pay', v: pct(w.paid), s: `median payer ${inr(w.medPayer)}/mo`, trace: { f: 'Q22 ≠ "Free only" ÷ answered Q22. Median uses band midpoints (₹149, ₹349, ₹749, ₹1,499, ₹2,499).', rows: [['Paid answers', fmtN(w.n - w.f.c[0])], ['Answered', fmtN(w.n)], ['Blank', fmtN(w.f.miss)]], note: 'Stated willingness to pay, not purchase behaviour.' } },
    { l: 'Hit a skill gap frequently', v: pct(share(ix, i => D.q14[i] >= 0 ? D.q14[i] === 0 : null).p), s: `avg ${f1(mean(D.gap, ix), 1)} perceived gaps each`, trace: { f: 'Q14 = "Yes, frequently" ÷ answered Q14. Perceived gaps = skills a respondent believes employers demand (Q12) but does not hold (Q11).' } },
    { l: 'Net Promoter Score', v: `${ns.nps >= 0 ? '+' : ''}${f1(ns.nps)}`, s: fl ? `all: ${f1(nsB.nps)}` : `±${f1(ns.ci)} (95% CI)`, trace: { f: 'NPS = % promoters (9–10) − % detractors (0–6) on Q24.', code: `${pct(ns.pp)} − ${pct(ns.pd)} = ${f1(ns.nps)}`, rows: [['Promoters', fmtN(ns.P)], ['Passives', fmtN(ns.Pa)], ['Detractors', fmtN(ns.De)], ['n answered', fmtN(ns.n)]], note: 'CI uses Var(NPS) = (p_P + p_D − (p_P − p_D)²)/n.' } },
  ]);
  // insights
  const ins = execInsights(ix);
  panel({ parent: c, span: 12, title: 'Automated executive insights', sub: `Calculated live from the ${fmtN(n)} respondents in view. Groups with fewer than ${CFG.minN} respondents are skipped.`, prov: 'calc',
    html: `<div class="insights">${ins.map(x => `<div class="ins"><div class="q">${x.q}</div><div class="a">${x.a}</div><div class="e">${x.e}</div></div>`).join('')}</div>` });
  cpanel({ parent: c, span: 4, title: 'Employment status', sub: 'Q4 · click a bar to drill down', opt: () => hbar(L.STATUS, st.c), table: () => tblCount(L.STATUS, st.c, st.n), click: p => drill('q4', p.data.code, L.STATUS[p.data.code]) });
  const ag = freq(D.q1, ix, 6); cpanel({ parent: c, span: 4, title: 'Age distribution', sub: 'Q1', opt: () => vbar(L.AGE, ag.c, { colors: ordRamp(6) }), table: () => tblCount(L.AGE, ag.c, ag.n), click: p => drill('q1', p.data.code, L.AGE[p.data.code]) });
  const ed = freq(D.q2, ix, 7); cpanel({ parent: c, span: 4, title: 'Education', sub: `Q2 · ${fmtN(ed.miss)} blank`, opt: () => hbar(EDU_S, ed.c), table: () => tblCount(L.EDU, ed.c, ed.n), click: p => drill('q2', p.data.code, L.EDU[p.data.code]) });
  const ct = freq(D.q3, ix, 12); const tcol = [TC.c3, TC.c1, TC.c2];
  cpanel({ parent: c, span: 6, title: 'Geographic distribution', sub: 'Q3 · coloured by city tier', h: 'tall', pre: legendHTML(L.TIER.map((t, k) => [tcol[k], t])), opt: () => hbar(L.CITY, ct.c, { colors: L.CITY.map((_, k) => tcol[P.tierOfCity[k]]), lw: 170 }),
    table: () => tblCount(L.CITY, ct.c, ct.n), click: p => drill('q3', p.data.code, L.CITY[p.data.code]) });
  const df = freqBase(D.q6, ix, 5, 1); const lk = likert5().reverse();
  cpanel({ parent: c, span: 6, title: 'Job-search difficulty', sub: 'Q6 · 1 = very easy, 5 = extremely difficult', opt: () => vbar(['1 Very easy', '2', '3', '4', '5 Extremely'], df.c, { colors: lk }), table: () => tblCount(['1', '2', '3', '4', '5'], df.c, df.n), click: p => drill('q6', p.data.code, 'Difficulty ' + (p.data.code + 1)),
    post: `<div class="flex" style="margin-top:6px"><span class="pill">Hard (4–5): ${pct((df.c[3] + df.c[4]) / df.n)}</span><span class="pill">Easy (1–2): ${pct((df.c[0] + df.c[1]) / df.n)}</span></div>` });
  const au = freq(D.q17, ix, 4); cpanel({ parent: c, span: 4, title: 'AI tool adoption', sub: 'Q17 · used AI for applications, resume or interview prep', opt: () => vbar(L.AIUSE, au.c, { colors: ordRamp(4).reverse() }), table: () => tblCount(L.AIUSE, au.c, au.n) });
  const pi = freq(D.q20, ix, 5); cpanel({ parent: c, span: 4, title: 'Product interest', sub: 'Q20 · would use a skills-evaluation & career-plan platform', opt: () => vbar(L.INTENT, pi.c, { colors: likert5().reverse() }), table: () => tblCount(L.INTENT, pi.c, pi.n), click: p => drill('q20', p.data.code, L.INTENT[p.data.code]) });
  cpanel({ parent: c, span: 4, title: 'Willingness to pay (monthly)', sub: `Q22 · ${fmtN(w.f.miss)} blank`, opt: () => vbar(WTP_S, w.f.c, { colors: ordRamp(6) }), table: () => tblCount(L.WTP, w.f.c, w.n), click: p => drill('q22', p.data.code, L.WTP[p.data.code]) });
});
function groupScan(ix, metric, minN = CFG.minN) {
  const dims = [['q1', L.AGE, 'Age'], ['q2', L.EDU, 'Education'], ['q4', L.STATUS, 'Employment'], ['q5', L.EXP, 'Experience'], ['tier', L.TIER, 'City tier']];
  const out = []; for (const [col, labs, dl] of dims) for (let k = 0; k < labs.length; k++) { const s = sub(ix, i => D[col][i] === k); if (s.length >= minN) out.push({ col, k, lab: labs[k], dim: dl, n: s.length, v: metric(s) }); }
  return out.filter(x => isFinite(x.v));
}
function execInsights(ix) {
  const out = [], tot = ix.length;
  const hi = groupScan(ix, s => mean(D.diff, s)).sort((a, b) => b.v - a.v)[0];
  if (hi) out.push({ q: 'Highest job-search difficulty', a: `${hi.lab} <span class="muted" style="font-weight:400">(${hi.dim})</span>`, e: `Avg <b>${f1(hi.v, 2)}</b>/5 vs ${f1(mean(D.diff, ix), 2)} in view · n = ${fmtN(hi.n)}` });
  const lo = groupScan(ix, s => mean(D.ready, s)).sort((a, b) => a.v - b.v)[0];
  if (lo) out.push({ q: 'Lowest industry readiness', a: `${lo.lab} <span class="muted" style="font-weight:400">(${lo.dim})</span>`, e: `Avg <b>${f1(lo.v, 2)}</b>/5 vs ${f1(mean(D.ready, ix), 2)} in view · n = ${fmtN(lo.n)}` });
  const ct = freq(D.q3, ix, 12); const ord = ct.c.map((v, k) => [v, k]).sort((a, b) => b[0] - a[0]).slice(0, 3); const nonMetro = share(ix, i => D.tier[i] >= 0 ? D.tier[i] > 0 : null);
  out.push({ q: 'Highest respondent concentration', a: ord.map(([v, k]) => L.CITY[k].replace('Other Tier 2/Tier 3 city', 'Other Tier 2/3')).join(', '), e: ord.map(([v]) => pct(v / ct.n)).join(' · ') + ` · non-metro total <b>${pct(nonMetro.p)}</b>` });
  const sg = skillGap(ix).filter(x => x.j < 11).sort((a, b) => b.gap - a.gap)[0];
  out.push({ q: 'Largest perceived skill gap', a: sg.s, e: `Demand ${pct(sg.dem)} vs held ${pct(sg.have)} → <b>${pp(sg.gap)}</b> · ${fmtN(sg.gapN)} respondents lack it` });
  const ag = groupScan(ix, s => mean(D.ai, s)).filter(x => x.col === 'q1').sort((a, b) => b.v - a.v)[0];
  if (ag) { const fr = share(sub(ix, i => D.q1[i] === ag.k), i => D.q17[i] >= 0 ? D.q17[i] === 0 : null); out.push({ q: 'Strongest AI adoption by age', a: ag.lab, e: `AI Adoption Index <b>${f1(ag.v)}</b> vs ${f1(mean(D.ai, ix))} · ${pct(fr.p)} use AI tools frequently · n = ${fmtN(ag.n)}` }); }
  const cand = groupScan(ix, s => share(s, i => isN(D.paid[i]) ? D.paid[i] : null).p).filter(x => x.col === 'q4');
  personaTable(ix).forEach(p => { if (p.m.n >= CFG.minN) cand.push({ lab: p.nm, dim: 'Persona', n: p.m.n, v: p.m.paid, w: p.m.wtp }); });
  const wp = cand.sort((a, b) => b.v - a.v)[0];
  if (wp) out.push({ q: 'Highest willingness to pay', a: `${wp.lab} <span class="muted" style="font-weight:400">(${wp.dim})</span>`, e: `<b>${pct(wp.v)}</b> would pay ₹99+/month vs ${pct(share(ix, i => isN(D.paid[i]) ? D.paid[i] : null).p)} in view · n = ${fmtN(wp.n)}` });
  return out;
}

/* ============================================================ CEO · Decision Centre */
page('ceo', 'CEO', 'CEO Decision Centre', 'CEO Strategic Decision Centre', 'Five questions a founder or investor asks first, answered from the survey with the evidence behind each answer.', 'decide', c => {
  const ix = IX(), n = ix.length; if (n < 50) return emptyState(c);
  const pers = rankSegments(personaTable(ix)); const t = pers[0]; const tm = t.m, tp = t.pr;
  const fs = featureStats(ix), ff = fs.f21.slice().sort((a, b) => b.score - a.score); const w = wtpStats(ix); const recs = recommendations(ix);
  const ch = freq(D.q7, ix, 9), chT = freq(D.q7, t.ix, 9); const chO = ch.c.map((v, k) => [v, k]).sort((a, b) => b[0] - a[0]);
  const th = mfreq(D.themes, ix, P.themeKeys.length); const thO = th.c.map((v, k) => [v, k]).sort((a, b) => b[0] - a[0]);
  const scen = simRun(defaultScen(ix)[1], ix);
  const block = (no, q, ans, stats, ev, impl, next) => c.insertAdjacentHTML('beforeend', `<section class="panel s12"><div class="ceo-q">${provChip(no === 5 ? 'inferred' : 'calc')}<div class="no">${no}</div><h2>${q}</h2><div class="ans">${ans}</div>
    <div class="ceo-grid"><div><h4>Supporting statistics</h4><div class="stat-row">${stats.map(([v, l]) => `<div><b>${v}</b><span>${l}</span></div>`).join('')}</div></div>
    <div><h4>Evidence strength</h4>${evPill(ev[0])}<p class="muted" style="margin:6px 0 0;font-size:12px">${ev[1]}</p></div>
    <div><h4>Business implication</h4><p style="margin:0">${impl}</p></div><div><h4>Recommended next steps</h4><ul>${next.map(x => `<li>${x}</li>`).join('')}</ul></div></div></div></section>`);
  c.insertAdjacentHTML('beforeend', `<div class="s12 note info">Answers recalculate on the current view (n = ${fmtN(n)}). Segment ranking weights are set in Strategic Recommendations. Synthetic demonstration data.</div>`);
  block(1, 'Who is our best target customer?', `${t.nm}: ${fmtN(tm.n)} respondents (${pct(tm.share)} of the view) with a need index of ${f1(tm.need, 0)} and ${pct(tm.paid)} stated willingness to pay.`,
    [[fmtN(tm.n), 'respondents'], [pct(tm.interest), 'would use (top-2)'], [pct(tm.paid), 'would pay ₹99+'], [f1(tm.ai, 0), 'AI Adoption Index'], [f1(t.score, 0) + '/100', 'attractiveness score']],
    [evidence(tm.n), `Ranked #1 of ${pers.filter(p => isFinite(p.score)).length} personas on need, size, intent, WTP, AI readiness and sample size. Runner-up: ${pers[1].nm} (${f1(pers[1].score, 0)}).`],
    `This group feels the problem and signals it will pay, so it can validate both product value and pricing in one pilot.`,
    [PERSONA_SOL[t.k], `Acquire through ${PERSONA_ACQ[t.k].toLowerCase()}`, 'Define success as ≥ 8% trial-to-paid within 60 days']);
  block(2, 'What is their biggest problem?', `${L.CHAL[argmax(chT.c)]} (${pct(chT.c[argmax(chT.c)] / chT.n)} of the target segment). Across the view, the leading barriers are ${L.CHAL[chO[0][1]].toLowerCase()} and ${L.CHAL[chO[1][1]].toLowerCase()}.`,
    [[pct(chO[0][0] / ch.n), L.CHAL[chO[0][1]]], [pct(chO[1][0] / ch.n), L.CHAL[chO[1][1]]], [pct(chO[2][0] / ch.n), L.CHAL[chO[2][1]]], [pct(profile(ix).hard.p), 'rate their search hard (4–5)'], [pct(thO[0][0] / Math.max(1, th.n)), 'open-text: ' + P.themeKeys[thO[0][1]].toLowerCase()]],
    [evidence(ch.n), `Q7 is single-choice, so each respondent names one barrier. Open-text themes (model-classified) point the same way.`],
    'The platform has to solve the experience and skills story together: show what is missing, then prove readiness to employers.',
    ['Make the Neural Profile show the gap between a candidate and a target role in under 10 minutes', 'Pair each gap with a short, demand-led learning step', 'Give employers a verified readiness score to reduce the "no experience" filter']);
  block(3, 'Which product feature should we launch first?', `${ff[0].f}, followed by ${ff[1].f} and ${ff[2].f}.`,
    ff.slice(0, 4).map(x => [f1(x.score, 0), x.f]).concat([[pct(ff[0].paidP), 'of #1 choosers would pay']]),
    [evidence(ff[0].prim), `Score = 35% Q19 interest + 30% first-choice share (Q21) + 20% paid share of choosers + 15% need. High-demand features: ${fs.f21.filter(x => x.cls === 'High').map(x => x.f).join(', ') || 'none'}.`],
    'A single hero feature keeps the MVP small and gives marketing one clear promise.',
    [`Prototype ${ff[0].f} and run 20 moderated usability sessions with the target segment`, `Ship ${ff[1].f} as the first fast-follow`, 'Instrument feature-level retention from day one']);
  block(4, 'How much are customers willing to pay?', `${pct(w.paid)} state any paid price. The common paid band is ₹99–₹199 (${pct(w.sh[1])}); the stated revenue-maximising price is about ${inr(w.best.p)}/month.`,
    [[pct(w.sh[0]), 'free only'], [pct(w.sh[1]), '₹99–₹199'], [pct(w.sh[2] + w.sh[3] + w.sh[4] + w.sh[5]), '₹200 or more'], [inr(w.medPayer), 'median payer'], [inr(scen.mrrEnd), 'moderate-scenario MRR, month 24']],
    [evidence(w.n), `Stated WTP overstates real purchasing. Projections apply a ${CFG.haircut}% stated-to-actual discount (Settings).`],
    'Revenue depends on volume at a low price point plus employer-side income, not on high consumer prices.',
    ['Launch at ₹149/month with an annual plan', 'A/B test ₹199 and ₹249 on the pricing page', 'Model employer-paid hiring fees as a second revenue line']);
  block(5, 'What should JobSaathi do next?', `${recs[0]?.title}. Then: ${recs.slice(1, 3).map(r => r.title.charAt(0).toLowerCase() + r.title.slice(1)).join('; ')}.`,
    recs.slice(0, 5).map((r, i) => [`#${i + 1} · ${f1(r.total, 0)}`, r.type]), [recs[0] ? recs[0].ev : 'limited', 'Ranked by the Data-to-Decision engine. Actions are proposals inferred from survey findings, not measured outcomes.'],
    'Sequence matters: target segment and hero feature first, pricing test second, scale channels third.',
    recs.slice(0, 5).map((r, i) => `<b>${['0–30 days', '0–30 days', '30–60 days', '60–90 days', '60–90 days'][i]}:</b> ${r.action}`));
});

/* ============================================================ REC · Strategic Recommendations */
page('recs', 'REC', 'Strategic Recommendations', 'Strategic Recommendation Centre', 'Survey data → analytics → customer insight → business opportunity → management decision, ranked by evidence.', 'decide', c => {
  const ix = IX(); if (ix.length < 50) return emptyState(c);
  const crit = [['need', 'Customer need'], ['size', 'Segment size'], ['interest', 'Product interest'], ['wtp', 'Willingness to pay'], ['feas', 'Business feasibility'], ['evid', 'Evidence strength']];
  const wp = panel({ parent: c, span: 12, title: 'Ranking weights', sub: 'Move a slider to re-rank every recommendation and the CEO target-customer answer.', prov: '',
    html: `<div class="ctl-grid">${crit.map(([k, l]) => `<div class="ctl"><label for="w_${k}">${l}<output id="o_${k}">${CFG.w[k]}</output></label><input type="range" id="w_${k}" min="0" max="50" value="${CFG.w[k]}"></div>`).join('')}</div>
    <p class="muted" style="margin:8px 0 0;font-size:12px">Feasibility is an analyst assumption per recommendation type (shown on each card). Evidence = √(n/1000), capped at 100.</p>` });
  crit.forEach(([k]) => { const r = $('#w_' + k, wp); r.oninput = () => { $('#o_' + k, wp).textContent = r.value; }; r.onchange = () => { CFG.w[k] = +r.value; saveCfg(); render(true); }; });
  const recs = recommendations(ix);
  cpanel({ parent: c, span: 12, title: 'Recommendation ranking', sub: 'Weighted contribution of each criterion to the total score (0–100)', h: 'tall', prov: 'inferred',
    opt: () => ({ legend: { top: 0, textStyle: { color: TC['ink-2'] }, icon: 'circle', itemWidth: 9 }, grid: { left: 8, right: 30, top: 34, bottom: 6, containLabel: true }, tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      xAxis: valAx({ max: 100 }), yAxis: catAx(recs.map((r, i) => `#${i + 1} ${r.type}`), { inverse: true }),
      series: crit.map(([k, l], j) => ({ name: l, type: 'bar', stack: 't', barMaxWidth: 18, itemStyle: { color: TC.cat[j], borderColor: TC.panel, borderWidth: 1 }, data: recs.map(r => +(r.sc[k] * CFG.w[k] / Object.values(CFG.w).reduce((a, b) => a + +b, 0)).toFixed(1)) })) }),
    table: () => ({ head: ['#', 'Recommendation', ...crit.map(x => x[1]), 'Total'], rows: recs.map((r, i) => [String(i + 1), esc(r.title), ...crit.map(([k]) => f1(r.sc[k], 0)), f1(r.total, 1)]) }) });
  const lp = panel({ parent: c, span: 12, title: 'Data-to-Decision Intelligence Engine', sub: 'Each card separates what was measured, what is inferred and what is proposed.', prov: 'inferred' });
  $('.pb', lp).innerHTML = recs.map((r, i) => `<article class="rec"><div class="rec-head"><span class="rank">#${i + 1}</span><h4>${esc(r.title)}</h4><span class="pill">${r.type}</span>${evPill(r.ev)}
      <span class="scorebar" title="Score ${f1(r.total, 0)}"><i style="width:${r.total}%"></i></span><b class="num">${f1(r.total, 0)}</b></div>
    <div class="chain">
      <div><h5>${provChip('calc')} Survey finding</h5><p>${r.finding}</p></div>
      <div><h5>${provChip('calc')} Analytics</h5><p>${r.interp}</p></div>
      <div><h5>${provChip('inferred')} Opportunity</h5><p>${r.opp}</p></div>
      <div><h5>${provChip('inferred')} Decision</h5><p>${r.action}</p></div>
      <div><h5>${provChip('projection')} Measure</h5><p>${r.measure}</p></div></div>
    <div class="flex muted" style="font-size:12px"><span><b>Segment:</b> ${esc(r.segment)}</span><span><b>n</b> = ${fmtN(r.n)} (${pct(r.pct)})</span><span><b>Need</b> ${f1(r.sc.need, 0)}</span><span><b>Intent</b> ${pct(r.m.interest)}</span><span><b>Paid</b> ${pct(r.m.paid)}</span><span><b>Feasibility (assumed)</b> ${r.feas}</span></div>
    <div class="note warn"><b>Evidence limitation:</b> ${r.limit}</div></article>`).join('');
});

/* ============================================================ GTM · Market Opportunity */
let MKT_BASIS = 'persona';
page('market', 'GTM', 'Market Opportunity', 'Market Opportunity & Go-to-Market', 'Which segments and locations should JobSaathi enter first, and how should it reach them?', 'decide', c => {
  const ix = IX(), tot = ix.length; if (tot < 50) return emptyState(c);
  const bases = { persona: 'Personas', status_tier: 'Employment × city tier', city: 'Cities', cluster: 'K-Means clusters' };
  c.insertAdjacentHTML('beforeend', `<div class="s12 flex"><span class="flabel">Segment basis</span><div class="seg" id="mb">${Object.entries(bases).map(([k, l]) => `<button data-b="${k}" aria-pressed="${MKT_BASIS === k}">${l}</button>`).join('')}</div></div>`);
  $$('#mb button').forEach(b => b.onclick = () => { MKT_BASIS = b.dataset.b; render(true); });
  let rows = [];
  if (MKT_BASIS === 'persona') rows = personaTable(ix).map(p => ({ nm: p.nm, m: p.m, acq: p.acq }));
  else if (MKT_BASIS === 'city') rows = cityTable(ix).map(r => ({ nm: r.nm, m: r.m, tier: r.tier }));
  else if (MKT_BASIS === 'cluster') rows = Array.from({ length: P.kmK }, (_, k) => { const s = sub(ix, i => D.km[i] === k); return { nm: `C${k + 1} · ${clusterName(P.kmCent[k])}`, m: segMetrics(s, tot) }; });
  else for (const s of [1, 2, 3, 4, 6, 0]) for (let t = 0; t < 3; t++) { const sx = sub(ix, i => D.q4[i] === s && D.tier[i] === t); rows.push({ nm: `${L.STATUS[s]} · ${L.TIER[t].replace(' (named)', '').replace(' (Tier 1)', '')}`, m: segMetrics(sx, tot) }); }
  rows = rows.filter(r => r.m.n >= Math.min(30, CFG.minN));
  const xs = rows.map(r => r.m.need), ys = rows.map(r => r.m.wtp); const mx = xs.reduce((a, b) => a + b, 0) / xs.length, my = ys.reduce((a, b) => a + b, 0) / ys.length;
  rows.forEach(r => { const hiN = r.m.need >= mx, hiM = r.m.wtp >= my; r.q = hiN && hiM ? 'Attack' : hiN ? 'Freemium build' : hiM ? 'Premium upsell' : 'Deprioritise';
    r.acq = r.acq || { Attack: 'Paid acquisition + employer partnerships; lead with the paid plan', 'Freemium build': 'Free tier via colleges, ITIs and skilling missions; monetise employers', 'Premium upsell': 'Salary benchmarking and premium matching; LinkedIn and referrals', Deprioritise: 'Content marketing only; revisit after launch' }[r.q]; });
  const qc = { Attack: TC.c1, 'Freemium build': TC.c3, 'Premium upsell': TC.c2, Deprioritise: TC.muted };
  const maxN = Math.max(...rows.map(r => r.m.n));
  cpanel({ parent: c, span: 7, title: 'Segment attractiveness matrix', sub: 'x = customer need index · y = expected stated WTP per respondent (₹/month) · bubble = respondents', h: 'xtall', prov: 'calc',
    pre: legendHTML(Object.entries(qc).map(([k, v]) => [v, k])), opt: () => ({ grid: { left: 8, right: 24, top: 34, bottom: 30, containLabel: true },
      tooltip: { formatter: p => { const r = rows[p.dataIndex]; return `<b>${esc(r.nm)}</b><br>n = ${fmtN(r.m.n)} · need ${f1(r.m.need, 0)}<br>Expected WTP ${inr(r.m.wtp)} · intent ${pct(r.m.interest)}<br>Quadrant: ${r.q}`; } },
      xAxis: valAx({ name: 'Customer need index', nameLocation: 'middle', nameGap: 24, nameTextStyle: { color: TC.muted }, ...padAx(.08, .3) }), yAxis: valAx({ name: '₹ / respondent', nameTextStyle: { color: TC.muted }, ...padAx(.1, .12) }),
      series: [{ type: 'scatter', clip: false, data: rows.map(r => [r.m.need, r.m.wtp, r.m.n]), symbolSize: d => 10 + 38 * Math.sqrt(d[2] / maxN), itemStyle: { color: p => qc[rows[p.dataIndex].q], opacity: .85, borderColor: TC.panel, borderWidth: 2 },
        label: { show: rows.length <= 12, formatter: p => rows[p.dataIndex].nm.split(' · ')[0].replace(/ Job Seekers| Professionals| Candidates/, ''), position: 'right', color: TC['ink-2'], fontSize: 10.5 },
        markLine: { silent: true, symbol: 'none', lineStyle: { color: TC.line, type: 'solid' }, label: { show: false }, data: [{ xAxis: mx }, { yAxis: my }] } }] }),
    table: () => ({ head: ['Segment', 'n', 'Need', 'Exp. WTP', 'Quadrant'], rows: rows.map(r => [esc(r.nm), r.m.n, f1(r.m.need, 0), inr(r.m.wtp), r.q]) }) });
  const ranked = rankSegments(rows.map(r => ({ ...r })));
  panel({ parent: c, span: 5, title: 'Market-entry priorities', sub: 'Ranked with the recommendation weights', prov: 'inferred',
    html: `<ol style="margin:0;padding-left:18px;display:grid;gap:8px">${ranked.slice(0, 5).map(r => `<li><b>${esc(r.nm)}</b> <span class="pill" style="margin-left:4px">${r.q}</span><br><span class="muted" style="font-size:12px">score ${f1(r.score, 0)} · n ${fmtN(r.m.n)} · need ${f1(r.m.need, 0)} · paid ${pct(r.m.paid, 0)}</span><br><span style="font-size:12.5px">${esc(r.acq)}</span></li>`).join('')}</ol>` });
  panel({ parent: c, span: 12, title: 'Segment table', sub: 'Survey respondent concentration is not total addressable market', html: `<div class="tw">${tableHTML(['Segment', 'Respondents', '% of view', 'Need index', 'Hard search', 'Avg skill gaps', 'AI index', 'Intent (top-2)', 'Paid share', 'Exp. ₹/resp.', 'Quadrant', 'Recommended acquisition'],
    ranked.map(r => [esc(r.nm), r.m.n, pct(r.m.share), f1(r.m.need, 0), pct(r.m.hard), f1(r.m.gap, 2), f1(r.m.ai, 0), pct(r.m.interest), pct(r.m.paid), inr(r.m.wtp), r.q, esc(r.acq)]))}</div>` });
  const chs = L.CHANNEL.map((nm, k) => { const s = sub(ix, i => D.ch[i] === k); return { nm, m: segMetrics(s, tot), hi: share(s, i => D.q20[i] === 0 && D.paid[i] === 1).p }; });
  cpanel({ parent: c, span: 6, title: 'Survey recruitment channel quality', sub: 'Share of respondents who would definitely use and would pay · channel is survey metadata', prov: 'calc',
    opt: () => hbar(chs.map(x => x.nm), chs.map(x => x.hi * 100), { fmt: v => v.toFixed(1) + '%', tipFmt: (v) => v.toFixed(1) + '% high-intent payers' }),
    table: () => ({ head: ['Channel', 'n', 'Intent', 'Paid', 'High-intent payers'], rows: chs.map(x => [x.nm, x.m.n, pct(x.m.interest), pct(x.m.paid), pct(x.hi)]) }) });
  const ms = store.get('mkt', { pop: 12000000, reach: 8, adopt: 15, pay: 20, price: 149 });
  const mp = panel({ parent: c, span: 6, title: 'Illustrative market sizing', sub: 'Every input is an editable assumption, not a survey result', prov: 'projection',
    html: `<div class="ctl-grid">${[['pop', 'Target population (people)', 1], ['reach', 'Reachable in 3 yrs (%)', .1], ['adopt', 'Adopt the platform (%)', .1], ['pay', 'Convert to paid (%)', .1], ['price', 'Monthly price (₹)', 1]].map(([k, l, st]) => `<div class="ctl"><label for="m_${k}">${l}</label><input type="number" id="m_${k}" step="${st}" value="${ms[k]}"></div>`).join('')}</div><div id="msOut" style="margin-top:12px"></div>
    <p class="muted" style="font-size:11.5px;margin:8px 0 0">The survey cannot estimate TAM/SAM/SOM. Replace the population with an external source (e.g. PLFS youth labour-force estimates) before using these figures.</p>` });
  const calc = () => { ['pop', 'reach', 'adopt', 'pay', 'price'].forEach(k => ms[k] = +$('#m_' + k, mp).value || 0); store.set('mkt', ms);
    const sam = ms.pop * ms.reach / 100, users = sam * ms.adopt / 100, payers = users * ms.pay / 100, arr = payers * ms.price * 12;
    $('#msOut', mp).innerHTML = `<div class="outgrid"><span>Illustrative TAM (people)</span><b>${fmtN(ms.pop)}</b><span>Illustrative SAM (reachable)</span><b>${fmtN(sam)}</b><span>Illustrative SOM (adopters)</span><b>${fmtN(users)}</b><span>Paying users</span><b>${fmtN(payers)}</b><span>Illustrative ARR</span><b>${inr(arr)}</b></div>`; };
  $$('input', mp).forEach(i => i.oninput = calc); calc();
});

/* ============================================================ SIM · What-if Simulator */
function defaultScen(ix) {
  const w = wtpStats(ix); const stated = w.paid;
  return [
    { nm: 'Conservative', seg: 'all', price: 99, conv: +(stated * 100 * (1 - CFG.haircut / 100) * .6).toFixed(1), acq: 1500, budget: 150000, churn: 12, margin: 70, fixed: 600000, growth: 3 },
    { nm: 'Moderate', seg: 'all', price: 149, conv: +(stated * 100 * (1 - CFG.haircut / 100)).toFixed(1), acq: 3000, budget: 240000, churn: 9, margin: 75, fixed: 600000, growth: 5 },
    { nm: 'Optimistic', seg: 'all', price: 199, conv: +(stated * 100 * (1 - CFG.haircut / 100) * 1.35).toFixed(1), acq: 5000, budget: 350000, churn: 6, margin: 80, fixed: 600000, growth: 7 }];
}
function segIx(seg, ix) { if (seg === 'all') return ix; if (seg.startsWith('p')) { const k = +seg.slice(1); return sub(ix, i => D.persona[i] >> k & 1); } if (seg.startsWith('c')) { const k = +seg.slice(1); return sub(ix, i => D.km[i] === k); } return ix; }
function simRun(s, ix, months = 24) {
  const six = segIx(s.seg, ix); const w = wtpStats(six.length ? six : ix);
  const acceptAtPrice = w.willing(s.price) / Math.max(1e-9, w.paid); // relative acceptance at chosen price among stated payers
  const conv = Math.max(0, s.conv / 100) * Math.min(1.5, acceptAtPrice); const cac = s.acq > 0 ? s.budget / s.acq : NaN; const ch = s.churn / 100;
  let paying = 0, cum = 0, acquiredCum = 0; const mrr = [], pay = [], cash = []; let breakMonth = null;
  for (let m = 1; m <= months; m++) { const acq = s.acq * Math.pow(1 + s.growth / 100, m - 1); acquiredCum += acq; paying = paying * (1 - ch) + acq * conv; const r = paying * s.price;
    const profit = r * s.margin / 100 - s.fixed - s.budget; cum += profit; mrr.push(r); pay.push(paying); cash.push(cum); if (breakMonth === null && profit >= 0) breakMonth = m; }
  const arpu = s.price, ltv = ch > 0 ? arpu * s.margin / 100 / ch : NaN, cacPaid = conv > 0 ? cac / conv : NaN;
  return { six, statedPaid: w.paid, conv, accept: w.willing(s.price), cac, cacPaid, ltv, ltvcac: ltv / cacPaid, payback: cacPaid / (arpu * s.margin / 100), mrr, pay, cash, mrrEnd: mrr[months - 1], arrEnd: mrr[months - 1] * 12,
    payingEnd: pay[months - 1], acquired: acquiredCum, breakEvenCust: (s.fixed + s.budget) / (arpu * s.margin / 100), breakMonth, blendedCac: s.budget * months / acquiredCum };
}
let SIM = null;
page('simulator', 'SIM', 'What-if Simulator', 'What-if Business Simulator', 'Edit every assumption and compare three subscription scenarios side by side. Projections are hypothetical.', 'decide', c => {
  const ix = IX(); if (ix.length < 30) return emptyState(c);
  if (!SIM) SIM = store.get('sim', null) || defaultScen(ix);
  const segOpts = [['all', 'All respondents in view'], ...PERSONA.map((p, k) => ['p' + k, p]), ...Array.from({ length: P.kmK }, (_, k) => ['c' + k, `Cluster C${k + 1} · ${clusterName(P.kmCent[k])}`])];
  c.insertAdjacentHTML('beforeend', `<div class="s12 note warn"><b>Hypothetical projection.</b> Survey inputs (stated WTP, price acceptance) come from synthetic data; growth, churn, CAC, costs and the ${CFG.haircut}% stated-to-actual discount are assumptions. Results are not forecasts.</div>`);
  const sp = panel({ parent: c, span: 12, title: 'Scenario assumptions', sub: 'Changes recalculate instantly. Defaults: conversion = stated paid share × (1 − discount) × scenario factor.', prov: 'projection', tools: '<button class="btn sm" id="simReset">Reset to defaults</button>' });
  const fields = [['seg', 'Target segment', 'sel'], ['price', 'Subscription price (₹/month)', 1], ['conv', 'Paid conversion of sign-ups (%)', .1], ['acq', 'New sign-ups in month 1', 50], ['growth', 'Sign-up growth (%/month, organic + referral)', .5],
    ['budget', 'Marketing budget (₹/month)', 10000], ['churn', 'Monthly churn of payers (%)', .5], ['margin', 'Gross margin (%)', 1], ['fixed', 'Fixed costs (₹/month)', 10000]];
  $('.pb', sp).innerHTML = `<div class="scen">${SIM.map((s, j) => `<div data-j="${j}"><h4><i class="dot" style="background:${TC.cat[[2, 0, 1][j]]}"></i>${s.nm}</h4>
    ${fields.map(([k, l, st]) => st === 'sel' ? `<div class="ctl"><label for="s${j}_${k}">${l}</label><select id="s${j}_${k}" data-k="${k}">${segOpts.map(([v, t]) => `<option value="${v}" ${s.seg === v ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div>`
      : `<div class="ctl"><label for="s${j}_${k}">${l}</label><input type="number" id="s${j}_${k}" data-k="${k}" step="${st}" value="${s[k]}"></div>`).join('')}<div class="outgrid" data-out></div></div>`).join('')}</div>`;
  $('#simReset').onclick = () => { SIM = defaultScen(ix); store.set('sim', SIM); render(true); };
  const charts = {}; const res = () => SIM.map(s => simRun(s, ix));
  const draw = () => { const R = res(); $$('.scen > div', sp).forEach((d, j) => { const r = R[j];
      $('[data-out]', d).innerHTML = `<span>Segment respondents</span><b>${fmtN(r.six.length)}</b><span>Stated paid share</span><b>${pct(r.statedPaid)}</b><span>Stated acceptance at price</span><b>${pct(r.accept)}</b><span>Effective conversion</span><b>${pct(r.conv, 2)}</b>
      <span>Sign-ups (24 mo)</span><b>${fmtN(r.acquired)}</b><span>Paying customers, m24</span><b>${fmtN(r.payingEnd)}</b><span>MRR, month 24</span><b>${inr(r.mrrEnd)}</b><span>ARR run-rate</span><b>${inr(r.arrEnd)}</b>
      <span>CAC per sign-up (month 1)</span><b>${inr(r.cac)}</b><span>Blended CAC (24 mo)</span><b>${inr(r.blendedCac)}</b><span>CAC per payer</span><b>${inr(r.cacPaid)}</b><span>LTV (margin ÷ churn)</span><b>${inr(r.ltv)}</b><span>LTV : CAC</span><b>${f1(r.ltvcac, 2)}×</b>
      <span>Payback (months)</span><b>${f1(r.payback, 1)}</b><span>Break-even payers</span><b>${fmtN(r.breakEvenCust)}</b><span>First profitable month</span><b>${r.breakMonth ? 'M' + r.breakMonth : 'not in 24 mo'}</b>`; });
    const mo = Array.from({ length: 24 }, (_, i) => 'M' + (i + 1)), cols = [TC.c3, TC.c1, TC.c2];
    charts.mrr?.setOption({ series: R.map((r, j) => ({ data: r.mrr.map(v => Math.round(v)) })) }); charts.pay?.setOption({ series: R.map(r => ({ data: r.pay.map(v => Math.round(v)) })) }); charts.cash?.setOption({ series: R.map(r => ({ data: r.cash.map(v => Math.round(v)) })) });
    return R; };
  $$('input,select', sp).forEach(inp => inp.oninput = () => { const j = +inp.closest('[data-j]').dataset.j, k = inp.dataset.k; SIM[j][k] = k === 'seg' ? inp.value : +inp.value; store.set('sim', SIM); draw(); });
  const R = draw(); const mo = Array.from({ length: 24 }, (_, i) => 'M' + (i + 1)), cols = [TC.c3, TC.c1, TC.c2];
  const line = (key, title, sub, fmt) => cpanel({ parent: c, span: key === 'mrr' ? 12 : 6, title, sub, prov: 'projection', h: key === 'mrr' ? 'tall' : '',
    opt: () => ({ legend: { top: 0, icon: 'circle', itemWidth: 9, textStyle: { color: TC['ink-2'] } }, grid: { left: 8, right: 72, top: 34, bottom: 6, containLabel: true }, tooltip: { trigger: 'axis', valueFormatter: fmt },
      xAxis: catAx(mo, { boundaryGap: false }), yAxis: valAx({ axisLabel: { formatter: v => fmt(v), color: TC['ink-2'] } }),
      series: R.map((r, j) => ({ name: SIM[j].nm, type: 'line', smooth: .2, symbol: 'circle', symbolSize: 5, showSymbol: false, lineStyle: { width: 2, color: cols[j] }, itemStyle: { color: cols[j] }, areaStyle: key === 'mrr' ? { color: cols[j], opacity: .06 } : undefined,
        endLabel: { show: true, formatter: p => fmt(p.value), color: TC['ink-2'], fontSize: 11 }, data: (key === 'mrr' ? r.mrr : key === 'pay' ? r.pay : r.cash).map(v => Math.round(v)) })) }),
    table: () => ({ head: ['Month', ...SIM.map(s => s.nm)], rows: mo.map((m, i) => [m, ...SIM.map((_, j) => fmt(res()[j][key === 'mrr' ? 'mrr' : key === 'pay' ? 'pay' : 'cash'][i]))]) }) });
  charts.mrr = line('mrr', 'Monthly recurring revenue', 'Paying customers × price, after churn', v => inr(v))._chart;
  charts.pay = line('pay', 'Paying customers', 'End of month', v => fmtN(v))._chart;
  charts.cash = line('cash', 'Cumulative operating profit', 'Gross margin − fixed costs − marketing', v => inr(v))._chart;
  const w = wtpStats(segIx(SIM[1].seg, ix));
  cpanel({ parent: c, span: 12, title: 'Survey price-acceptance curve', sub: `Share stating they would pay at least each price (uniform within Q22 bands) and the revenue index price × acceptance · segment: ${esc(segOpts.find(o => o[0] === SIM[1].seg)[1])}`, prov: 'calc',
    opt: () => ({ grid: { left: 8, right: 20, top: 30, bottom: 6, containLabel: true }, tooltip: { trigger: 'axis' }, legend: { top: 0, icon: 'circle', itemWidth: 9, textStyle: { color: TC['ink-2'] } },
      xAxis: catAx(w.curve.map(x => '₹' + x.p)), yAxis: valAx({ max: 100, axisLabel: { formatter: '{value}%', color: TC['ink-2'] } }),
      series: [{ name: 'Accept price (%)', type: 'line', data: w.curve.map(x => +(x.d * 100).toFixed(1)), lineStyle: { color: TC.c1, width: 2 }, itemStyle: { color: TC.c1 }, symbolSize: 6, areaStyle: { color: TC.c1, opacity: .08 } },
        { name: 'Revenue index (max = 100)', type: 'line', data: w.curve.map(x => +(100 * x.rev / w.best.rev).toFixed(1)), lineStyle: { color: TC.c2, width: 2 }, itemStyle: { color: TC.c2 }, symbolSize: 6,
          markPoint: { symbol: 'pin', symbolSize: 34, itemStyle: { color: TC.c2 }, label: { fontSize: 9, color: '#fff', formatter: () => '₹' + w.best.p }, data: [{ coord: ['₹' + w.best.p, 100] }] } }] }),
    table: () => ({ head: ['Price', 'Accept %', 'Revenue index'], rows: w.curve.map(x => ['₹' + x.p, pct(x.d), f1(100 * x.rev / w.best.rev, 1)]) }) });
});
