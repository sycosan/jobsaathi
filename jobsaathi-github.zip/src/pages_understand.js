/* ============================================================ RSP · Respondent Intelligence */
function stack100(cats, groups, mat, colors, o = {}) { // mat[g][k] counts; horizontal 100% stacked
  const tot = mat.map(r => r.reduce((a, b) => a + b, 0));
  const lw = labW(groups, o.lw || 150);
  return { legend: { top: 0, icon: 'circle', itemWidth: 9, textStyle: { color: TC['ink-2'], fontSize: 11 } }, grid: { left: lw + 14, right: 16, top: o.top || 40, bottom: 22, containLabel: false },
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, formatter: ps => `<b>${esc(ps[0].name)}</b> · n ${fmtN(tot[ps[0].dataIndex])}<br>` + ps.map(p => `${p.marker}${esc(p.seriesName)}: ${p.value.toFixed(1)}%`).join('<br>') },
    xAxis: valAx({ max: 100, axisLabel: { formatter: '{value}%', color: TC['ink-2'] } }), yAxis: catAx(groups, { inverse: true, axisLabel: { width: lw, overflow: 'truncate', color: TC['ink-2'] } }),
    series: cats.map((cn, k) => ({ name: cn, type: 'bar', stack: 's', barMaxWidth: 20, itemStyle: { color: colors[k], borderColor: TC.panel, borderWidth: 1 }, data: mat.map((r, g) => ({ value: tot[g] ? 100 * r[k] / tot[g] : 0, g })),
      label: { show: o.labels !== false, formatter: p => p.value >= 9 ? Math.round(p.value) + '%' : '', fontSize: 10, color: k >= cats.length / 2 || o.darkText ? '#fff' : TC.ink } })) };
}
function crossCounts(ix, rowCol, R, colCol, C, rowBase = 0, colBase = 0) { const m = Array.from({ length: R }, () => new Array(C).fill(0)); for (const i of ix) { const r = D[rowCol][i] - rowBase, c = D[colCol][i] - colBase; if (D[rowCol][i] >= 0 && D[colCol][i] >= 0 && r < R && c < C && r >= 0 && c >= 0) m[r][c]++; } return m; }
function heat(xl, yl, data, o = {}) { // data [[x,y,v]]
  const vs = data.map(d => d[2]).filter(isFinite); const lo = o.min ?? Math.min(...vs), hi = o.max ?? Math.max(...vs);
  return { grid: { left: 8, right: 16, top: 10, bottom: o.vm === false ? 6 : 46, containLabel: true }, tooltip: { formatter: p => o.tip ? o.tip(p) : `${esc(yl[p.value[1]])} · ${esc(xl[p.value[0]])}<br><b>${o.fmt ? o.fmt(p.value[2]) : p.value[2]}</b>` },
    xAxis: catAx(xl, { position: 'top', axisLabel: { interval: 0, rotate: o.rot ?? 30, fontSize: 10.5, color: TC['ink-2'], width: 90, overflow: 'truncate' } }), yAxis: catAx(yl, { inverse: true, axisLabel: { fontSize: 11, color: TC['ink-2'], width: 150, overflow: 'truncate' } }),
    visualMap: { show: o.vm !== false, min: lo, max: hi, orient: 'horizontal', left: 'center', bottom: 0, itemHeight: 140, itemWidth: 10, calculable: false, text: o.vmText || [fmtV(hi, o), fmtV(lo, o)], textStyle: { color: TC['ink-2'], fontSize: 10.5 },
      inRange: { color: o.diverging ? [TC['div-neg'], TC['div-mid'], TC['div-pos']] : [TC['seq-lo'], TC['seq-hi']] } },
    series: [{ type: 'heatmap', data, itemStyle: { borderColor: TC.panel, borderWidth: 2, borderRadius: 3 }, label: { show: o.labels !== false, fontSize: 10, formatter: p => o.cell ? o.cell(p.value[2]) : p.value[2], color: TC.ink }, emphasis: { itemStyle: { borderColor: TC.ink, borderWidth: 1 } } }] };
}
const fmtV = (v, o) => o.fmt ? o.fmt(v) : String(Math.round(v));
page('respondents', 'RSP', 'Respondent Intelligence', 'Customer & Respondent Intelligence', 'Who needs JobSaathi? Combine any filters above and every chart, KPI and table on every page updates.', 'understand', c => {
  const ix = IX(), bs = BASE(), n = ix.length;
  panel({ parent: c, span: 12, title: 'Quick segment views', sub: 'One click applies a multi-filter view; edit it in the filter strip', prov: '',
    html: `<div class="flex">${PRESETS.map((p, i) => `<button class="btn wrap" data-p="${i}">${esc(p.name)}</button>`).join('')}</div>` });
  $$('[data-p]', c).forEach(b => b.onclick = () => { const pr = PRESETS[+b.dataset.p]; FDEF.forEach(d => F[d.k].clear()); for (const k in pr.f) pr.f[k].forEach(v => F[k].add(v)); refresh(); });
  if (!n) return emptyState(c);
  const pr = profile(ix), pb = profile(bs);
  const nm = share(ix, i => D.tier[i] >= 0 ? D.tier[i] > 0 : null), grad = share(ix, i => D.q2[i] >= 0 ? (D.q2[i] === 3 || D.q2[i] === 4) : null);
  kpiRow(c, [{ hero: true, l: 'Respondents in segment', v: fmtN(n), s: `${pct(n / bs.length)} of ${fmtN(bs.length)}` }, { l: 'Non-metro (Tier 2/3)', v: pct(nm.p), s: `${fmtN(nm.y)} respondents` },
    { l: 'Graduates (UG + PG)', v: pct(grad.p), s: `${fmtN(grad.y)} respondents` }, { l: 'Avg experience', v: `${f1(mean(D.expY, ix), 1)} <small>yrs</small>`, s: 'band midpoints' },
    { l: 'Hard job search (4–5)', v: pct(pr.hard.p), s: `all: ${pct(pb.hard.p)}` }, { l: 'Hit a skill gap frequently', v: pct(pr.gapFreq.p), s: `all: ${pct(pb.gapFreq.p)}` }]);
  const rows = [['Respondents', fmtN(pr.n), fmtN(pb.n), ''], ['Job-search difficulty (1–5)', f1(pr.diff, 2), f1(pb.diff, 2), pr.diff - pb.diff], ['Job confidence (1–5)', f1(pr.conf, 2), f1(pb.conf, 2), pr.conf - pb.conf],
    ['Industry readiness (1–5)', f1(pr.ready, 2), f1(pb.ready, 2), pr.ready - pb.ready], ['Avg skill gaps (count)', f1(pr.gap, 2), f1(pb.gap, 2), pr.gap - pb.gap], ['AI Adoption Index', f1(pr.ai), f1(pb.ai), pr.ai - pb.ai],
    ['Would use JobSaathi (top-2)', pct(pr.top2.p), pct(pb.top2.p), 100 * (pr.top2.p - pb.top2.p)], ['Would pay ₹99+', pct(pr.paid.p), pct(pb.paid.p), 100 * (pr.paid.p - pb.paid.p)], ['NPS', f1(pr.nps.nps), f1(pb.nps.nps), pr.nps.nps - pb.nps.nps]];
  panel({ parent: c, span: 5, title: 'Segment vs all respondents', sub: 'Differences in points (pp for shares)', html: `<div class="tw">${tableHTML(['Metric', 'Segment', 'All', 'Δ'], rows.map(r => [r[0], r[1], r[2], typeof r[3] === 'number' && isFinite(r[3]) ? `<span style="color:${r[3] >= 0 ? 'var(--good-ink)' : 'var(--crit-ink)'}">${r[3] >= 0 ? '+' : ''}${r[3].toFixed(r[0].includes('(1–5)') || r[0].includes('count') ? 2 : 1)}</span>` : '']), { right: [1, 2, 3] })}</div>` });
  const m = crossCounts(ix, 'q4', 7, 'q2', 7); const hd = []; m.forEach((r, y) => r.forEach((v, x) => hd.push([x, y, v])));
  cpanel({ parent: c, span: 7, title: 'Employment status × education', sub: 'Respondent counts · click a cell to drill down', h: 'tall', opt: () => heat(L.EDU, L.STATUS, hd, { rot: 25 }),
    table: () => ({ head: ['Status', ...L.EDU], rows: m.map((r, y) => [L.STATUS[y], ...r]) }), click: p => drill('q4', p.value[1], L.STATUS[p.value[1]]) });
  const ex = freq(D.q5, ix, 6); cpanel({ parent: c, span: 4, title: 'Professional experience', sub: 'Q5', opt: () => vbar(L.EXP.map(s => s.replace(' years', ' y').replace('Less than 1 year', '< 1 y').replace('More than 10 y', '10+ y').replace('No experience', 'None')), ex.c, { colors: ordRamp(6) }), table: () => tblCount(L.EXP, ex.c, ex.n), click: p => drill('q5', p.data.code, L.EXP[p.data.code]) });
  const ap = freq(D.q8, ix, 6); cpanel({ parent: c, span: 4, title: 'Job-search behaviour', sub: 'Q8 · applications in the last 3 months', opt: () => vbar(L.APPS, ap.c, { colors: ordRamp(6) }), table: () => tblCount(L.APPS, ap.c, ap.n) });
  const lr = freq(D.q15, ix, 5); cpanel({ parent: c, span: 4, title: 'Learning commitment', sub: 'Q15 · time willing to invest in new skills', opt: () => vbar(L.LEARN.map(s => s.replace('Less than', '<').replace('More than', '>').replace(' months', ' mo')), lr.c, { colors: ordRamp(5) }), table: () => tblCount(L.LEARN, lr.c, lr.n) });
  const f21 = freq(D.q21, ix, 7); cpanel({ parent: c, span: 6, title: 'Career aspirations: most valuable JobSaathi feature', sub: 'Q21 · single choice', opt: () => hbar(L.FEAT21, f21.c, { lw: 200 }), table: () => tblCount(L.FEAT21, f21.c, f21.n) });
  const tr = freq(D.tier, ix, 3), ag = crossCounts(ix, 'tier', 3, 'q1', 6);
  cpanel({ parent: c, span: 6, title: 'Age mix by city tier', sub: 'Row % of each tier', opt: () => stack100(L.AGE, L.TIER.map((t, k) => `${t} (n ${fmtN(tr.c[k])})`), ag, ordRamp(6), { lw: 170 }), table: () => ({ head: ['Tier', ...L.AGE], rows: ag.map((r, k) => [L.TIER[k], ...r]) }) });
});

/* ============================================================ EMP · Employment Analytics */
page('employment', 'EMP', 'Employment Analytics', 'Employment Market Intelligence', 'What problems are job seekers facing, and where does the application-to-interview process break down?', 'understand', c => {
  const ix = IX(); if (!ix.length) return emptyState(c);
  const okAI = sub(ix, i => !(D.flags[i] & 2) && isN(D.apps[i]) && isN(D.intv[i]));
  const applied = sub(okAI, i => D.apps[i] > 0); const zero = share(applied, i => D.intv[i] === 0);
  const conv = applied.reduce((s, i) => s + D.intv[i], 0) / Math.max(1, applied.reduce((s, i) => s + D.apps[i], 0));
  const conf = describe(D.conf, ix), low = share(ix, i => isN(D.conf[i]) ? D.conf[i] <= 2 : null), hard = share(ix, i => isN(D.diff[i]) ? D.diff[i] >= 4 : null);
  kpiRow(c, [{ l: 'Hard job search (4–5)', v: pct(hard.p), s: `${fmtN(hard.y)} of ${fmtN(hard.n)}`, trace: { f: 'Share with Q6 ≥ 4.', rows: [['Numerator', fmtN(hard.y)], ['Denominator', fmtN(hard.n)]] } },
    { l: 'Applied in last 3 months', v: pct(applied.length / Math.max(1, okAI.length)), s: `${fmtN(applied.length)} respondents` },
    { l: 'Applicants with zero interviews', v: pct(zero.p), s: `${fmtN(zero.y)} of ${fmtN(zero.n)}`, trace: { f: 'Among respondents with ≥ 1 application, share reporting 0 interviews. Excludes records flagged "applications = 0 but interviews ≥ 1" and blanks.', rows: [['Included', fmtN(okAI.length)], ['Excluded', fmtN(ix.length - okAI.length)]] } },
    { l: 'Interviews per 10 applications', v: f1(conv * 10, 2), s: 'band midpoints', trace: { f: 'Σ interview midpoints ÷ Σ application midpoints among applicants.', code: 'Q8 midpoints: 0,3,8,15.5,35,65 · Q9 midpoints: 0,1.5,4,8,13', note: 'Banded answers, so this is an approximation.' } },
    { l: 'Avg confidence, next 6 months', v: `${f1(conf.mean, 2)} <small>/ 5</small>`, s: `±${f1(conf.ci, 2)} (95% CI)` }, { l: 'Low confidence (1–2)', v: pct(low.p), s: `${fmtN(low.y)} respondents` }]);
  const fun = [['All respondents in view', ix.length], ['Applied (1+ applications)', applied.length], ['Got 1+ interview', sub(applied, i => D.intv[i] > 0).length], ['Got 3+ interviews', sub(applied, i => D.q9[i] >= 2).length], ['Confident of a job (Q10 4–5)', sub(applied, i => D.intv[i] > 0 && D.conf[i] >= 4).length]];
  cpanel({ parent: c, span: 6, title: 'Application-to-interview funnel', sub: 'Excludes inconsistent application/interview records', h: 'tall',
    opt: () => ({ tooltip: { formatter: p => `${p.name}<br><b>${fmtN(p.value)}</b> · ${pct(p.value / ix.length)} of view` }, series: [{ type: 'funnel', sort: 'none', left: 10, right: 10, top: 10, bottom: 10, minSize: '12%', gap: 3,
      label: { position: 'inside', formatter: p => `${p.name}\n${fmtN(p.value)} · ${pct(p.value / fun[0][1], 0)}`, color: '#fff', fontSize: 11, lineHeight: 15 }, itemStyle: { borderColor: TC.panel, borderWidth: 1 },
      data: fun.map(([nm, v], k) => ({ name: nm, value: v, itemStyle: { color: ordRamp(5).reverse()[k] } })) }] }),
    table: () => ({ head: ['Stage', 'Respondents', '% of view', '% of previous'], rows: fun.map((f, k) => [f[0], f[1], pct(f[1] / fun[0][1]), k ? pct(f[1] / fun[k - 1][1]) : '–']) }) });
  const am = crossCounts(okAI, 'q8', 6, 'q9', 5); const hd = []; am.forEach((r, y) => { const t = r.reduce((a, b) => a + b, 0); r.forEach((v, x) => hd.push([x, y, t ? +(100 * v / t).toFixed(1) : 0])); });
  cpanel({ parent: c, span: 6, title: 'Applications vs interviews', sub: 'Row % · more applications does not mean proportionally more interviews', h: 'tall', opt: () => heat(L.INTV.map(s => s + ' int.'), L.APPS.map(s => s + ' apps'), hd, { fmt: v => v + '%', cell: v => v >= 1 ? Math.round(v) + '%' : '', rot: 0 }),
    table: () => ({ head: ['Applications', ...L.INTV], rows: am.map((r, y) => [L.APPS[y], ...r]) }) });
  const ch = freq(D.q7, ix, 9); cpanel({ parent: c, span: 5, title: 'Biggest job-search challenge', sub: 'Q7 · single choice · click to drill down', opt: () => hbar(L.CHAL, ch.c, { lw: 180 }), table: () => tblCount(L.CHAL, ch.c, ch.n), click: p => drillCustom(sub(ix, i => D.q7[i] === p.data.code), L.CHAL[p.data.code], 'Biggest challenge') });
  const cm = crossCounts(ix, 'q4', 7, 'q7', 9); cpanel({ parent: c, span: 7, title: 'Challenges by employment status', sub: 'Row % · the darkest cell in each row is its main barrier', h: 'tall',
    opt: () => { const d = []; cm.forEach((r, y) => { const t = r.reduce((a, b) => a + b, 0); r.forEach((v, x) => d.push([x, y, t ? +(100 * v / t).toFixed(1) : 0])); }); return heat(L.CHAL, L.STATUS, d, { fmt: v => v + '%', cell: v => Math.round(v) + '' }); },
    table: () => ({ head: ['Status', ...L.CHAL], rows: cm.map((r, y) => [L.STATUS[y], ...r]) }), click: p => drill('q4', p.value[1], L.STATUS[p.value[1]]) });
  const dims = [['q4', L.STATUS, 'Employment status'], ['q5', L.EXP, 'Experience'], ['tier', L.TIER, 'City tier'], ['q2', L.EDU, 'Education']];
  dims.forEach(([col, labs, t], j) => { const ms = labs.map((_, k) => { const s = sub(ix, i => D[col][i] === k); return { n: s.length, d: describe(D.diff, s) }; });
    cpanel({ parent: c, span: j < 2 ? 6 : 6, title: `Difficulty by ${t.toLowerCase()}`, sub: 'Mean Q6 (1–5) with 95% CI in tooltip', opt: () => ({ ...hbar(labs, ms.map(m => +(m.d.mean || 0).toFixed(2)), { sort: false, fmt: v => v.toFixed(2), max: 5, tipFmt: (v, d) => `${v.toFixed(2)} ± ${f1(ms[d.code].d.ci, 2)} · n ${fmtN(ms[d.code].n)}`, colors: labs.map((_, k) => div(((ms[k].d.mean || 3) - 3) / -1.2)) }) }),
      table: () => ({ head: [t, 'n', 'Mean', '95% CI ±', 'Median'], rows: labs.map((l, k) => [l, ms[k].n, f1(ms[k].d.mean, 2), f1(ms[k].d.ci, 2), f1(ms[k].d.median, 1)]) }), click: col === 'q2' || col === 'tier' || col === 'q4' || col === 'q5' ? p => drill(col, p.data.code, labs[p.data.code]) : null }); });
  const scan = groupScan(ix, s => { const ap = sub(s, i => !(D.flags[i] & 2) && D.apps[i] > 0 && isN(D.intv[i])); const z = ap.length ? ap.filter(i => D.intv[i] === 0).length / ap.length : NaN;
    const h = share(s, i => isN(D.diff[i]) ? D.diff[i] >= 4 : null).p, lc = share(s, i => isN(D.conf[i]) ? D.conf[i] <= 2 : null).p; s._z = z; s._h = h; s._l = lc; return 100 * (.4 * h + .3 * (z || 0) + .3 * lc); });
  const top = scan.sort((a, b) => b.v - a.v).slice(0, 10);
  panel({ parent: c, span: 12, title: 'Segments struggling most', sub: `Struggle index = 40% hard search + 30% zero interviews among applicants + 30% low confidence · groups with n ≥ ${CFG.minN}`,
    html: `<div class="tw">${tableHTML(['Segment', 'Dimension', 'n', 'Struggle index', ''], top.map(t => [esc(t.lab), t.dim, t.n, f1(t.v, 1), `<span class="bar-in" style="width:${t.v * 1.4}px"></span>`]))}</div>` });
});
function drillCustom(seg, label, dim) { const pr = profile(seg); drawer(esc(label), profileHTML(pr, IX().length) + `<div class="note info">${esc(dim)} = ${esc(label)} within the current view.</div>`, 'Drill-down · ' + dim); }

/* ============================================================ SKL · Skill Gap Analysis */
let SKL_DIM = 'q4';
page('skills', 'SKL', 'Skill Gap Analysis', 'Skill Gap Analytics', 'Which skills are missing from the workforce, and which training should JobSaathi build first? Employer demand is respondent-perceived.', 'understand', c => {
  const ix = IX(); if (!ix.length) return emptyState(c);
  const sg = skillGap(ix).filter(x => x.j < 11), ord = sg.slice().sort((a, b) => b.gap - a.gap);
  const n = sg[0].n;
  c.insertAdjacentHTML('beforeend', `<div class="s12 note info"><b>Perceived employer demand</b> = share of respondents who believe employers want a skill (Q12). This is not an employer survey. Skill gap (pp) = demand % − held % (Q11). ${fmtN(ix.length - n)} respondents left both skill questions blank and are excluded here.</div>`);
  cpanel({ parent: c, span: 7, title: 'Skill demand vs skill availability', sub: `Q11 held vs Q12 perceived demand · n = ${fmtN(n)}`, h: 'xtall',
    pre: legendHTML([[TC.c3, 'Respondents who hold the skill'], [TC.c2, 'Respondents who think employers demand it']]),
    opt: () => ({ grid: { left: 8, right: 40, top: 6, bottom: 6, containLabel: true }, tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, formatter: ps => { const s = ord[ps[0].dataIndex]; return `<b>${s.s}</b><br>Held ${pct(s.have)} (${fmtN(s.haveN)})<br>Demand ${pct(s.dem)} (${fmtN(s.demN)})<br>Gap ${pp(s.gap)} · ${fmtN(s.gapN)} lack it`; } },
      xAxis: valAx({ max: 100, axisLabel: { formatter: '{value}%', color: TC['ink-2'] } }), yAxis: catAx(ord.map(s => s.s), { inverse: true }),
      series: [{ name: 'Held', type: 'bar', barGap: '10%', barMaxWidth: 11, itemStyle: { color: TC.c3, borderRadius: [0, 3, 3, 0] }, data: ord.map(s => +(s.have * 100).toFixed(1)) },
        { name: 'Demand', type: 'bar', barMaxWidth: 11, itemStyle: { color: TC.c2, borderRadius: [0, 3, 3, 0] }, data: ord.map(s => +(s.dem * 100).toFixed(1)), label: { show: true, position: 'right', fontSize: 10.5, color: TC['ink-2'], formatter: p => pp(ord[p.dataIndex].gap) } }] }),
    table: () => ({ head: ['Skill', 'Held %', 'Demand %', 'Gap (pp)', 'Hold it (n)', 'Lack it (n)'], rows: ord.map(s => [s.s, pct(s.have), pct(s.dem), pp(s.gap), s.haveN, s.gapN]) }) });
  panel({ parent: c, span: 5, title: 'Skill priority ranking', sub: 'Ranked by percentage-point gap', html: `<div class="tw">${tableHTML(['#', 'Skill', 'Gap', 'Lack it', 'Priority'], ord.map((s, k) => [String(k + 1), s.s, pp(s.gap), s.gapN, s.gap >= 20 ? '<span class="pill hi">Critical</span>' : s.gap >= 8 ? '<span class="pill md">High</span>' : s.gap > 0 ? '<span class="pill lo">Watch</span>' : '<span class="pill lo">Surplus</span>']), { right: [2, 3] })}</div>` });
  const dims = { q1: ['Age', L.AGE], q2: ['Education', L.EDU], q4: ['Employment', L.STATUS], q5: ['Experience', L.EXP], tier: ['City tier', L.TIER], q3: ['City', L.CITY] };
  const [dl, dlab] = dims[SKL_DIM]; const gb = gapBy(ix, SKL_DIM, dlab.length);
  const hd = []; gb.forEach(g => g.sg.slice(0, 11).forEach(s => hd.push([g.g, s.j, g.n >= 20 ? +s.gap.toFixed(1) : NaN])));
  const hp = cpanel({ parent: c, span: 12, title: 'Skill-gap heatmap', sub: `Gap in percentage points by ${dl.toLowerCase()} · red = demand exceeds supply · groups under 20 respondents greyed out · click a cell to drill down`, h: 'xtall',
    pre: `<div class="flex" style="margin-bottom:6px"><span class="flabel">Compare across</span><div class="seg" id="skd">${Object.entries(dims).map(([k, [l]]) => `<button data-d="${k}" aria-pressed="${SKL_DIM === k}">${l}</button>`).join('')}</div></div>`,
    opt: () => { const o = heat(dlab.map((l, k) => `${l} (${fmtN(gb[k].n)})`), L.SKILLS.slice(0, 11), hd, { diverging: true, min: -30, max: 30, fmt: v => isFinite(v) ? pp(v) : 'n < 20', cell: v => isFinite(v) ? Math.round(v) : '', vmText: ['demand > held', 'held > demand'], rot: 30 });
      o.visualMap.inRange.color = [TC['div-pos'], TC['div-mid'], TC['div-neg']]; return o; },
    table: () => ({ head: ['Skill', ...dlab], rows: L.SKILLS.slice(0, 11).map((s, j) => [s, ...gb.map(g => g.n >= 20 ? pp(g.sg[j].gap) : '–')]) }),
    click: p => { if (SKL_DIM in F || FDEF.some(d => d.k === SKL_DIM)) drill(SKL_DIM, p.value[0], dlab[p.value[0]]); } });
  $$('#skd button', hp).forEach(b => b.onclick = () => { SKL_DIM = b.dataset.d; render(true); });
  const combos = []; for (const [col, [dn, labs]] of Object.entries(dims)) gapBy(ix, col, labs.length).forEach(g => { if (g.n >= CFG.minN) g.sg.slice(0, 11).forEach(s => combos.push({ seg: labs[g.g], dn, n: g.n, s: s.s, gap: s.gap, lack: s.gapN })); });
  const t10 = combos.sort((a, b) => b.gap - a.gap).slice(0, 10);
  panel({ parent: c, span: 6, title: 'Top 10 skill gaps by segment', sub: `Skill × segment combinations, segments with n ≥ ${CFG.minN}`, html: `<div class="tw">${tableHTML(['#', 'Skill', 'Segment', 'Gap', 'Lack it', 'Segment n'], t10.map((t, k) => [String(k + 1), t.s, `${esc(t.seg)} <span class="muted">· ${t.dn}</span>`, pp(t.gap), t.lack, t.n]), { right: [3, 4, 5] })}</div>` });
  const recs = ord.filter(s => s.gap > 0).slice(0, 6);
  panel({ parent: c, span: 6, title: 'Training recommendations', sub: 'Proposed JobSaathi learning products for the largest gaps', prov: 'inferred',
    html: `<div class="tw">${tableHTML(['Skill gap', 'Proposed programme', 'Format'], recs.map(s => [`${s.s} <span class="muted">${pp(s.gap)}</span>`, TRAIN[s.j][0], TRAIN[s.j][1]]), { autoRight: false })}</div>` });
  // Training opportunity matrix
  const rowsT = recs.concat(ord.filter(s => s.gap > 0).slice(6, 8)).map(s => {
    const gi = sub(ix, i => D.q11[i] >= 0 && ((D.q12[i] & ~D.q11[i]) >> s.j & 1));
    const rate = (col, k) => { const all = sub(ix, i => D[col][i] === k && D.q11[i] >= 0); return all.length >= CFG.minN ? gi.filter(i => D[col][i] === k).length / all.length : -1; };
    const topBy = (col, labs) => labs.map((l, k) => [l, rate(col, k)]).filter(x => x[1] >= 0).sort((a, b) => b[1] - a[1]).slice(0, 2).map(x => `${x[0]} (${pct(x[1], 0)})`).join(', ');
    const lt = freq(D.q15, gi, 5); const mode = argmax(lt.c); const fmt = mode <= 1 ? 'Short micro-course (≤ 3 months)' : mode === 2 ? 'Cohort programme (3–6 months)' : 'Certification track (6+ months)';
    return [`<b>${s.s}</b>`, fmtN(gi.length), topBy('q2', L.EDU), topBy('q4', L.STATUS), pct(s.dem), `${L.LEARN[mode]} <span class="muted">(${pct(lt.c[mode] / lt.n, 0)})</span>`, fmt, TRAIN[s.j][0]];
  });
  panel({ parent: c, span: 12, title: 'Skill gap → training opportunity matrix', sub: 'Lack-it rate shown in brackets for the segments where the gap is most common', prov: 'inferred',
    html: `<div class="pipe" style="margin-bottom:12px"><span class="on">Skill gap</span><span>Target customer</span><span>Learning roadmap</span><span>Assessment</span><span>Job-readiness measurement</span></div>
    <div class="tw">${tableHTML(['Skill', 'Respondents with gap', 'Top education segments', 'Top employment segments', 'Perceived demand', 'Preferred learning time (mode)', 'Training format', 'JobSaathi product'], rowsT, { autoRight: false, right: [1, 4] })}</div>` });
});

/* ============================================================ AIX · AI Adoption */
page('ai', 'AIX', 'AI Adoption', 'AI Adoption & Technology Readiness', 'Are job seekers ready to adopt AI-powered career tools, and what holds the rest back?', 'understand', c => {
  const ix = IX(); if (!ix.length) return emptyState(c);
  const d = describe(D.ai, ix), ready = share(ix, i => D.aiReady[i] >= 0 ? D.aiReady[i] === 2 : null), aw = share(ix, i => D.aiReady[i] >= 0 ? D.aiReady[i] === 0 : null), fr = share(ix, i => D.q17[i] === 0), tr = describe(D.trust, ix);
  const W = CFG.aiW; const sw = W.reduce((a, b) => a + +b, 0);
  kpiRow(c, [{ hero: true, l: 'AI Adoption Index', v: `${f1(d.mean)} <small>/ 100</small>`, s: `median ${f1(d.median)} · n ${fmtN(d.n)}`, trace: { f: 'Weighted average of three components rescaled to 0–1, × 100. Computed when at least 2 of 3 answers exist; weights renormalise over available answers.',
      code: `Index = 100 × (${W[0]}·(Q16−1)/4 + ${W[1]}·usage/3 + ${W[2]}·(Q18−1)/4) / ${sw}\nusage: Frequently 3, Occasionally 2, Tried 1, Never 0`, note: 'Weights are editable in Settings.' } },
    { l: 'AI-ready customers', v: pct(ready.p), s: `index ≥ 65 · ${fmtN(ready.y)}` }, { l: 'Need AI awareness', v: pct(aw.p), s: `index < 40 · ${fmtN(aw.y)}` },
    { l: 'Use AI tools frequently', v: pct(fr.p), s: `${fmtN(fr.y)} respondents` }, { l: 'Trust AI recommendations', v: `${f1(tr.mean, 2)} <small>/ 5</small>`, s: `${pct(share(ix, i => isN(D.trust[i]) ? D.trust[i] >= 4 : null).p)} rate 4–5` }]);
  const bins = new Array(10).fill(0); for (const i of ix) if (isN(D.ai[i])) bins[Math.min(9, Math.floor(D.ai[i] / 10))]++;
  cpanel({ parent: c, span: 6, title: 'AI Adoption Index distribution', sub: 'Respondents per 10-point band · bands ≥ 65 are AI-ready', opt: () => vbar(bins.map((_, k) => `${k * 10}–${k * 10 + 9}`), bins, { colors: bins.map((_, k) => k >= 6.5 ? TC.c1 : k < 4 ? TC.c2 : TC.muted) }), table: () => tblCount(bins.map((_, k) => `${k * 10}–${k * 10 + 9}`), bins, d.n),
    post: legendHTML([[TC.c2, 'Needs awareness (< 40)'], [TC.muted, 'Developing (40–64)'], [TC.c1, 'AI-ready (≥ 65)']]) });
  const fm = crossCounts(ix, 'q16', 5, 'q17', 4, 1, 0); const hd = []; fm.forEach((r, y) => r.forEach((v, x) => hd.push([x, y, v])));
  cpanel({ parent: c, span: 6, title: 'Familiarity × actual usage', sub: 'Q16 (rows) vs Q17 (columns) · counts', opt: () => heat(L.AIUSE, ['Familiarity 1', '2', '3', '4', '5'], hd, { rot: 0 }), table: () => ({ head: ['Q16', ...L.AIUSE], rows: fm.map((r, y) => [String(y + 1), ...r]) }) });
  [['q1', L.AGE, 'age'], ['q2', L.EDU, 'education'], ['q4', L.STATUS, 'employment status']].forEach(([col, labs, t]) => {
    const ms = labs.map((_, k) => { const s = sub(ix, i => D[col][i] === k); return { n: s.length, m: mean(D.ai, s), r: share(s, i => D.aiReady[i] >= 0 ? D.aiReady[i] === 2 : null).p }; });
    cpanel({ parent: c, span: 4, title: `Adoption by ${t}`, sub: 'Mean AI Adoption Index', opt: () => hbar(labs, ms.map(m => +(m.m || 0).toFixed(1)), { sort: col !== 'q1', fmt: v => v.toFixed(0), max: 100, tipFmt: (v, dd) => `index ${v.toFixed(1)} · AI-ready ${pct(ms[dd.code].r)} · n ${fmtN(ms[dd.code].n)}`, lw: 120 }),
      table: () => ({ head: [t, 'n', 'Mean index', 'AI-ready %'], rows: labs.map((l, k) => [l, ms[k].n, f1(ms[k].m), pct(ms[k].r)]) }), click: p => drill(col, p.data.code, labs[p.data.code]) }); });
  const fs = featureStats(ix);
  cpanel({ parent: c, span: 6, title: 'Most attractive AI features', sub: `Q19 multi-select · n = ${fmtN(fs.n19)} · High ≥ 40%, Medium 30–39%, Low < 30%`, h: 'tall', pre: legendHTML([[TC.c1, 'High demand'], [TC.c3, 'Medium'], [TC.muted, 'Low']]),
    opt: () => hbar(L.FEAT19, fs.f19.map(f => f.n), { total: fs.n19, colors: fs.f19.map(f => f.cls === 'High' ? TC.c1 : f.cls === 'Medium' ? TC.c3 : TC.muted), lw: 210 }),
    table: () => ({ head: ['Feature', 'Respondents', '% of n', 'Demand'], rows: fs.f19.map(f => [f.f, f.n, pct(f.p), f.cls]) }), click: p => drill('q19', p.data.code, L.FEAT19[p.data.code]) });
  const lowT = sub(ix, i => isN(D.trust[i]) && D.trust[i] <= 2), hiT = sub(ix, i => isN(D.trust[i]) && D.trust[i] >= 4);
  const a = freq(D.q23, lowT, 8), b = freq(D.q23, hiT, 8);
  cpanel({ parent: c, span: 6, title: 'Barriers to adoption: what would build trust', sub: `Q23 · low-trust (AI trust 1–2, n ${fmtN(lowT.length)}) vs high-trust (4–5, n ${fmtN(hiT.length)})`, h: 'tall', pre: legendHTML([[TC.c2, 'Low trust'], [TC.c3, 'High trust']]),
    opt: () => ({ grid: { left: labW(L.TRUST) + 14, right: 30, top: 6, bottom: 22, containLabel: false }, tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, valueFormatter: v => v + '%' }, xAxis: valAx({ axisLabel: { formatter: '{value}%', color: TC['ink-2'] } }), yAxis: catAx(L.TRUST, { inverse: true, axisLabel: { width: labW(L.TRUST), overflow: 'truncate', color: TC['ink-2'] } }),
      series: [{ name: 'Low trust', type: 'bar', barMaxWidth: 10, itemStyle: { color: TC.c2, borderRadius: [0, 3, 3, 0] }, data: a.c.map(v => +(100 * v / Math.max(1, a.n)).toFixed(1)) }, { name: 'High trust', type: 'bar', barMaxWidth: 10, itemStyle: { color: TC.c3, borderRadius: [0, 3, 3, 0] }, data: b.c.map(v => +(100 * v / Math.max(1, b.n)).toFixed(1)) }] }),
    table: () => ({ head: ['Trust driver', 'Low trust %', 'High trust %'], rows: L.TRUST.map((t, k) => [t, pct(a.c[k] / a.n), pct(b.c[k] / b.n)]) }) });
  const grp = [['AI-ready (≥ 65)', sub(ix, i => D.aiReady[i] === 2)], ['Developing (40–64)', sub(ix, i => D.aiReady[i] === 1)], ['Needs awareness (< 40)', sub(ix, i => D.aiReady[i] === 0)]].map(([nm, s]) => [nm, profile(s)]);
  panel({ parent: c, span: 12, title: 'AI-ready customers vs customers needing awareness', html: `<div class="tw">${tableHTML(['Group', 'n', 'Avg age band', 'Avg experience (yrs)', 'Would use (top-2)', 'Would pay', 'NPS', 'Top valued feature'],
    grp.map(([nm, p], k) => { const s = [sub(ix, i => D.aiReady[i] === 2), sub(ix, i => D.aiReady[i] === 1), sub(ix, i => D.aiReady[i] === 0)][k]; return [nm, p.n, L.AGE[Math.round(mean(fromCode(D.q1), s))] || '–', f1(mean(D.expY, s), 1), pct(p.top2.p), pct(p.paid.p), f1(p.nps.nps), L.FEAT21[p.topF]]; }))}</div>
    <p class="muted" style="font-size:12px;margin:8px 0 0">Segments are based on the AI Adoption Index; associations here are descriptive and do not imply that AI familiarity causes intent.</p>` });
});

/* ============================================================ PMF · Product-Market Fit */
page('pmf', 'PMF', 'Product-Market Fit', 'JobSaathi Product-Market Fit', 'Which proposed features do customers value most, and which should be built first? Every finding shows its n and %.', 'understand', c => {
  const ix = IX(); if (!ix.length) return emptyState(c);
  const fs = featureStats(ix), it = freq(D.q20, ix, 5);
  const spec = [['Neural Profile & skill assessment', [3, 7], 1], ['AI career guidance', [0], 0], ['Job matching', [4], 2], ['Skill-gap analysis', [3], -1], ['Interview preparation', [2], 5], ['Salary estimation', [5], 3]];
  kpiRow(c, [{ hero: true, l: 'Would use JobSaathi', v: pct((it.c[0] + it.c[1]) / it.n), s: `Definitely ${pct(it.c[0] / it.n)} · Probably ${pct(it.c[1] / it.n)}`, trace: { f: 'Q20 top-2 box.', rows: [['Definitely', fmtN(it.c[0])], ['Probably', fmtN(it.c[1])], ['Answered', fmtN(it.n)]] } },
    ...spec.map(([nm, bits, q21]) => { const s = share(ix, i => bits.some(b => D.q19[i] >> b & 1)); const p1 = q21 >= 0 ? freq(D.q21, ix, 7) : null;
      return { l: nm + ' interest', v: pct(s.p), s: `${fmtN(s.y)} resp.${p1 ? ` · #1 for ${pct(p1.c[q21] / p1.n, 0)}` : ''}`, trace: { f: `Share selecting ${bits.map(b => '“' + L.FEAT19[b] + '”').join(' or ')} in Q19${q21 >= 0 ? `; "#1" = Q21 first choice "${L.FEAT21[q21]}"` : ''}.`, rows: [['Numerator', fmtN(s.y)], ['Denominator', fmtN(s.n)]] } }; })]);
  const mx = fs.f21.map(f => f.intP * 100), my = fs.f21.map(f => f.paidP * 100); const ax = mx.reduce((a, b) => a + b, 0) / 7, ay = my.reduce((a, b) => a + b, 0) / 7; const maxP = Math.max(...fs.f21.map(f => f.prim));
  cpanel({ parent: c, span: 7, title: 'Feature priority matrix', sub: 'x = interest in the matching AI capability (Q19) · y = paid share among those choosing it as #1 (Q21) · bubble = #1 choosers', h: 'xtall',
    opt: () => ({ grid: { left: 8, right: 30, top: 34, bottom: 30, containLabel: true }, tooltip: { formatter: p => { const f = fs.f21[p.dataIndex]; return `<b>${f.f}</b><br>Interest ${pct(f.intP)} (${fmtN(f.intN)})<br>#1 choice ${pct(f.primP)} (${fmtN(f.prim)})<br>Paid share of choosers ${pct(f.paidP)}<br>Priority score ${f1(f.score, 0)}`; } },
      xAxis: valAx({ name: 'Interest %', nameLocation: 'middle', nameGap: 24, nameTextStyle: { color: TC.muted }, ...padAx(.12, .45), axisLabel: { formatter: '{value}%', color: TC['ink-2'] } }), yAxis: valAx({ name: 'Paid share %', nameTextStyle: { color: TC.muted }, ...padAx(.12, .15), axisLabel: { formatter: '{value}%', color: TC['ink-2'] } }),
      series: [{ type: 'scatter', data: fs.f21.map((f, k) => [mx[k], my[k], f.prim]), symbolSize: d => 14 + 34 * Math.sqrt(d[2] / maxP), itemStyle: { color: p => fs.f21[p.dataIndex].cls === 'High' ? TC.c1 : fs.f21[p.dataIndex].cls === 'Medium' ? TC.c3 : TC.muted, borderColor: TC.panel, borderWidth: 2 },
        label: { show: true, position: 'right', formatter: p => fs.f21[p.dataIndex].f, color: TC['ink-2'], fontSize: 10.5 }, markLine: { silent: true, symbol: 'none', lineStyle: { color: TC.line, type: 'solid' }, label: { show: false }, data: [{ xAxis: ax }, { yAxis: ay }] } }] }),
    table: () => ({ head: ['Feature', 'Interest', '#1 choice', 'Paid share', 'Score', 'Demand'], rows: fs.f21.map(f => [f.f, pct(f.intP), pct(f.primP), pct(f.paidP), f1(f.score, 0), f.cls]) }), pre: legendHTML([[TC.c1, 'High demand'], [TC.c3, 'Medium'], [TC.muted, 'Low']]) });
  const sorted = fs.f21.slice().sort((a, b) => b.score - a.score);
  panel({ parent: c, span: 5, title: 'Feature priority ranking', sub: 'Score = 35% interest + 30% #1 choice + 20% paid share + 15% need', html: `<div class="tw">${tableHTML(['#', 'Feature', 'Demand', '#1 choosers', 'Score'], sorted.map((f, k) => [String(k + 1), f.f, `<span class="pill ${f.cls === 'High' ? 'hi' : f.cls === 'Medium' ? 'md' : 'lo'}">${f.cls}</span>`, `${fmtN(f.prim)} · ${pct(f.primP, 0)}`, f1(f.score, 0)]), { right: [3, 4] })}</div>` });
  const sm = crossCounts(ix, 'q4', 7, 'q20', 5);
  cpanel({ parent: c, span: 6, title: 'Adoption intention by employment status', sub: 'Q20 · row %', h: 'tall', opt: () => stack100(L.INTENT, L.STATUS, sm, likert5().reverse(), { darkText: false }), table: () => ({ head: ['Status', ...L.INTENT], rows: sm.map((r, k) => [L.STATUS[k], ...r]) }) });
  const tf = freq(D.q23, ix, 8); cpanel({ parent: c, span: 6, title: 'Customer trust factors', sub: `Q23 · what would make you trust an AI employment platform · ${fmtN(tf.miss)} blank`, h: 'tall', opt: () => hbar(L.TRUST, tf.c, { lw: 200 }), table: () => tblCount(L.TRUST, tf.c, tf.n) });
  const rules = assocRules('q19', ix, .08, .45).sort((a, b) => b.lift - a.lift).slice(0, 8);
  panel({ parent: c, span: 12, title: 'Feature bundles: which AI features travel together', sub: 'Association rules on Q19 (support ≥ 8%, confidence ≥ 45%) · full explorer in Model Lab', prov: 'model',
    html: rules.length ? `<div class="tw">${tableHTML(['If respondent wants…', '…they also want', 'Support', 'Confidence', 'Lift', 'n'], rules.map(r => [r.A, r.B, pct(r.sup), pct(r.conf), f1(r.lift, 2), r.nAB]))}</div>` : '<div class="empty">No rules pass the thresholds for this view.</div>' });
});

/* ============================================================ REV · Revenue Intelligence */
let REV_BY = 'q4';
page('revenue', 'REV', 'Revenue Intelligence', 'Revenue & Monetisation Intelligence', 'Which customer segments are willing to pay, and how much? Stated willingness to pay is not purchasing behaviour.', 'understand', c => {
  const ix = IX(); if (!ix.length) return emptyState(c);
  const w = wtpStats(ix), hi = w.sh[3] + w.sh[4] + w.sh[5];
  kpiRow(c, [{ hero: true, l: 'Willing to pay ₹99+', v: pct(w.paid), s: `${fmtN(w.n - w.f.c[0])} of ${fmtN(w.n)}`, trace: { f: '1 − share choosing "Free only" in Q22.', rows: [['Answered', fmtN(w.n)], ['Blank', fmtN(w.f.miss)]] } },
    { l: 'Free only', v: pct(w.sh[0]), s: `${fmtN(w.f.c[0])} respondents` }, { l: 'Median stated WTP (payers)', v: inr(w.medPayer), s: 'per month, band midpoints' },
    { l: 'Mean stated WTP (all)', v: inr(w.meanAll), s: 'free counted as ₹0' }, { l: 'Revenue-maximising price', v: inr(w.best.p), s: `${pct(w.best.d)} accept`, trace: { f: 'Price p maximising p × share willing to pay ≥ p, with willingness uniform inside each Q22 band.', code: `₹${w.best.p} × ${pct(w.best.d)} = ₹${f1(w.best.rev, 1)} per respondent` } },
    { l: '₹500+ per month', v: pct(hi), s: 'premium signal' }]);
  const dims = { q4: ['Employment status', L.STATUS, 'q4'], q1: ['Age', L.AGE, 'q1'], q2: ['Education', L.EDU, 'q2'], aiReady: ['AI adoption', ['Needs awareness (< 40)', 'Developing (40–64)', 'AI-ready (≥ 65)'], 'aiReady'], q20: ['Product interest', L.INTENT, 'q20'], tier: ['City tier', L.TIER, 'tier'] };
  const [dl, labs, col] = dims[REV_BY]; const m = crossCounts(ix, col, labs.length, 'q22', 6);
  const sp = cpanel({ parent: c, span: 8, title: `Willingness to pay by ${dl.toLowerCase()}`, sub: 'Row % of each group across Q22 price bands', h: 'xtall',
    pre: `<div class="flex" style="margin-bottom:6px"><span class="flabel">Break down by</span><div class="seg" id="rvd">${Object.entries(dims).map(([k, [l]]) => `<button data-d="${k}" aria-pressed="${REV_BY === k}">${l}</button>`).join('')}</div></div>`,
    opt: () => stack100(WTP_S, labs.map((l, k) => `${l} (${fmtN(m[k].reduce((a, b) => a + b, 0))})`), m, ordRamp(6), { lw: 170, top: 44 }), table: () => ({ head: [dl, ...L.WTP], rows: m.map((r, k) => [labs[k], ...r]) }) });
  $$('#rvd button', sp).forEach(b => b.onclick = () => { REV_BY = b.dataset.d; render(true); });
  const ps = labs.map((_, k) => { const s = sub(ix, i => D[col][i] === k); const sh = share(s, i => isN(D.paid[i]) ? D.paid[i] : null); return { ...sh, ci: wilson(sh.y, sh.n), wtp: mean(D.wtp, s) }; });
  panel({ parent: c, span: 4, title: 'Paid share with 95% CI', sub: 'Wilson interval', html: `<div class="tw">${tableHTML([dl, 'n', 'Paid', '95% CI', 'Mean ₹'], labs.map((l, k) => [esc(l), ps[k].n, pct(ps[k].p), `${pct(ps[k].ci[0], 0)}–${pct(ps[k].ci[1], 0)}`, inr(ps[k].wtp)]), { right: [1, 2, 3, 4] })}</div>` });
  cpanel({ parent: c, span: 6, title: 'Monthly price sensitivity', sub: 'Share of respondents who state they would pay at least each price', opt: () => ({ grid: { left: 8, right: 20, top: 20, bottom: 6, containLabel: true }, tooltip: { trigger: 'axis', valueFormatter: v => v + '%' },
    xAxis: catAx(w.curve.map(x => '₹' + x.p)), yAxis: valAx({ max: 100, axisLabel: { formatter: '{value}%', color: TC['ink-2'] } }),
    series: [{ type: 'line', data: w.curve.map(x => +(x.d * 100).toFixed(1)), lineStyle: { color: TC.c1, width: 2 }, itemStyle: { color: TC.c1 }, areaStyle: { color: TC.c1, opacity: .1 }, symbolSize: 6, markLine: { silent: true, symbol: 'none', label: { formatter: 'revenue max', color: TC['ink-2'] }, lineStyle: { color: TC.c2 }, data: [{ xAxis: '₹' + w.best.p }] } }] }),
    table: () => ({ head: ['Price', 'Accept'], rows: w.curve.map(x => ['₹' + x.p, pct(x.d)]) }) });
  const sc = store.get('revsc', [{ nm: 'Conservative', price: 99, conv: 3, target: 50000, cac: 250 }, { nm: 'Moderate', price: 149, conv: 6, target: 100000, cac: 200 }, { nm: 'Optimistic', price: 199, conv: 9, target: 200000, cac: 180 }]);
  const rp = panel({ parent: c, span: 6, title: 'Hypothetical subscription revenue scenarios', sub: `Edit any cell. Survey anchor: ${pct(w.paid)} stated paid; ${CFG.haircut}% discount suggests ~${pct(w.paid * (1 - CFG.haircut / 100))} real conversion of engaged users.`, prov: 'projection',
    html: `<div class="tw"><table class="t"><thead><tr><th>Scenario</th><th class="r">Price ₹/mo</th><th class="r">Paid conversion %</th><th class="r">Target customers</th><th class="r">CAC ₹</th></tr></thead><tbody>${sc.map((s, j) => `<tr><td><b>${s.nm}</b></td>${['price', 'conv', 'target', 'cac'].map(k => `<td class="r"><input class="inp num" style="width:96px;text-align:right" type="number" id="rv${j}${k}" data-j="${j}" data-k="${k}" value="${s[k]}"></td>`).join('')}</tr>`).join('')}</tbody></table></div><div id="rvOut" class="tw" style="margin-top:10px"></div>` });
  const calc = () => { const out = sc.map(s => { const pay = s.target * s.conv / 100, mrr = pay * s.price; return { pay, mrr, arr: mrr * 12, acq: s.target * s.cac }; });
    $('#rvOut', rp).innerHTML = tableHTML(['Scenario', 'Paying customers', 'Monthly revenue', 'Annual revenue', 'Acquisition spend', 'Year-1 net of CAC'], sc.map((s, j) => [s.nm, fmtN(out[j].pay), inr(out[j].mrr), inr(out[j].arr), inr(out[j].acq), inr(out[j].arr - out[j].acq)]), { right: [1, 2, 3, 4, 5] }); };
  $$('input', rp).forEach(i => i.oninput = () => { sc[+i.dataset.j][i.dataset.k] = +i.value; store.set('revsc', sc); calc(); }); calc();
  c.insertAdjacentHTML('beforeend', `<div class="s12 note warn"><b>Stated vs actual:</b> survey respondents typically overstate willingness to pay. Treat these figures as upper bounds and validate with a live pricing page or pre-orders. The What-if Simulator models churn, CAC and break-even.</div>`);
});

/* ============================================================ SEG · Customer Segmentation */
page('segments', 'SEG', 'Customer Segmentation', 'Customer Segmentation & Personas', 'Data-derived segments: rule-based personas, K-Means behavioural clusters and Latent Class survey types.', 'understand', c => {
  const ix = IX(), tot = ix.length; if (tot < 30) return emptyState(c);
  const pt = personaTable(ix);
  panel({ parent: c, span: 12, title: 'Persona scorecard', sub: 'Rule-based personas built from respondent answers. Personas overlap, so shares do not add to 100%.', html: `<div class="tw">${tableHTML(['Persona', 'Respondents', '% of view', 'Main challenge', 'Readiness', 'AI index', 'Would use', 'Would pay', 'Median payer ₹', 'Recommended JobSaathi solution'],
    pt.map(p => [`<b>${esc(p.nm)}</b><br><span class="muted" style="font-size:11px">${esc(p.rule)}</span>`, p.m.n, pct(p.m.share), `${esc(L.CHAL[p.pr.topChal])} <span class="muted">${pct(p.pr.topChalP, 0)}</span>`, f1(p.pr.ready, 2), f1(p.m.ai, 0), pct(p.m.interest), pct(p.m.paid), inr(p.pr.wtpPayers), esc(p.sol)]), { right: [1, 2, 4, 5, 6, 7, 8] })}</div>` });
  const ov = pt.map(a => pt.map(b => { let i_ = 0, u = 0; const sa = new Set(a.ix); const sb = new Set(b.ix); for (const x of sa) if (sb.has(x)) i_++; u = sa.size + sb.size - i_; return u ? i_ / u : 0; }));
  const hd = []; ov.forEach((r, y) => r.forEach((v, x) => hd.push([x, y, +(v * 100).toFixed(0)])));
  cpanel({ parent: c, span: 6, title: 'Persona overlap', sub: 'Jaccard similarity (% of the union shared)', h: 'tall', opt: () => heat(PERSONA.map(p => p.split(' ')[0] + ' ' + (p.split(' ')[1] || '')), PERSONA, hd, { fmt: v => v + '%', cell: v => v, rot: 30, vm: false }), table: () => ({ head: ['', ...PERSONA], rows: ov.map((r, k) => [PERSONA[k], ...r.map(v => pct(v, 0))]) }) });
  const radarInd = [['Need', 100], ['Intent %', 100], ['Paid %', 100], ['AI index', 100], ['Readiness ×20', 100]];
  cpanel({ parent: c, span: 6, title: 'Persona profiles', sub: 'Need index, intent, paid share, AI index and readiness on one 0–100 scale', h: 'tall', opt: () => ({ legend: { type: 'scroll', bottom: 0, icon: 'circle', itemWidth: 8, textStyle: { color: TC['ink-2'], fontSize: 10.5 } }, tooltip: { trigger: 'item' },
    radar: { indicator: radarInd.map(([n_, m_]) => ({ name: n_, max: m_ })), radius: '62%', center: ['50%', '46%'], axisName: { color: TC['ink-2'], fontSize: 11 }, splitLine: { lineStyle: { color: TC['line-2'] } }, splitArea: { show: false }, axisLine: { lineStyle: { color: TC.line } } },
    series: [{ type: 'radar', symbol: 'none', data: pt.map((p, k) => ({ name: p.nm, value: [p.m.need, p.m.interest * 100, p.m.paid * 100, p.m.ai, p.pr.ready * 20].map(v => +(v || 0).toFixed(1)), lineStyle: { color: TC.cat[k], width: 2 }, itemStyle: { color: TC.cat[k] }, areaStyle: { opacity: .04, color: TC.cat[k] } })) }] }),
    table: () => ({ head: ['Persona', 'Need', 'Intent', 'Paid', 'AI', 'Readiness'], rows: pt.map(p => [p.nm, f1(p.m.need, 0), pct(p.m.interest), pct(p.m.paid), f1(p.m.ai, 0), f1(p.pr.ready, 2)]) }) });
  const km = Array.from({ length: P.kmK }, (_, k) => { const s = sub(ix, i => D.km[i] === k); return { k, s, m: segMetrics(s, tot), pr: profile(s), nm: clusterName(P.kmCent[k]) }; });
  panel({ parent: c, span: 6, title: `K-Means behavioural clusters (k = ${P.kmK})`, sub: 'Reference solution: Python k-means++, 9 standardised variables, n_init = 20. Re-run live in Model Lab.', prov: 'model',
    html: `<div class="tw">${tableHTML(['Cluster', 'n', '%', 'Need', 'Would use', 'Would pay', 'Top feature'], km.map(x => [`<span class="dot" style="background:${TC.cat[x.k]}"></span> <b>C${x.k + 1}</b> ${esc(x.nm)}`, x.m.n, pct(x.m.share), f1(x.m.need, 0), pct(x.m.interest), pct(x.m.paid), L.FEAT21[x.pr.topF]]), { right: [1, 2, 3, 4, 5] })}</div>` });
  const lc = Array.from({ length: LCA_C }, (_, k) => { const s = sub(ix, i => D.lca[i] === k); let cert = 0; for (const i of s) cert += LCAP[i * LCA_C + k]; return { k, s, m: segMetrics(s, tot), cert: s.length ? cert / s.length : NaN }; });
  panel({ parent: c, span: 6, title: `Latent Class survey types (C = ${LCA_C})`, sub: 'EM-fitted on 7 categorical answers; soft membership. Names assigned after reading item-response probabilities.', prov: 'model',
    html: `<div class="tw">${tableHTML(['Class', 'n (modal)', '%', 'Avg certainty', 'Would use', 'Would pay'], lc.map(x => [`<span class="dot" style="background:${TC.cat[x.k + 4]}"></span> <b>L${x.k + 1}</b> ${LCA_NAMES[x.k]}`, x.m.n, pct(x.m.share), pct(x.cert), pct(x.m.interest), pct(x.m.paid)]), { right: [1, 2, 3, 4, 5] })}</div>` });
  c.insertAdjacentHTML('beforeend', `<div class="s12 note"><b>Clustering limitations.</b> Silhouette scores are low (≈ 0.12 at k = 5), so clusters are soft regions of a continuum rather than separate groups. K-Means needs standardised numeric inputs (ordinal answers were treated as numeric); results depend on k and variable choice. LCA assumes local independence of answers within a class; BIC kept improving up to 6 classes, and 4 were kept for interpretability. Personas are rules, not statistical clusters, and overlap.</div>`);
});

/* ============================================================ NPS · NPS and Sentiment */
let NPS_BY = 'q4', VERB = { th: -1, se: -1, seed: 1 };
page('nps', 'NPS', 'NPS & Sentiment', 'NPS & Customer Sentiment', 'How likely are respondents to recommend JobSaathi, and what do they say about the employment ecosystem?', 'understand', c => {
  const ix = IX(); if (!ix.length) return emptyState(c);
  const ns = nps(ix), dist = freq(D.q24, ix, 11), se = freq(D.sent, ix, 3);
  kpiRow(c, [{ hero: true, l: 'Net Promoter Score', v: `${ns.nps >= 0 ? '+' : ''}${f1(ns.nps)}`, s: `95% CI ${f1(ns.nps - ns.ci)} to ${f1(ns.nps + ns.ci)}`, trace: { f: '% Promoters (9–10) − % Detractors (0–6). Invalid raw codes (−1, 11, 12, 99) set to blank.', code: `${pct(ns.pp)} − ${pct(ns.pd)} = ${f1(ns.nps)}`, rows: [['n answered', fmtN(ns.n)], ['Blank / invalid', fmtN(ix.length - ns.n)]] } },
    { l: 'Promoters (9–10)', v: pct(ns.pp), s: fmtN(ns.P) }, { l: 'Passives (7–8)', v: pct(ns.pa), s: fmtN(ns.Pa) }, { l: 'Detractors (0–6)', v: pct(ns.pd), s: fmtN(ns.De) },
    { l: 'Negative feedback', v: pct(se.c[0] / se.n), s: `${fmtN(se.c[0])} comments` }, { l: 'Positive feedback', v: pct(se.c[2] / se.n), s: `${fmtN(se.c[2])} comments` }]);
  const nc = [TC['div-neg'], TC.muted, TC['div-pos']];
  cpanel({ parent: c, span: 6, title: 'Likelihood to recommend', sub: 'Q24 · 0–10 · coloured by NPS group', opt: () => vbar(Array.from({ length: 11 }, (_, k) => String(k)), dist.c, { colors: dist.c.map((_, k) => nc[k >= 9 ? 2 : k >= 7 ? 1 : 0]) }), table: () => tblCount(Array.from({ length: 11 }, (_, k) => String(k)), dist.c, dist.n), post: legendHTML([[nc[0], 'Detractor 0–6'], [nc[1], 'Passive 7–8'], [nc[2], 'Promoter 9–10']]) });
  const dims = { q4: ['Employment', L.STATUS], q1: ['Age', L.AGE], tier: ['City tier', L.TIER], q2: ['Education', L.EDU], persona: ['Persona', PERSONA] };
  const [dl, labs] = dims[NPS_BY]; const nv = labs.map((_, k) => nps(NPS_BY === 'persona' ? sub(ix, i => D.persona[i] >> k & 1) : sub(ix, i => D[NPS_BY][i] === k)));
  const pnl = cpanel({ parent: c, span: 6, title: `NPS by ${dl.toLowerCase()}`, sub: 'Bar = NPS; tooltip shows n and 95% CI', pre: `<div class="seg" id="npd" style="margin-bottom:6px">${Object.entries(dims).map(([k, [l]]) => `<button data-d="${k}" aria-pressed="${NPS_BY === k}">${l}</button>`).join('')}</div>`,
    opt: () => ({ grid: { left: 8, right: 40, top: 6, bottom: 6, containLabel: true }, tooltip: { formatter: p => `${esc(labs[p.dataIndex])}<br>NPS <b>${f1(nv[p.dataIndex].nps)}</b> ± ${f1(nv[p.dataIndex].ci)} · n ${fmtN(nv[p.dataIndex].n)}` },
      xAxis: valAx({}), yAxis: catAx(labs, { inverse: true, axisLabel: { width: 160, overflow: 'truncate', color: TC['ink-2'] } }),
      series: [{ type: 'bar', barMaxWidth: 16, data: nv.map(v => ({ value: +(v.nps || 0).toFixed(1), itemStyle: { color: v.nps >= 0 ? TC['div-pos'] : TC['div-neg'], borderRadius: v.nps >= 0 ? [0, 4, 4, 0] : [4, 0, 0, 4] } })), label: { show: true, position: 'right', formatter: p => (p.value > 0 ? '+' : '') + p.value, fontSize: 11, color: TC['ink-2'] } }] }),
    table: () => ({ head: [dl, 'n', 'NPS', '95% CI ±', 'Promoters', 'Detractors'], rows: labs.map((l, k) => [l, nv[k].n, f1(nv[k].nps), f1(nv[k].ci), pct(nv[k].pp), pct(nv[k].pd)]) }) });
  $$('#npd button', pnl).forEach(b => b.onclick = () => { NPS_BY = b.dataset.d; render(true); });
  const thc = mfreq(D.themes, sub(ix, i => D.sent[i] >= 0), P.themeKeys.length);
  cpanel({ parent: c, span: 6, title: 'Recurring themes in open feedback', sub: `Q25 · model-classified · ${fmtN(thc.n)} usable comments · a comment can carry several themes · click to read`, h: 'tall',
    opt: () => hbar(P.themeKeys, thc.c, { total: thc.n, lw: 210 }), table: () => tblCount(P.themeKeys, thc.c, thc.n), click: p => { VERB.th = p.data.code; render(true); } });
  const sm = [0, 1, 2].map(cat => { const s = sub(ix, i => D.npsCat[i] === cat); return freq(D.sent, s, 3).c; });
  cpanel({ parent: c, span: 6, title: 'Sentiment by NPS group', sub: 'Row % · lexicon sentiment of Q25', h: 'tall', opt: () => stack100(['Negative', 'Neutral', 'Positive'], ['Detractors', 'Passives', 'Promoters'], sm, [TC['div-neg'], TC['div-mid'], TC['div-pos']], { darkText: false }), table: () => ({ head: ['Group', 'Negative', 'Neutral', 'Positive'], rows: sm.map((r, k) => [['Detractors', 'Passives', 'Promoters'][k], ...r]) }) });
  const pool = sub(ix, i => D.sent[i] >= 0 && (VERB.th < 0 || (D.themes[i] >> VERB.th & 1)) && (VERB.se < 0 || D.sent[i] === VERB.se));
  let s = VERB.seed; const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647; const pick = pool.slice().sort(() => rnd() - .5).slice(0, 12);
  const vp = panel({ parent: c, span: 12, title: 'Verbatim feedback', sub: `${fmtN(pool.length)} matching comments · sample of 12`, prov: 'raw', tools: `<select class="inp" id="vth" style="width:auto"><option value="-1">All themes</option>${P.themeKeys.map((t, k) => `<option value="${k}" ${VERB.th === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <select class="inp" id="vse" style="width:auto"><option value="-1">All sentiment</option>${['Negative', 'Neutral', 'Positive'].map((t, k) => `<option value="${k}" ${VERB.se === k ? 'selected' : ''}>${t}</option>`).join('')}</select><button class="btn sm" id="vsh">Shuffle</button>`,
    html: `<div class="tw">${tableHTML(['ID', 'Comment (as written)', 'Sentiment', 'Themes', 'Q24'], pick.map(i => [`<span class="mono">${D.id[i]}</span>`, esc(P.texts[P.text[i]]), ['Negative', 'Neutral', 'Positive'][D.sent[i]], P.themeKeys.filter((_, b) => D.themes[i] >> b & 1).join(', ') || '–', D.q24[i] >= 0 ? String(D.q24[i]) : '–']), { autoRight: false })}</div>` });
  $('#vth', vp).onchange = e => { VERB.th = +e.target.value; render(true); }; $('#vse', vp).onchange = e => { VERB.se = +e.target.value; render(true); }; $('#vsh', vp).onclick = () => { VERB.seed = (VERB.seed * 7 + 3) % 9973 + 1; render(true); };
  const drv = regFit('rec', 'ridge', 1, ix);
  if (drv) { const top = drv.coef.map((b, j) => [REG_F[j], b]).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1])).slice(0, 8);
    cpanel({ parent: c, span: 6, title: 'What drives likelihood to recommend', sub: `Ridge regression (λ = 1) on standardised drivers · test R² ${f1(drv.r2te, 3)} · full model in Model Lab`, prov: 'model',
      opt: () => ({ grid: { left: 8, right: 40, top: 6, bottom: 6, containLabel: true }, tooltip: { formatter: p => `${p.name}<br>β = ${p.value}` }, xAxis: valAx({}), yAxis: catAx(top.map(t => t[0]), { inverse: true }),
        series: [{ type: 'bar', barMaxWidth: 14, data: top.map(t => ({ value: +t[1].toFixed(3), itemStyle: { color: t[1] >= 0 ? TC['div-pos'] : TC['div-neg'] } })), label: { show: true, position: 'right', fontSize: 10.5, color: TC['ink-2'], formatter: p => p.value.toFixed(2) } }] }),
      table: () => ({ head: ['Driver', 'Standardised β'], rows: top.map(t => [t[0], f1(t[1], 3)]) }) }); }
  panel({ parent: c, span: drv ? 6 : 12, title: 'How sentiment and themes are classified', prov: 'model', html: `<p style="margin:0 0 8px">A transparent lexicon model: score = positive-word hits − negative-word hits (positive > 0, negative < 0, neutral = 0). Themes are keyword rules; one comment can carry several. Blank and junk answers ("NA", "-", "nil") are excluded.</p>
    <div class="kv"><span>Positive lexicon</span><b style="text-align:left">${P.posLex.join(', ')}</b><span>Negative lexicon</span><b style="text-align:left">${P.negLex.slice(0, 14).join(', ')}…</b><span>Agreement with generator's primary theme</span><b>${pct(P.meta.theme_agreement)}</b></div>
    <div class="note warn" style="margin-top:8px">Model-generated analysis of synthetic feedback. Agreement is optimistic because the keyword list and the synthetic comments share vocabulary; real comments would score lower. Sarcasm and mixed sentiment are not handled.</div>` });
});
