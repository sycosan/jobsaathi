/* ============================================================ DEX · Data Explorer */
const DX = { q: '', sort: 'id', dir: 1, page: 0, size: 25, layer: 'clean' };
const DXCOLS = [['id', 'ID', i => D.id[i], i => i], ['age', 'Age', i => lab(D.q1, i, L.AGE), i => D.q1[i]], ['edu', 'Education', i => lab(D.q2, i, L.EDU), i => D.q2[i]], ['city', 'City', i => DX.layer === 'raw' ? P.rawCityU[P.rawCity[i]] : lab(D.q3, i, L.CITY), i => D.q3[i]],
  ['st', 'Status', i => lab(D.q4, i, L.STATUS), i => D.q4[i]], ['exp', 'Experience', i => lab(D.q5, i, L.EXP), i => D.q5[i]], ['q6', 'Q6', i => DX.layer === 'raw' && RAWO[i]?.q6_difficulty !== undefined ? `<span style="color:var(--crit-ink)">${RAWO[i].q6_difficulty}</span>` : sc(D.q6, i), i => D.q6[i]],
  ['q13', 'Q13', i => DX.layer === 'raw' && RAWO[i]?.q13_readiness !== undefined ? `<span style="color:var(--crit-ink)">${RAWO[i].q13_readiness}</span>` : sc(D.q13, i), i => D.q13[i]], ['ai', 'AI idx', i => isN(D.ai[i]) ? D.ai[i].toFixed(0) : '', i => isN(D.ai[i]) ? D.ai[i] : -1],
  ['q20', 'Intent', i => lab(D.q20, i, L.INTENT), i => -D.q20[i]], ['q22', 'WTP', i => lab(D.q22, i, L.WTP), i => D.q22[i]], ['q24', 'Q24', i => DX.layer === 'raw' && RAWO[i]?.q24_nps !== undefined ? `<span style="color:var(--crit-ink)">${RAWO[i].q24_nps}</span>` : sc(D.q24, i), i => D.q24[i]],
  ['prop', 'Propensity', i => D.prop[i].toFixed(2), i => D.prop[i]], ['km', 'Cluster', i => 'C' + (D.km[i] + 1), i => D.km[i]], ['dq', 'Quality', i => `<span class="pill ${['strong', 'moderate', 'limited'][D.dq[i]]}">${DQL[D.dq[i]]}</span>`, i => D.dq[i]]];
page('explorer', 'DEX', 'Data Explorer', 'Respondent Data Explorer', 'Search, sort, filter and export respondent-level records. Click a row for the full 25-question response.', 'data', c => {
  const ix = Array.from(IX()); const q = DX.q.trim().toLowerCase();
  let rows = q ? ix.filter(i => D.id[i].toLowerCase().includes(q) || (P.texts[P.text[i]] || '').toLowerCase().includes(q) || (P.otherCity[i] >= 0 && P.otherCityU[P.otherCity[i]].toLowerCase().includes(q))) : ix;
  const col = DXCOLS.find(x => x[0] === DX.sort); rows = rows.slice().sort((a, b) => { const va = col[3](a), vb = col[3](b); return (va < vb ? -1 : va > vb ? 1 : 0) * DX.dir; });
  const pages = Math.max(1, Math.ceil(rows.length / DX.size)); DX.page = Math.min(DX.page, pages - 1); const pg = rows.slice(DX.page * DX.size, (DX.page + 1) * DX.size);
  const p = panel({ parent: c, span: 12, title: `${fmtN(rows.length)} records`, sub: 'Filters from the top strip apply. Search matches respondent ID, other-city name or open-text comment.', prov: DX.layer === 'raw' ? 'raw' : 'clean',
    tools: `<div class="seg" id="dxL"><button data-l="raw" aria-pressed="${DX.layer === 'raw'}">Raw values</button><button data-l="clean" aria-pressed="${DX.layer === 'clean'}">Cleaned values</button></div>`,
    html: `<div class="flex" style="margin-bottom:10px"><input class="inp" id="dxq" type="search" placeholder="Search ID (e.g. JS-00042) or text" value="${esc(DX.q)}" style="max-width:320px"><select class="inp" id="dxs" style="width:auto">${[25, 50, 100].map(n => `<option ${DX.size === n ? 'selected' : ''}>${n}</option>`).join('')}</select><span class="muted" style="font-size:12px">per page</span>
      <span style="flex:1"></span><button class="btn" id="dxcsv">Export view · CSV</button><button class="btn" id="dxxl">Export view · Excel</button></div>
      <div class="tw" style="max-height:620px"><table class="t"><thead><tr>${DXCOLS.map(([k, l]) => `<th class="sort" data-s="${k}">${l}${DX.sort === k ? (DX.dir > 0 ? ' ▲' : ' ▼') : ''}</th>`).join('')}</tr></thead>
      <tbody>${pg.map(i => `<tr class="click" data-i="${i}">${DXCOLS.map(([k, , f]) => `<td class="${k === 'id' ? 'mono' : ''}">${f(i)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${DXCOLS.length}" class="empty">No records match.</td></tr>`}</tbody></table></div>
      <div class="flex" style="margin-top:10px"><button class="btn sm" id="dxp" ${DX.page ? '' : 'disabled'}>← Previous</button><span class="mono" style="font-size:12px">page ${DX.page + 1} of ${pages}</span><button class="btn sm" id="dxn" ${DX.page < pages - 1 ? '' : 'disabled'}>Next →</button>
      ${DX.layer === 'raw' ? '<span class="muted" style="font-size:12px">Red values are invalid raw codes that the cleaned layer sets to blank. City shows the raw label as typed.</span>' : ''}</div>` });
  const dq = $('#dxq', p); let tmo; dq.oninput = () => { clearTimeout(tmo); tmo = setTimeout(() => { DX.q = dq.value; DX.page = 0; render(true); setTimeout(() => { const e = $('#dxq'); e.focus(); e.setSelectionRange(e.value.length, e.value.length); }, 0); }, 250); };
  $('#dxs', p).onchange = e => { DX.size = +e.target.value; DX.page = 0; render(true); };
  $$('[data-s]', p).forEach(th => th.onclick = () => { if (DX.sort === th.dataset.s) DX.dir *= -1; else { DX.sort = th.dataset.s; DX.dir = 1; } render(true); });
  $$('[data-l]', p).forEach(b => b.onclick = () => { DX.layer = b.dataset.l; render(true); });
  $('#dxp', p).onclick = () => { DX.page--; render(true); }; $('#dxn', p).onclick = () => { DX.page++; render(true); };
  $$('tr[data-i]', p).forEach(tr => tr.onclick = () => openRespondent(+tr.dataset.i));
  $('#dxcsv', p).onclick = () => saveFile(`jobsaathi-explorer-${rows.length}.csv`, csv(recordHead('analytical'), rows.map(i => record(i, 'analytical'))));
  $('#dxxl', p).onclick = () => { const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, readme(), 'README'); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([recordHead('analytical'), ...rows.map(i => record(i, 'analytical'))]), 'Records'); saveFile(`jobsaathi-explorer-${rows.length}.xlsx`, new Uint8Array(XLSX.write(wb, { type: 'array', bookType: 'xlsx' }))); };
});
function openRespondent(i) {
  const h = recordHead('analytical'), r = record(i, 'analytical'); const raw = record(i, 'raw'), rh = recordHead('raw');
  const pr = lcaRow(i); const flags = FLAGS.filter((_, b) => D.flags[i] >> b & 1);
  const qa = h.map((k, j) => [k, r[j]]).filter(([k]) => k.startsWith('Q'));
  drawer(D.id[i], `<div class="flex"><span class="pill ${['strong', 'moderate', 'limited'][D.dq[i]]}">${DQL[D.dq[i]]}</span>${flags.map(f => `<span class="pill limited">${f}</span>`).join('')}<span class="pill">Split: ${['train', 'test', 'unlabelled'][P.split[i]]}</span></div>
    <div class="kv">${qa.map(([k, v]) => `<span>${esc(k.replace(/^Q(\d+)_/, 'Q$1 · ').replace(/_/g, ' '))}</span><b style="text-align:left">${esc(v === '' ? '— blank —' : v)}</b>`).join('')}</div>
    ${RAWO[i] || P.rawCityU[P.rawCity[i]] !== lab(D.q3, i, L.CITY) ? `<div class="note warn"><b>Raw → cleaned changes:</b> ${[P.rawCityU[P.rawCity[i]] !== lab(D.q3, i, L.CITY) ? `city "${esc(P.rawCityU[P.rawCity[i]])}" → ${esc(lab(D.q3, i, L.CITY))}` : '', ...Object.entries(RAWO[i] || {}).map(([k, v]) => `${k} raw value ${v} → blank (invalid)`)].filter(Boolean).join('; ')}</div>` : ''}
    <div><h4 style="margin:0 0 6px;font:600 11px var(--f-mono);letter-spacing:.08em;color:var(--muted)">DERIVED & MODEL OUTPUTS</h4><div class="kv">
      <span>AI Adoption Index</span><b>${isN(D.ai[i]) ? f1(D.ai[i]) : '–'}</b><span>Skill gaps (count)</span><b>${isN(D.gap[i]) ? D.gap[i] : '–'}</b><span>Personas</span><b>${esc(ml(D.persona[i], PERSONA) || '–')}</b>
      <span>K-Means cluster</span><b>C${D.km[i] + 1} · ${esc(clusterName(P.kmCent[D.km[i]]))}</b><span>Paid propensity (GBT, out-of-fold)</span><b>${pct(D.prop[i])}</b><span>Sentiment / themes</span><b>${['Negative', 'Neutral', 'Positive'][D.sent[i]] || '–'} · ${P.themeKeys.filter((_, b) => D.themes[i] >> b & 1).join(', ') || '–'}</b></div></div>
    <div><h4 style="margin:0 0 6px;font:600 11px var(--f-mono);letter-spacing:.08em;color:var(--muted)">LATENT CLASS MEMBERSHIP</h4>${LCA_NAMES.map((nm, k) => `<div style="display:grid;grid-template-columns:150px 1fr 40px;gap:6px;align-items:center;font-size:12px;margin:3px 0"><span>${nm}</span><span style="background:var(--line-2);height:8px;border-radius:3px;overflow:hidden"><i style="display:block;height:100%;width:${pr[k] * 100}%;background:${TC.cat[k + 4]}"></i></span><b class="num">${pct(pr[k], 0)}</b></div>`).join('')}</div>`, 'Respondent record · synthetic');
}

/* ============================================================ DQM · Data Quality */
page('quality', 'DQM', 'Data Quality', 'Data Quality Monitoring', 'Every record is kept. Missing and invalid values are counted, flagged and excluded only from the analyses they affect.', 'data', c => {
  const all = Array.from({ length: N }, (_, i) => i); const ids = new Set(D.id); const dq = freq(D.dq, all, 3);
  const fc = FLAGS.map((_, b) => D.flags.reduce((s, f) => s + (f >> b & 1), 0)); const core = ['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7', 'q8', 'q9', 'q10', 'q13', 'q14', 'q15', 'q16', 'q17', 'q18', 'q20', 'q21', 'q22', 'q23', 'q24'];
  const missCols = core.map(k => [k.toUpperCase(), D[k].reduce((s, v) => s + (v < 0 ? 1 : 0), 0)]).concat([['Q11/Q12', D.q11.reduce((s, v) => s + (v < 0), 0)], ['Q25 (blank)', P.text.reduce((s, t) => s + (P.texts[t] === '' ? 1 : 0), 0)], ['Salary', D.sal.reduce((s, v) => s + (isN(v) ? 0 : 1), 0)]]);
  const cells = N * (core.length + 2 + 1); const missT = missCols.reduce((s, x) => s + x[1], 0);
  kpiRow(c, [{ hero: true, l: 'Total respondents', v: fmtN(N), s: `${P.cols.q1.length} records loaded` }, { l: 'Unique respondent IDs', v: fmtN(ids.size), s: ids.size === N ? 'no duplicate IDs' : 'duplicate IDs found' },
    { l: 'Complete records', v: pct(dq.c[0] / N), s: fmtN(dq.c[0]) }, { l: 'Usable – partial', v: pct(dq.c[1] / N), s: fmtN(dq.c[1]) }, { l: 'Flagged records', v: pct(dq.c[2] / N), s: fmtN(dq.c[2]) },
    { l: 'Cell completeness', v: pct(1 - missT / cells), s: `${fmtN(missT)} blank cells`, trace: { f: '1 − blank answers ÷ (records × 24 answer fields). Q11 and Q12 are counted once each.', rows: [['Blank cells', fmtN(missT)], ['Answer cells', fmtN(cells)]] } },
    { l: 'Possible duplicate submissions', v: fmtN(fc[4]), s: 'identical answers, new ID' }, { l: 'Invalid codes corrected', v: fmtN(P.rawOver.length), s: `${fmtN(fc[5])} records` }]);
  cpanel({ parent: c, span: 7, title: 'Missing values by question', sub: 'Blank answers in the cleaned dataset (includes invalid raw codes set to blank)', h: 'tall', opt: () => vbar(missCols.map(x => x[0]), missCols.map(x => x[1]), { fmt: v => v ? fmtN(v) : '', colors: missCols.map(x => x[1] / N > .03 ? TC.c2 : TC.c3), lw: 40 }),
    table: () => ({ head: ['Field', 'Blank', '% of records'], rows: missCols.map(x => [x[0], x[1], pct(x[1] / N, 2)]) }), post: legendHTML([[TC.c2, '> 3% blank'], [TC.c3, '≤ 3% blank']]) });
  const rules = [['Inconsistent age/experience', 'Age 18–21 or Fresher reporting 5+ years experience', 'Kept; excluded only if the rule toggle is on', 0], ['Inconsistent applications/interviews', '0 applications but 1+ interviews', 'Kept; excluded from funnel and interview-conversion metrics', 1],
    ['Straight-liner', 'Same answer on all five 1–5 scale questions', 'Kept; optional exclusion', 2], ['Speeder (< 120 s)', 'Completed in under 2 minutes (median ≈ 9 min)', 'Kept; optional exclusion', 3], ['Possible duplicate', 'Every answer identical to an earlier record', 'Kept; optional exclusion', 4], ['Invalid code corrected', 'Out-of-range raw value (e.g. Q24 = 11)', 'Value set to blank; record kept', 5]];
  const ep = panel({ parent: c, span: 5, title: 'Quality flags & exclusion rules', sub: 'Toggle a rule to exclude those records from every page', prov: 'clean',
    html: `<div class="tw">${tableHTML(['Flag', 'Records', 'Handling'], rules.map(r => [`<b>${r[0]}</b><br><span class="muted" style="font-size:11px">${r[1]}</span>`, fc[r[3]], r[2]]), { autoRight: false, right: [1] })}</div>
    <div class="stack" style="margin-top:10px">${[['inconsistent', 'Exclude inconsistent records'], ['straight', 'Exclude straight-liners'], ['speeder', 'Exclude speeders'], ['dup', 'Exclude possible duplicates']].map(([k, l]) => `<label class="flex" style="gap:8px"><input type="checkbox" data-x="${k}" ${CFG.ex[k] ? 'checked' : ''}> ${l}</label>`).join('')}</div>` });
  $$('[data-x]', ep).forEach(cb => cb.onchange = () => { CFG.ex[cb.dataset.x] = cb.checked; saveCfg(); refresh(); });
  const cv = {}; P.rawCity.forEach((r, i) => { const rl = P.rawCityU[r], cl = lab(D.q3, i, L.CITY); if (rl !== cl && !(D.q3[i] === 11)) { const k = rl + '→' + cl; cv[k] = (cv[k] || 0) + 1; } });
  const other = P.rawCity.reduce((s, r, i) => s + (D.q3[i] === 11 ? 1 : 0), 0);
  panel({ parent: c, span: 6, title: 'Raw → cleaned transformations', sub: 'City labels standardised; out-of-range codes blanked', prov: 'clean', html: `<div class="tw" style="max-height:320px">${tableHTML(['Raw value', 'Cleaned value', 'Records'], Object.entries(cv).sort((a, b) => b[1] - a[1]).map(([k, v]) => [esc(k.split('→')[0]), esc(k.split('→')[1]), v])
    .concat(Object.entries(P.rawOver.reduce((m, [r, c_, v]) => { const k = c_ + ' = ' + v; m[k] = (m[k] || 0) + 1; return m; }, {})).map(([k, v]) => [esc(k), '(blank)', v])), { right: [2] })}</div>
    <p class="muted" style="font-size:12px;margin:8px 0 0">${fmtN(other)} "Other Tier 2/3" respondents typed a city name (e.g. Indore, Nagpur) kept as <span class="mono">Q3_other_city_name</span>.</p>` });
  const inc = [['Executive KPIs & distributions', 'All records in view; each KPI uses respondents who answered that question', N], ['Funnel & interview conversion', 'Excludes inconsistent apps/interviews and blanks', all.filter(i => !(D.flags[i] & 2) && isN(D.apps[i]) && isN(D.intv[i])).length],
    ['Skill-gap analytics', 'Excludes blank Q11/Q12', all.filter(i => D.q11[i] >= 0).length], ['AI Adoption Index', 'Needs ≥ 2 of Q16, Q17, Q18', all.filter(i => isN(D.ai[i])).length], ['NPS', 'Excludes blank / invalid Q24', all.filter(i => D.npsCat[i] >= 0).length],
    ['Willingness to pay & classifiers', 'Excludes blank Q22', all.filter(i => isN(D.paid[i])).length], ['Sentiment & themes', 'Excludes blank and junk text (NA, -, nil)', all.filter(i => D.sent[i] >= 0).length], ['K-Means & LCA', 'All records; blanks median-imputed (K-Means) or skipped in the likelihood (LCA)', N]];
  panel({ parent: c, span: 6, title: 'Records included in each analysis', sub: 'Full sample, before filters', html: `<div class="tw">${tableHTML(['Analysis', 'Rule', 'Records', '%'], inc.map(r => [r[0], `<span class="muted">${r[1]}</span>`, r[2], pct(r[2] / N)]), { autoRight: false, right: [2, 3] })}</div>` });
  panel({ parent: c, span: 12, title: 'Data layers and provenance', sub: 'Every panel carries a tag showing which layer it draws on', prov: '', html: `<div class="pipe">${[['raw', 'Raw synthetic survey data'], ['clean', 'Cleaned data'], ['calc', 'Calculated results'], ['model', 'Model-generated insights'], ['inferred', 'Inferred opportunities'], ['projection', 'Hypothetical projections']].map(([k, l]) => `<span>${provChip(k)} ${l}</span>`).join('')}</div>
    <p style="margin:10px 0 0;font-size:12.5px">Generated once in Python with fixed seed <b class="mono">${P.meta.seed}</b> and embedded in this page, so every viewer sees the same 5,000 records. Raw, cleaned and analytical layers export separately from the Export menu.</p>` });
});

/* ============================================================ CFG · Settings */
page('config', 'CFG', 'Settings', 'Settings & Methodology', 'Display preferences, analyst assumptions and how the synthetic data was generated. Settings are saved in this browser only.', 'data', c => {
  const sp = panel({ parent: c, span: 6, title: 'Display', prov: '', html: `<div class="stack"><div class="ctl"><span class="lab">Theme</span><div class="seg">${['system', 'light', 'dark'].map(t => `<button data-th="${t}" aria-pressed="${CFG.theme === t}">${t}</button>`).join('')}</div></div>
    <div class="ctl"><span class="lab">Number format</span><div class="seg"><button data-nf="in" aria-pressed="${CFG.numfmt === 'in'}">Indian (12,34,567 · ₹ L / Cr)</button><button data-nf="intl" aria-pressed="${CFG.numfmt === 'intl'}">International (1,234,567 · K / M)</button></div></div>
    <div class="ctl"><label for="minN">Minimum group size for insights <output>${CFG.minN}</output></label><input type="range" id="minN" min="20" max="300" step="10" value="${CFG.minN}"></div></div>` });
  $$('[data-th]', sp).forEach(b => b.onclick = () => { CFG.theme = b.dataset.th; saveCfg(); $$('[data-theme-set]').forEach(x => x.setAttribute('aria-pressed', x.dataset.themeSet === CFG.theme)); applyTheme(); render(true); });
  $$('[data-nf]', sp).forEach(b => b.onclick = () => { CFG.numfmt = b.dataset.nf; saveCfg(); render(true); });
  $('#minN', sp).onchange = e => { CFG.minN = +e.target.value; saveCfg(); render(true); };
  const ap = panel({ parent: c, span: 6, title: 'Analyst assumptions', prov: 'inferred', html: `<div class="stack"><div class="ctl-grid">${['Familiarity (Q16)', 'Usage (Q17)', 'Trust (Q18)'].map((l, k) => `<div class="ctl"><label for="aw${k}">AI index weight: ${l}</label><input type="number" id="aw${k}" min="0" max="100" value="${CFG.aiW[k]}"></div>`).join('')}</div>
    <div class="ctl"><label for="hc">Stated-to-actual WTP discount <output>${CFG.haircut}%</output></label><input type="range" id="hc" min="0" max="90" step="5" value="${CFG.haircut}"></div>
    <p class="muted" style="font-size:12px;margin:0">The discount reduces stated paid intent before it seeds simulator conversion rates. Survey research commonly finds stated purchase intent overstates behaviour; the default is a planning assumption, not a measured value.</p>
    <button class="btn" id="resetAll">Reset all settings, filters and scenarios</button></div>` });
  [0, 1, 2].forEach(k => $('#aw' + k, ap).onchange = e => { CFG.aiW[k] = Math.max(0, +e.target.value || 0); saveCfg(); computeAI(); _memo.key = null; render(true); });
  $('#hc', ap).onchange = e => { CFG.haircut = +e.target.value; SIM = null; store.set('sim', null); saveCfg(); render(true); };
  const rb = $('#resetAll', ap); rb.onclick = () => { if (rb.dataset.c) { try { ['cfg', 'sim', 'revsc', 'mkt'].forEach(k => localStorage.removeItem('js.' + k)); } catch (e) {} location.reload(); } else { rb.dataset.c = 1; rb.textContent = 'Click again to confirm reset'; rb.classList.add('pri'); } };
  panel({ parent: c, span: 12, title: 'Synthetic generation assumptions', sub: 'All distributions are configurable assumptions in gen.py, not population statistics', prov: 'raw', html: `<div class="tw">${tableHTML(['Variable', 'Assumption'], [
    ['Sample', `Exactly ${fmtN(N)} respondents, IDs JS-00001 to JS-05000, fixed seed ${P.meta.seed}, collected 1 Sep – 15 Oct 2026 (simulated)`],
    ['Age (Q1)', '18–21 17% · 22–25 27% · 26–30 22% · 31–35 14% · 36–45 13% · 45+ 7%'], ['Employment (Q4)', 'Conditional on age: students dominate 18–21; employment rises with age; career-changers peak 26–35'],
    ['Education (Q2)', 'Conditional on age; undergraduate is the modal level'], ['City (Q3)', '8 Tier-1 metros 60% · Jaipur/Lucknow/Chandigarh 11% · other Tier 2/3 29% (36 named towns)'],
    ['Latent traits', 'Skill (education, experience, metro), digital affinity (younger, educated, metro) and status distress drive later answers through noisy logistic / threshold models'],
    ['Relationships', 'Experience → salary · skill → readiness · difficulty → lower confidence · AI familiarity → usage → trust · skill gaps → upskilling interest · status & intent → WTP · applications ↛ proportional interviews'],
    ['Injected noise', 'Missing values 2–5% on 12 fields · 80 invalid codes · 253 raw city label variants · ~85 inconsistent answers · 61 straight-liners · 54 speeders · 9 duplicate submissions · 225 deliberately unusual but valid combinations'],
    ['Open text (Q25)', 'Template + Hinglish phrases with varied case, spelling, prefixes and suffixes; 4% blank, 70 junk answers'],
    ['Engine', `${P.meta.engine}; browser engine: Apache ECharts, SheetJS, jsPDF; tests and regressions recomputed in JavaScript`]], { autoRight: false })}</div>` });
  panel({ parent: c, span: 12, title: 'Methodology notes', prov: '', html: `<ul style="margin:0;padding-left:18px;display:grid;gap:4px;font-size:12.5px">
    <li><b>Perceived demand.</b> Q12 measures what respondents believe employers want. It is not employer demand.</li>
    <li><b>Stated vs actual.</b> Willingness to pay and intent are stated; projections are hypothetical and apply an editable discount.</li>
    <li><b>Market size.</b> Respondent concentration is not TAM. Illustrative sizing uses separate, editable inputs.</li>
    <li><b>Classifiers.</b> Target = Q22 ≠ Free only. 27 features, median imputation, stratified 70/30 split, scikit-learn defaults except where shown. K chosen by test AUC; tree depth by test AUC; boosting rounds by minimum test log-loss.</li>
    <li><b>Clustering.</b> K-Means on 9 z-scored variables; LCA via EM with 12 random starts, missing answers skipped in the likelihood. Cluster names are generated from the two largest centroid deviations.</li>
    <li><b>Inference.</b> Two-sided tests; effect sizes reported with conventional thresholds. Large n makes small effects significant. No causal claims.</li></ul>` });
});

/* ============================================================ exports */
function readme() { return XLSX.utils.aoa_to_sheet([['SYNTHETIC DEMONSTRATION DATA – 5,000 RESPONDENTS. THESE ARE NOT ACTUAL JOBSAATHI CUSTOMERS OR REAL SURVEY PARTICIPANTS.'], [], ['View', filterSentence().replace(/<[^>]+>/g, '')], ['Records in view', IX().length], ['Generated', new Date().toISOString().slice(0, 16)], ['Seed', P.meta.seed]]); }
function summaries(ix) {
  const pr = profile(ix), w = wtpStats(ix), ns = nps(ix), fs = featureStats(ix), sg = skillGap(ix), pt = personaTable(ix), recs = recommendations(ix);
  return { kpi: [['Metric', 'Value', 'n'], ['Respondents', ix.length, ix.length], ['Avg job-search difficulty (1–5)', +pr.diff.toFixed(3), nValid(D.diff, ix)], ['Avg industry readiness (1–5)', +pr.ready.toFixed(3), nValid(D.ready, ix)], ['AI Adoption Index', +pr.ai.toFixed(2), nValid(D.ai, ix)],
    ['Product interest (top-2)', +pr.top2.p.toFixed(4), pr.top2.n], ['Willing to pay ₹99+', +w.paid.toFixed(4), w.n], ['Median payer WTP (₹)', w.medPayer, w.n], ['NPS', +ns.nps.toFixed(2), ns.n], ['NPS 95% CI ±', +ns.ci.toFixed(2), ns.n]],
    skills: [['Skill', 'Held %', 'Perceived demand %', 'Gap (pp)', 'Hold it', 'Lack it', 'n'], ...sg.map(s => [s.s, +(s.have * 100).toFixed(2), +(s.dem * 100).toFixed(2), +s.gap.toFixed(2), s.haveN, s.gapN, s.n])],
    feats: [['Feature', 'Interest %', 'First choice %', 'First-choice n', 'Paid share of choosers %', 'Priority score', 'Demand class'], ...fs.f21.map(f => [f.f, +(f.intP * 100).toFixed(2), +(f.primP * 100).toFixed(2), f.prim, +(f.paidP * 100).toFixed(2), +f.score.toFixed(1), f.cls])],
    wtp: [['Band', 'Respondents', '%'], ...L.WTP.map((b, k) => [b, w.f.c[k], +(w.sh[k] * 100).toFixed(2)])],
    pers: [['Persona', 'Rule', 'n', '% of view', 'Need index', 'Intent %', 'Paid %', 'AI index', 'Recommended solution'], ...pt.map(p => [p.nm, p.rule, p.m.n, +(p.m.share * 100).toFixed(2), +p.m.need.toFixed(1), +(p.m.interest * 100).toFixed(2), +(p.m.paid * 100).toFixed(2), +p.m.ai.toFixed(1), p.sol])],
    nps: [['Group', 'Respondents', '%'], ['Promoters', ns.P, +(ns.pp * 100).toFixed(2)], ['Passives', ns.Pa, +(ns.pa * 100).toFixed(2)], ['Detractors', ns.De, +(ns.pd * 100).toFixed(2)], ['NPS', +ns.nps.toFixed(2), '']],
    recs: [['Rank', 'Type', 'Recommendation', 'Finding', 'Action', 'Measure', 'Segment', 'n', 'Score', 'Evidence', 'Limitation'], ...recs.map((r, k) => [k + 1, r.type, r.title, r.finding, r.action, r.measure, r.segment, r.n, +r.total.toFixed(1), EVL[r.ev], r.limit])], recsRaw: recs, pr, w, ns };
}
function exportXLSX() {
  if (!window.XLSX) return toast('Excel library did not load. Try CSV instead.');
  const ix = Array.from(IX()), S_ = summaries(ix), wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, readme(), 'README');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([recordHead('analytical'), ...ix.map(i => record(i, 'analytical'))]), 'Filtered_data');
  [['KPIs', S_.kpi], ['Skill_gaps', S_.skills], ['Features', S_.feats], ['WTP', S_.wtp], ['Personas', S_.pers], ['NPS', S_.nps], ['Recommendations', S_.recs]].forEach(([n_, a]) => XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(a), n_));
  saveFile(`jobsaathi-workbook-${ix.length}.xlsx`, new Uint8Array(XLSX.write(wb, { type: 'array', bookType: 'xlsx' })));
}
const LIGHT_TC = { panel: '#ffffff', 'panel-2': '#f5f7f9', ink: '#101b2b', 'ink-2': '#47546a', muted: '#6f7b8e', line: '#d9dfe7', 'line-2': '#e8ecf1' };
function offChart(build, w = 900, h = 380) { const keep = TC; TC = { ...TC, ...LIGHT_TC }; const d = document.createElement('div'); d.style.cssText = `position:fixed;left:-9999px;top:0;width:${w}px;height:${h}px`; document.body.appendChild(d);
  const ch = echarts.init(d, null, { renderer: 'canvas' }); ch.setOption(baseOpt({ ...build(), animation: false })); const u = ch.getDataURL({ type: 'png', pixelRatio: 2, backgroundColor: '#ffffff' }); ch.dispose(); d.remove(); TC = keep; return u; }
function exportPDF() {
  if (!window.jspdf) return toast('PDF library did not load. Try the HTML report.');
  const ix = Array.from(IX()), S_ = summaries(ix); const { jsPDF } = window.jspdf; const doc = new jsPDF({ unit: 'pt', format: 'a4' }); const W = doc.internal.pageSize.getWidth();
  const pr = S_.pr, w = S_.w, ns = S_.ns;
  doc.setFillColor(11, 31, 58); doc.rect(0, 0, W, 70, 'F'); doc.setTextColor(255); doc.setFont('helvetica', 'bold'); doc.setFontSize(18); doc.text('JobSaathi - Executive Intelligence Report', 36, 40); doc.setFontSize(9); doc.setFont('helvetica', 'normal'); doc.text(`Generated ${new Date().toISOString().slice(0, 10)} | ${ix.length} respondents in view | seed ${P.meta.seed}`, 36, 57);
  doc.setFillColor(255, 243, 214); doc.rect(0, 70, W, 22, 'F'); doc.setTextColor(168, 106, 0); doc.setFontSize(8.5); doc.setFont('helvetica', 'bold'); doc.text('SYNTHETIC DEMONSTRATION DATA - 5,000 RESPONDENTS. NOT ACTUAL JOBSAATHI CUSTOMERS OR REAL SURVEY PARTICIPANTS.', 36, 84);
  const clean = s => String(s).replace(/<[^>]+>/g, '').replace(/₹/g, 'Rs ').replace(/[–—]/g, '-').replace(/[→]/g, '->').replace(/[≥]/g, '>=').replace(/[≤]/g, '<=').replace(/[·]/g, '|').replace(/[^\x00-\xff]/g, '');
  doc.setTextColor(16, 27, 43); doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.text(doc.splitTextToSize('View: ' + clean(filterSentence()), W - 72), 36, 110);
  const kb = [['Respondents in view', fmtN(ix.length)], ['Avg job-search difficulty (1-5)', f1(pr.diff, 2)], ['Avg industry readiness (1-5)', f1(pr.ready, 2)], ['AI Adoption Index (0-100)', f1(pr.ai, 1)], ['Product interest (top-2)', pct(pr.top2.p)], ['Willing to pay Rs 99+/month', pct(w.paid)], ['Median payer WTP', clean(inr(w.medPayer))], ['Revenue-maximising stated price', clean(inr(w.best.p))], ['Net Promoter Score', `${f1(ns.nps)} (+/- ${f1(ns.ci)})`]];
  doc.autoTable({ startY: 124, head: [['Metric', 'Value']], body: kb, theme: 'grid', styles: { fontSize: 8.5 }, headStyles: { fillColor: [0, 143, 138] }, margin: { left: 36, right: 36 } });
  let y = doc.lastAutoTable.finalY + 18; doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text('Ranked recommendations (Data-to-Decision engine)', 36, y);
  doc.autoTable({ startY: y + 8, head: [['#', 'Recommendation', 'Action', 'n', 'Score', 'Evidence']], body: S_.recsRaw.slice(0, 8).map((r, k) => [k + 1, clean(r.title), clean(r.action), r.n, r.total.toFixed(0), EVL[r.ev]]), theme: 'grid', styles: { fontSize: 7.5, cellPadding: 3 }, headStyles: { fillColor: [11, 31, 58] }, columnStyles: { 1: { cellWidth: 130 }, 2: { cellWidth: 230 } }, margin: { left: 36, right: 36 } });
  doc.addPage(); const sg = skillGap(ix).filter(s => s.j < 11).sort((a, b) => b.gap - a.gap);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.setTextColor(16, 27, 43); doc.text('Perceived skill gaps (demand % - held %)', 36, 44);
  doc.addImage(offChart(() => ({ grid: { left: 10, right: 60, top: 10, bottom: 10, containLabel: true }, xAxis: valAx({}), yAxis: catAx(sg.map(s => s.s), { inverse: true }), series: [{ type: 'bar', data: sg.map(s => +s.gap.toFixed(1)), itemStyle: { color: '#008f8a' }, label: { show: true, position: 'right', formatter: '{c} pp' } }] })), 'PNG', 36, 54, W - 72, 210);
  doc.text('Willingness to pay (monthly)', 36, 290);
  doc.addImage(offChart(() => ({ grid: { left: 10, right: 10, top: 24, bottom: 10, containLabel: true }, xAxis: catAx(L.WTP), yAxis: valAx({}), series: [{ type: 'bar', data: w.f.c, itemStyle: { color: '#2a78d6' }, label: { show: true, position: 'top', formatter: p => (100 * p.value / w.n).toFixed(1) + '%' } }] })), 'PNG', 36, 300, W - 72, 190);
  doc.autoTable({ startY: 510, head: [['Persona', 'n', 'Intent', 'Paid', 'Recommended solution']], body: S_.pers.slice(1).map(r => [r[0], r[2], r[5] + '%', r[6] + '%', clean(r[8])]), theme: 'grid', styles: { fontSize: 7.5, cellPadding: 3 }, headStyles: { fillColor: [0, 143, 138] }, columnStyles: { 4: { cellWidth: 240 } }, margin: { left: 36, right: 36 } });
  y = doc.lastAutoTable.finalY + 16; doc.setFontSize(8); doc.setFont('helvetica', 'normal'); doc.setTextColor(90);
  doc.text(doc.splitTextToSize('Limitations: synthetic data; employer demand is respondent-perceived; stated willingness to pay overstates purchasing; respondent concentration is not market size; associations are not causal; projections are hypothetical.', W - 72), 36, Math.min(y, 800));
  saveFile(`jobsaathi-executive-report-${ix.length}.pdf`, doc.output('arraybuffer'));
}
function exportHTML() {
  const ix = Array.from(IX()), S_ = summaries(ix); const t = (rows) => `<table>${rows.map((r, k) => `<tr>${r.map(v => k ? `<td>${esc(v)}</td>` : `<th>${esc(v)}</th>`).join('')}</tr>`).join('')}</table>`;
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>JobSaathi Executive Report</title><style>body{font:14px/1.5 system-ui,sans-serif;max-width:960px;margin:32px auto;padding:0 16px;color:#101b2b}h1{font-size:24px}h2{font-size:17px;margin-top:28px;border-bottom:1px solid #d9dfe7;padding-bottom:4px}table{border-collapse:collapse;width:100%;font-size:12.5px}td,th{border:1px solid #d9dfe7;padding:5px 7px;text-align:left;vertical-align:top}th{background:#eef2f5}.warn{background:#fff3d6;color:#7a4d00;padding:8px 12px;font-weight:600;font-size:12px}</style></head><body>
  <div class="warn">SYNTHETIC DEMONSTRATION DATA – 5,000 RESPONDENTS. THESE ARE NOT ACTUAL JOBSAATHI CUSTOMERS OR REAL SURVEY PARTICIPANTS.</div><h1>JobSaathi · Executive Intelligence Report</h1><p>View: ${filterSentence()} · ${ix.length} respondents · generated ${new Date().toISOString().slice(0, 10)}</p>
  <h2>Key metrics</h2>${t(S_.kpi)}<h2>Ranked recommendations</h2>${t(S_.recs.map(r => r.slice(0, 10)))}<h2>Skill gaps</h2>${t(S_.skills)}<h2>Feature priority</h2>${t(S_.feats)}<h2>Willingness to pay</h2>${t(S_.wtp)}<h2>Personas</h2>${t(S_.pers)}<h2>NPS</h2>${t(S_.nps)}
  <h2>Limitations</h2><p>Synthetic data. Employer demand is respondent-perceived. Stated willingness to pay overstates purchasing. Respondent concentration is not market size. Associations are not causal. Projections are hypothetical.</p></body></html>`;
  saveFile(`jobsaathi-executive-report-${ix.length}.html`, html);
}

/* ============================================================ boot */
function boot() { applyTheme(); shell(); addEventListener('hashchange', () => render()); render(); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
