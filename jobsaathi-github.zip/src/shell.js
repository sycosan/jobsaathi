/* ============================================================ shell: layout, nav, filters, palette, exports */
const GROUPS = [['decide', 'Decide'], ['understand', 'Understand'], ['prove', 'Prove'], ['data', 'Data']];
function page(key, code, nav, title, q, group, render, star) { PAGES.push({ key, code, nav, title, q, group, render, star }); }

function shell() {
  $('#root').innerHTML = `
  <div class="app">
    <nav class="rail" id="rail" aria-label="Modules">
      <div class="brand"><div class="mark"><div class="logo">JS</div><div><b>JobSaathi</b><small>Workforce Intelligence</small></div></div></div>
      <div class="nav">${GROUPS.map(([g, gl]) => `<h6>${gl}</h6>` + PAGES.filter(p => p.group === g).map(p => `<a href="#${p.key}" data-k="${p.key}" class="${p.star ? 'star' : ''}"><code>${p.code}</code><span>${p.nav}</span></a>`).join('')).join('')}</div>
      <div class="rail-foot">seed ${P.meta.seed}<br>n = ${fmtN(N)} · 25 questions<br>press <span class="kbd">/</span> to jump</div>
    </nav>
    <div class="main" id="main">
      <div class="ribbon" role="note"><div>SYNTHETIC DEMONSTRATION DATA – 5,000 RESPONDENTS. THESE ARE NOT ACTUAL JOBSAATHI CUSTOMERS OR REAL SURVEY PARTICIPANTS.</div></div>
      <header class="topbar">
        <button class="burger" id="burger" aria-label="Open menu">☰</button>
        <div class="ptitle"><div class="code" id="pcode"></div><h1 id="ptitle"></h1><p id="pq"></p></div>
        <div class="tools">
          <span class="nbadge" id="nbadge"></span>
          <button class="btn" id="cmdBtn" title="Jump to a module">Go <span class="kbd">/</span></button>
          <button class="btn" id="expBtn">Export ▾</button>
          <div class="seg" role="group" aria-label="Theme">${['system', 'light', 'dark'].map(t => `<button data-theme-set="${t}" aria-pressed="${CFG.theme === t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div>
        </div>
      </header>
      <div class="fstrip" id="fstrip"></div>
      <main class="content" id="content"></main>
    </div>
  </div>`;
  $('#burger').onclick = () => $('#rail').classList.toggle('open');
  $$('#rail a').forEach(a => a.addEventListener('click', () => $('#rail').classList.remove('open')));
  $$('[data-theme-set]').forEach(b => b.onclick = () => { CFG.theme = b.dataset.themeSet; saveCfg(); $$('[data-theme-set]').forEach(x => x.setAttribute('aria-pressed', x === b)); applyTheme(); render(true); });
  $('#cmdBtn').onclick = openCmd; $('#expBtn').onclick = e => exportMenu(e.currentTarget);
  document.addEventListener('keydown', e => { if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { e.preventDefault(); openCmd(); } if (e.key === 'Escape') { closePop(); closeDrawer(); $('.cmdk')?.remove(); } });
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { readColors(); render(true); });
  new MutationObserver(() => { const before = TC.panel; readColors(); if (TC.panel !== before) render(true); }).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
}

function filterStrip() {
  const fs = $('#fstrip'); const { idx, base } = getIdx();
  const nAct = FDEF.filter(d => F[d.k].size).length;
  fs.innerHTML = `<div class="frow"><button class="fbtn ftoggle ${nAct ? 'act' : ''}" id="fTog">Filters${nAct ? `<span class="ct">${nAct}</span>` : ''} ▾</button><span class="flabel">Filters</span>${FDEF.map(d => `<button class="fbtn ${F[d.k].size ? 'act' : ''}" data-f="${d.k}">${esc(d.lab)}${F[d.k].size ? `<span class="ct">${F[d.k].size}</span>` : ''} ▾</button>`).join('')}
    <button class="fbtn" id="presetBtn">Saved views ▾</button>${FDEF.some(d => F[d.k].size) ? '<button class="fbtn" id="fReset">Clear all</button>' : ''}</div>
    <div class="fsentence"><span>Showing</span><span>${filterSentence()}</span><span class="muted mono">n = ${fmtN(idx.length)} of ${fmtN(base.length)}${base.length < N ? ` (${fmtN(N - base.length)} excluded by data-quality rules)` : ''}</span></div>`;
  $('#fTog').onclick = () => fs.classList.toggle('open');
  $$('[data-f]', fs).forEach(b => b.onclick = () => filterPop(b, FDEF.find(d => d.k === b.dataset.f)));
  $('#presetBtn').onclick = e => openPop(e.currentTarget, `<div class="pophead"><span>Saved views</span></div>${PRESETS.map((p, i) => `<label><input type="radio" name="pr" data-p="${i}"> ${esc(p.name)}</label>`).join('')}`)
    .querySelectorAll('[data-p]').forEach(r => r.onchange = () => { const pr = PRESETS[+r.dataset.p]; FDEF.forEach(d => F[d.k].clear()); for (const k in pr.f) pr.f[k].forEach(v => F[k].add(v)); closePop(); refresh(); });
  if ($('#fReset')) $('#fReset').onclick = () => { FDEF.forEach(d => F[d.k].clear()); refresh(); };
  $('#nbadge').innerHTML = `n = <b>${fmtN(idx.length)}</b>`;
}
function filterPop(anchor, d) {
  const base = BASE(); const k = d.opts.length;
  const cnt = d.mask ? mfreq(D[d.k], base, k).c : freqBase(D[d.k], base, k, d.base || 0).c;
  const p = openPop(anchor, `<div class="pophead"><span>${esc(d.lab)}</span><span><button data-all>All</button> · <button data-none>Clear</button></span></div>
    ${d.opts.map((o, v) => `<label><input type="checkbox" value="${v}" ${F[d.k].has(v) ? 'checked' : ''}> ${esc(o)}<span class="c">${fmtN(cnt[v])}</span></label>`).join('')}
    ${d.mask ? '<p class="muted" style="margin:6px;font-size:11px">Matches respondents who selected any of the ticked options.</p>' : ''}`);
  $$('input', p).forEach(cb => cb.onchange = () => { cb.checked ? F[d.k].add(+cb.value) : F[d.k].delete(+cb.value); refresh(); });
  $('[data-all]', p).onclick = () => { d.opts.forEach((_, v) => F[d.k].add(v)); closePop(); refresh(); };
  $('[data-none]', p).onclick = () => { F[d.k].clear(); closePop(); refresh(); };
}

function openCmd() {
  $('.cmdk')?.remove(); const m = document.createElement('div'); m.className = 'cmdk';
  m.innerHTML = `<input id="cmdIn" placeholder="Type a module code or name — e.g. SKL, CEO, simulator" aria-label="Jump to module"><ul></ul>`;
  document.body.appendChild(m); const inp = $('input', m), ul = $('ul', m); let sel = 0, list = [];
  const draw = () => { const q = inp.value.trim().toLowerCase(); list = PAGES.filter(p => !q || p.code.toLowerCase().startsWith(q) || p.nav.toLowerCase().includes(q) || p.title.toLowerCase().includes(q));
    sel = Math.min(sel, Math.max(0, list.length - 1)); ul.innerHTML = list.map((p, i) => `<li class="${i === sel ? 'on' : ''}" data-k="${p.key}"><code>${p.code}</code><span>${p.title}</span></li>`).join(''); $$('li', ul).forEach(li => li.onclick = () => { m.remove(); go(li.dataset.k); }); };
  inp.oninput = () => { sel = 0; draw(); };
  inp.onkeydown = e => { if (e.key === 'ArrowDown') { sel = Math.min(list.length - 1, sel + 1); draw(); e.preventDefault(); } if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); } if (e.key === 'Enter' && list[sel]) { m.remove(); go(list[sel].key); } if (e.key === 'Escape') m.remove(); };
  draw(); inp.focus(); setTimeout(() => document.addEventListener('mousedown', function o(e) { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('mousedown', o); } }), 0);
}

function exportMenu(anchor) {
  const items = [['raw', 'Raw synthetic dataset · CSV', 'All 5,000 records as captured: label variants, invalid codes'], ['clean', 'Cleaned dataset · CSV', 'Standardised labels, invalid → blank, quality flags'],
    ['filtered', 'Filtered analytical dataset · CSV', 'Current view with derived variables, personas, clusters, model scores'], ['xlsx', 'Workbook (filtered + summaries) · Excel', 'Data, KPIs, skill gaps, features, WTP, segments, NPS, tests'],
    ['pdf', 'Executive report · PDF', 'KPIs, CEO answers, ranked recommendations, caveats'], ['html', 'Executive report · HTML', 'Same report as a standalone page']];
  const p = openPop(anchor, `<div class="pophead"><span>Export (${fmtN(IX().length)} in view)</span></div>${items.map(([k, t, s]) => `<label data-e="${k}" style="flex-direction:column;align-items:flex-start;gap:1px"><b style="font-weight:600">${t}</b><span class="muted" style="font-size:11px">${s}</span></label>`).join('')}<p class="muted" style="font-size:11px;margin:6px">Every file is labelled as synthetic demonstration data.</p>`);
  $$('[data-e]', p).forEach(el => el.onclick = () => { closePop(); doExport(el.dataset.e); });
}
function doExport(k) {
  const all = Array.from({ length: N }, (_, i) => i);
  if (k === 'raw') return saveFile('jobsaathi-raw-synthetic-5000.csv', csv(recordHead('raw'), all.map(i => record(i, 'raw'))));
  if (k === 'clean') return saveFile('jobsaathi-cleaned-synthetic-5000.csv', csv(recordHead('clean'), all.map(i => record(i, 'clean'))));
  if (k === 'filtered') return saveFile(`jobsaathi-filtered-${IX().length}.csv`, csv(recordHead('analytical'), [...IX()].map(i => record(i, 'analytical'))));
  if (k === 'xlsx') return exportXLSX();
  if (k === 'pdf') return exportPDF();
  if (k === 'html') return exportHTML();
}

function render(keep) {
  const key = location.hash.slice(1) || 'exec'; const pg = pageByKey(key);
  const main = $('#main'); const y = keep && CUR === pg.key ? window.scrollY : 0;
  closePop(); disposeCharts(); CUR = pg.key;
  $$('#rail a').forEach(a => a.classList.toggle('on', a.dataset.k === pg.key));
  $('#pcode').textContent = pg.code + ' <GO>'; $('#ptitle').textContent = pg.title; $('#pq').textContent = pg.q;
  document.title = 'JobSaathi Intelligence';
  filterStrip(); const c = $('#content'); c.innerHTML = '';
  try { pg.render(c); } catch (e) { console.error(e); c.innerHTML = `<div class="panel s12"><div class="pb"><div class="note warn">This module hit an error while calculating: ${esc(e.message)}. Clear the filters or reload the page.</div></div></div>`; }
  window.scrollTo(0, y);
}
