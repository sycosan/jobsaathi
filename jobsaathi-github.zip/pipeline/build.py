"""Assemble the single-file dashboard (index.html) from src/ + data/payload.json.
Run from the repository root:  python pipeline/build.py
Add --test to inline local copies of the chart/export libraries (node_modules) for offline testing."""
import sys, pathlib
R = pathlib.Path(__file__).resolve().parent.parent
TEST = "--test" in sys.argv
css = (R / "src/style.css").read_text()
js = "\n".join((R / f"src/{f}.js").read_text() for f in ["core", "shell", "analytics", "pages_decide", "pages_understand", "pages_prove", "pages_data"])
payload = (R / "data/payload.json").read_text().replace("</", "<\\/")
LIBS = [("echarts@5.5.0", "echarts/dist/echarts.min.js"), ("xlsx@0.18.5", "xlsx/dist/xlsx.full.min.js"),
        ("jspdf@2.5.1", "jspdf/dist/jspdf.umd.min.js"), ("jspdf-autotable@3.8.2", "jspdf-autotable/dist/jspdf.plugin.autotable.min.js")]
if TEST:
    libs = "".join(f"<script>{(R / 'node_modules' / p).read_text()}</script>\n" for _, p in LIBS)
else:
    libs = "".join(f'<script src="https://cdn.jsdelivr.net/npm/{v}/{p.split("/", 1)[1]}"></script>\n' for v, p in LIBS)
html = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>JobSaathi Intelligence</title>
<meta name="description" content="Business-intelligence dashboard for JobSaathi built on 5,000 synthetic survey respondents. Synthetic demonstration data.">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,400..800&family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap">
<style>{css}</style>
</head>
<body>
<div id="root"><div style="padding:48px 24px;font:500 14px system-ui,sans-serif;color:#47546a">Loading JobSaathi intelligence: 5,000 synthetic respondents…</div></div>
<script type="application/json" id="jsdata">{payload}</script>
{libs}<script>
{js}
</script>
</body>
</html>
"""
out = R / ("test.html" if TEST else "index.html")
out.write_text(html)
print("wrote", out.relative_to(R), out.stat().st_size // 1024, "KB")
