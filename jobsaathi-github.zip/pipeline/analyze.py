"""
JobSaathi analytical engine (offline, Python / scikit-learn).
Builds the analytical dataset and trains every framework from the course guide:
  K-NN, Decision Tree, Random Forest, Gradient Boosting (+ ROC/AUC scoring)
  K-Means (elbow, silhouette), Latent Class Analysis (EM)
Association rules, regression and hypothesis tests are re-computed live in the browser
on the filtered sample; Python versions here are used to cross-check the browser numbers.
"""
import json, pickle, base64, re
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import roc_auc_score, accuracy_score, log_loss, roc_curve, precision_score, recall_score, f1_score, silhouette_score
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.inspection import permutation_importance

S = pickle.load(open("data/gen_state.pkl", "rb"))
L = S["labels"]; df = S["df"].copy(); N = S["N"]; SEED = S["SEED"]
have, dem, feat = S["have"], S["dem"], S["feat"]; smiss = S["skills_missing"]; texts = S["texts"]
rng = np.random.default_rng(SEED + 1)

# ------------------------------------------------------------ derived variables
tier = np.array([L["TIER_OF_CITY"][int(c)] for c in df.q3_city])
n_sk = np.where(smiss, np.nan, have.sum(1)); n_dem = np.where(smiss, np.nan, dem.sum(1))
gap = np.where(smiss, np.nan, (dem & ~have).sum(1))
fam = (df.q16_ai_fam - 1) / 4; use = (3 - df.q17_ai_use) / 3; tru = (df.q18_ai_trust - 1) / 4
comp = np.vstack([fam, use, tru]).T; w = np.array([.35, .35, .30])
okc = ~np.isnan(comp)
ai_idx = np.where(okc.sum(1) >= 2, 100 * np.nansum(comp * w, 1) / (okc * w).sum(1), np.nan)
intent_score = 4 - df.q20_intent.values  # 4 = Definitely
wtp_mid = np.array([np.nan if np.isnan(v) else L["WTP_MID"][int(v)] for v in df.q22_wtp])
paid = np.where(np.isnan(df.q22_wtp), np.nan, (df.q22_wtp >= 1).astype(float))
exp_yrs = np.array([np.nan if np.isnan(v) else L["EXP_YRS"][int(v)] for v in df.q5_exp])
learn_mo = np.array([np.nan if np.isnan(v) else L["LEARN_MO"][int(v)] for v in df.q15_learn])
apps_mid = np.array([np.nan if np.isnan(v) else L["APPS_MID"][int(v)] for v in df.q8_apps])
intv_mid = np.array([np.nan if np.isnan(v) else L["INTV_MID"][int(v)] for v in df.q9_interviews])
edu_ord = np.array([np.nan if np.isnan(v) else [0, 1, 2, 3, 4, 3, 1][int(v)] for v in df.q2_edu])
gapq_ord = np.array([[3, 2, 1, 0, 1.5][int(v)] for v in df.q14_gap])
nps = df.q24_nps.values
nps_cat = np.where(np.isnan(nps), -1, np.where(nps >= 9, 2, np.where(nps >= 7, 1, 0)))

# ------------------------------------------------------------ sentiment + themes (transparent lexicon model)
POS = ["great", "helpful", "help", "happy", "improving", "better", "use it daily", "works", "okay", "grow"]
NEG = ["not enough", "nahi", "no one", "weak", "outdated", "mismatch", "expensive", "unfair", "fake", "scam", "frustrating",
       "black hole", "hardest", "lost money", "fraud", "no response", "no calls", "rejects", "vague", "not affordable",
       "dont guarantee", "half the postings", "on your own", "how will", "limited", "too many", "banned"]
THEMES = {"Lack of jobs": ["jobs", "openings", "vacanc", "opportunit", "oppurtunit", "hire locally", "entry level roles", "remote roles"],
          "Poor career guidance": ["guidance", "counselling", "mentorship", "career path"],
          "Skill mismatch": ["skill", "syllabus", "practical", "theory", "mismatch", "matches actual"],
          "Expensive training": ["expensive", "afford", "lakhs"],
          "Lack of experience": ["experience", "experiance", "internship"],
          "Difficulty getting interviews": ["calls", "no response", "black hole", "rejection", "ats ", "interview", "hr"],
          "Need for AI-powered career guidance": ["ai tool", "ai based", "ai job", "if ai", "using ai", "roadmap"],
          "Hiring transparency": ["transparen", "salary range", "publish salary", "reference based"],
          "Fake jobs & fraud": ["fake", "scam", "fraud"]}
TH_KEYS = list(THEMES)
sent = np.full(N, -1); themes = np.zeros(N, int)
for i, t in enumerate(texts):
    s = (t or "").lower().strip()
    if s in ("", "na", "-", ".", "nil", "nothing", "no"):
        continue
    sc = sum(s.count(p) for p in POS) - sum(s.count(n) for n in NEG)
    sent[i] = 2 if sc > 0 else (0 if sc < 0 else 1)
    m = 0
    for k, key in enumerate(TH_KEYS):
        if any(kw in " " + s + " " for kw in THEMES[key]): m |= 1 << k
    themes[i] = m
# agreement of theme model with generator ground-truth primary theme
GT = {"jobs": 0, "guidance": 1, "skills": 2, "cost": 3, "experience": 4, "interviews": 5, "ai": 6, "transparency": 7, "fraud": 8}
gt = S["th1"]; agree = [];
for i in range(N):
    if gt[i] in GT and sent[i] >= 0: agree.append(bool(themes[i] >> GT[gt[i]] & 1))
theme_agreement = float(np.mean(agree))
print("theme agreement", round(theme_agreement, 3), "sentiment dist", np.bincount(sent[sent >= 0]))

# ------------------------------------------------------------ rule-based personas (overlapping, data-defined)
st = df.q4_status.values; ag = df.q1_age.values
persona_rules = [
    ("Fresh Graduate Job Seekers", (st == 1) | ((np.isin(st, [3, 4])) & (np.isin(df.q2_edu, [3, 4])) & (exp_yrs <= .5)),
     "Status = Fresher, or unemployed / actively looking UG–PG with < 1 year experience"),
    ("Unemployed Experienced Professionals", np.isin(st, [3, 4]) & (exp_yrs >= 2), "Unemployed or actively looking with 1–3+ years experience"),
    ("Career Switchers", st == 6, "Status = Looking for a career change"),
    ("AI-Ready Young Professionals", (ag <= 2) & (ai_idx >= 65), "Age 18–30 and AI Adoption Index ≥ 65"),
    ("Tier 2/Tier 3 Job Seekers", (tier >= 1) & np.isin(st, [1, 3, 4, 6]), "Lives outside Tier 1 metros and is seeking work or a switch"),
    ("Budget-Conscious Job Seekers", (df.q22_wtp == 0) & np.isin(st, [0, 1, 3, 4]), "Free-only and student / fresher / unemployed / looking"),
    ("High-Intent Upskilling Candidates", (df.q14_gap <= 1) & (df.q15_learn >= 2) & (feat[:, 6] | feat[:, 3]), "Has hit a skill gap, will invest 3+ months in learning, and wants a learning roadmap or skill-gap analysis"),
]
persona_mask = np.zeros(N, int)
for k, (_, m, _) in enumerate(persona_rules):
    persona_mask |= (np.nan_to_num(np.asarray(m, float)).astype(bool)).astype(int) << k

# ------------------------------------------------------------ helpers
def med_impute(X):
    X = X.copy()
    for j in range(X.shape[1]):
        c = X[:, j]; c[np.isnan(c)] = np.nanmedian(c)
    return X

def zs(X):
    mu, sd = X.mean(0), X.std(0); sd[sd == 0] = 1
    return (X - mu) / sd, mu, sd

def i8b64(Z, scale):
    q = np.clip(np.round(Z * scale), -127, 127).astype(np.int8)
    return base64.b64encode(q.tobytes()).decode()

# ------------------------------------------------------------ classification: paid-conversion propensity
FEATS = ["Age group", "Education level", "Metro city", "Tier 2 (named) city", "Student", "Fresher", "Employed", "Unemployed",
         "Actively looking", "Self-employed", "Career change", "Experience (yrs)", "Job-search difficulty", "Applications (log)",
         "Interviews (log)", "Job confidence", "Industry readiness", "Skill gaps (count)", "Skills held (count)", "Skill-gap frequency",
         "Learning commitment (months)", "AI familiarity", "AI tool usage", "AI trust", "Platform intent", "Features wanted (count)",
         "Expected salary (log)"]
Xc = np.column_stack([ag, edu_ord, tier == 0, tier == 1] + [st == k for k in range(7)] +
                     [exp_yrs, df.q6_difficulty, np.log1p(apps_mid), np.log1p(intv_mid), df.q10_confidence, df.q13_readiness, gap, n_sk,
                      gapq_ord, learn_mo, df.q16_ai_fam, 3 - df.q17_ai_use, df.q18_ai_trust, intent_score, feat.sum(1),
                      np.log(df.exp_salary_k)]).astype(float)
Xi = med_impute(Xc); Zc, mu_c, sd_c = zs(Xi)
y_all = paid; lab_ok = ~np.isnan(y_all)
idx_all = np.arange(N)[lab_ok]; y = y_all[lab_ok].astype(int)
tr, te = train_test_split(idx_all, test_size=.3, random_state=SEED % 2**31, stratify=y)
ytr, yte = y_all[tr].astype(int), y_all[te].astype(int)
print("train", len(tr), "test", len(te), "base rate", y.mean().round(3))

def metrics(p, yt, thr=.5):
    pr = (p >= thr).astype(int)
    return dict(acc=accuracy_score(yt, pr), prec=precision_score(yt, pr, zero_division=0), rec=recall_score(yt, pr),
                f1=f1_score(yt, pr), auc=roc_auc_score(yt, p))

models = {}
# K-NN
knn_curve = []
for k in [1, 3, 5, 7, 9, 15, 21, 31, 51, 75, 101, 151]:
    m = KNeighborsClassifier(k).fit(Zc[tr], ytr)
    ptr, pte = m.predict_proba(Zc[tr])[:, 1], m.predict_proba(Zc[te])[:, 1]
    knn_curve.append(dict(k=k, train_acc=accuracy_score(ytr, ptr >= .5), test_acc=accuracy_score(yte, pte >= .5),
                          train_auc=roc_auc_score(ytr, ptr), test_auc=roc_auc_score(yte, pte)))
best_k = max(knn_curve, key=lambda r: r["test_auc"])["k"]
knn = KNeighborsClassifier(best_k).fit(Zc[tr], ytr)
models["knn"] = dict(name=f"K-NN (K={best_k})", p_test=knn.predict_proba(Zc[te])[:, 1], p_train=knn.predict_proba(Zc[tr])[:, 1])
# Decision tree
dt_curve = []
for d in list(range(1, 16)):
    m = DecisionTreeClassifier(max_depth=d, min_samples_leaf=1, random_state=SEED % 2**31).fit(Xi[tr], ytr)
    ptr, pte = m.predict_proba(Xi[tr])[:, 1], m.predict_proba(Xi[te])[:, 1]
    dt_curve.append(dict(depth=d, train_acc=accuracy_score(ytr, ptr >= .5), test_acc=accuracy_score(yte, pte >= .5),
                         train_auc=roc_auc_score(ytr, ptr), test_auc=roc_auc_score(yte, pte)))
best_d = max(dt_curve, key=lambda r: r["test_auc"])["depth"]
dt = DecisionTreeClassifier(max_depth=best_d, min_samples_leaf=20, random_state=SEED % 2**31).fit(Xi[tr], ytr)
models["dt"] = dict(name=f"Decision Tree (depth {best_d})", p_test=dt.predict_proba(Xi[te])[:, 1], p_train=dt.predict_proba(Xi[tr])[:, 1])
# display tree, depth 3, readable rules
dt3 = DecisionTreeClassifier(max_depth=3, min_samples_leaf=40, random_state=SEED % 2**31).fit(Xi[tr], ytr)
t = dt3.tree_
def node(i):
    v = t.value[i][0]; tot = t.n_node_samples[i]
    d = dict(id=int(i), n=int(tot), p=float(v[1] / v.sum()))
    if t.children_left[i] != -1:
        d.update(f=int(t.feature[i]), thr=float(t.threshold[i]), l=node(t.children_left[i]), r=node(t.children_right[i]))
    return d
tree_json = node(0)
dt3_test = metrics(dt3.predict_proba(Xi[te])[:, 1], yte)
# Random forest
rf = RandomForestClassifier(n_estimators=200, max_features="sqrt", min_samples_leaf=5, random_state=SEED % 2**31, n_jobs=-1).fit(Xi[tr], ytr)
models["rf"] = dict(name="Random Forest (200 trees)", p_test=rf.predict_proba(Xi[te])[:, 1], p_train=rf.predict_proba(Xi[tr])[:, 1])
tree_probs = np.array([e.predict_proba(Xi[te])[:, 1] for e in rf.estimators_])
votes = (tree_probs >= .5)  # 200 x n_test
rf_curve = []
for m_ in [1, 2, 3, 5, 8, 12, 20, 30, 50, 75, 100, 150, 200]:
    p = tree_probs[:m_].mean(0); rf_curve.append(dict(trees=m_, test_auc=roc_auc_score(yte, p), test_acc=accuracy_score(yte, p >= .5)))
perm = permutation_importance(rf, Xi[te], yte, n_repeats=5, random_state=SEED % 2**31, scoring="roc_auc", n_jobs=-1)
rf_imp = sorted([dict(f=FEATS[j], mdi=float(rf.feature_importances_[j]), perm=float(perm.importances_mean[j]), perm_sd=float(perm.importances_std[j]))
                 for j in range(len(FEATS))], key=lambda r: -r["perm"])
# Gradient boosting
gb = GradientBoostingClassifier(n_estimators=400, learning_rate=.12, max_depth=4, subsample=.8, random_state=SEED % 2**31).fit(Xi[tr], ytr)
gb_curve = []
for r_, (ptr, pte) in enumerate(zip(gb.staged_predict_proba(Xi[tr]), gb.staged_predict_proba(Xi[te])), 1):
    if r_ in (1, 2, 3, 5) or r_ % 10 == 0:
        gb_curve.append(dict(rounds=r_, train_err=1 - accuracy_score(ytr, ptr[:, 1] >= .5), test_err=1 - accuracy_score(yte, pte[:, 1] >= .5),
                             train_loss=log_loss(ytr, ptr[:, 1]), test_loss=log_loss(yte, pte[:, 1]), test_auc=roc_auc_score(yte, pte[:, 1])))
best_r = min(gb_curve, key=lambda r: r["test_loss"])["rounds"]
gbb = GradientBoostingClassifier(n_estimators=best_r, learning_rate=.12, max_depth=4, subsample=.8, random_state=SEED % 2**31).fit(Xi[tr], ytr)
models["gb"] = dict(name=f"Gradient Boosting ({best_r} rounds)", p_test=gbb.predict_proba(Xi[te])[:, 1], p_train=gbb.predict_proba(Xi[tr])[:, 1])
gb_imp = sorted([dict(f=FEATS[j], v=float(gbb.feature_importances_[j])) for j in range(len(FEATS))], key=lambda r: -r["v"])
# out-of-fold propensity for every labelled respondent + model scores for unlabelled
prop = np.full(N, np.nan)
skf = StratifiedKFold(5, shuffle=True, random_state=SEED % 2**31)
for a, b in skf.split(idx_all, y):
    m = GradientBoostingClassifier(n_estimators=best_r, learning_rate=.12, max_depth=4, subsample=.8, random_state=SEED % 2**31).fit(Xi[idx_all[a]], y[a])
    prop[idx_all[b]] = m.predict_proba(Xi[idx_all[b]])[:, 1]
prop[~lab_ok] = gbb.predict_proba(Xi[~lab_ok])[:, 1]

cmp = []
for k, m in models.items():
    te_m = metrics(m["p_test"], yte); tr_auc = roc_auc_score(ytr, m["p_train"]); tr_acc = accuracy_score(ytr, m["p_train"] >= .5)
    fpr, tpr, _ = roc_curve(yte, m["p_test"])
    cmp.append(dict(key=k, name=m["name"], train_acc=tr_acc, train_auc=tr_auc, **te_m))
    print(k, {a: round(b, 3) for a, b in te_m.items()}, "train auc", round(tr_auc, 3))

# ------------------------------------------------------------ K-Means (behavioural segmentation)
KM_F = ["Job-search difficulty", "Job confidence", "Industry readiness", "Skill gaps (count)", "AI Adoption Index",
        "Platform intent", "Willingness to pay (log ₹)", "Experience (yrs)", "Learning commitment (months)"]
Xk = med_impute(np.column_stack([df.q6_difficulty, df.q10_confidence, df.q13_readiness, gap, ai_idx, intent_score,
                                 np.log1p(wtp_mid), exp_yrs, learn_mo]).astype(float))
Zk, mu_k, sd_k = zs(Xk)
elbow = []
samp = rng.choice(N, 2000, replace=False)
for k in range(2, 11):
    km = KMeans(k, n_init=10, random_state=SEED % 2**31).fit(Zk)
    elbow.append(dict(k=k, wcss=float(km.inertia_), sil=float(silhouette_score(Zk[samp], km.labels_[samp]))))
print("elbow", [(e["k"], round(e["wcss"]), round(e["sil"], 3)) for e in elbow])
K_SEL = 5
km = KMeans(K_SEL, n_init=20, random_state=SEED % 2**31).fit(Zk)
# order clusters by size
order = np.argsort(-np.bincount(km.labels_)); remap = np.empty(K_SEL, int); remap[order] = np.arange(K_SEL)
km_lab = remap[km.labels_]; km_cent = km.cluster_centers_[order]
pca = PCA(2, random_state=0).fit(Zk); P = pca.transform(Zk)
print("cluster sizes", np.bincount(km_lab), "pca var", pca.explained_variance_ratio_.round(3))

# ------------------------------------------------------------ Latent Class Analysis (EM with missing-at-random items)
def collapse():
    sg = np.select([np.isin(st, [0, 1]), np.isin(st, [3, 4]), np.isin(st, [2, 5]), st == 6], [0, 1, 2, 3])
    g = np.select([df.q14_gap == 0, df.q14_gap == 1], [0, 1], 2)
    u = np.select([df.q17_ai_use == 0, df.q17_ai_use == 1], [0, 1], 2)
    it = np.select([df.q20_intent == 0, df.q20_intent == 1], [0, 1], 2)
    wp = np.where(np.isnan(df.q22_wtp), -1, np.select([df.q22_wtp == 0, df.q22_wtp <= 2], [0, 1], 2))
    lr = np.where(np.isnan(df.q15_learn), -1, np.select([df.q15_learn <= 1, df.q15_learn == 2], [0, 1], 2))
    df6 = np.where(np.isnan(df.q6_difficulty), -1, np.select([df.q6_difficulty <= 2, df.q6_difficulty == 3], [0, 1], 2))
    return np.column_stack([sg, g, u, it, wp, lr, df6]).astype(int)
LCA_ITEMS = [("Life stage", ["Student / fresher", "Job seeker", "Employed / self-employed", "Career switcher"]),
             ("Skill-gap experience", ["Frequent", "Occasional", "Rare / never / unsure"]),
             ("AI tool usage", ["Frequent", "Occasional", "Tried / never"]),
             ("Would use JobSaathi", ["Definitely", "Probably", "Unsure / no"]),
             ("Willingness to pay", ["Free only", "₹99–₹499", "₹500+"]),
             ("Learning commitment", ["< 3 months", "3–6 months", "6+ months"]),
             ("Job-search difficulty", ["Easy (1–2)", "Moderate (3)", "Hard (4–5)"])]
Y = collapse(); J = Y.shape[1]; cats = [len(c) for _, c in LCA_ITEMS]

def lca(C, starts=12, iters=400):
    best = None
    for s in range(starts):
        r = np.random.default_rng(1000 + s)
        pi = np.full(C, 1 / C); th = [r.dirichlet(np.ones(cats[j]), C) for j in range(J)]
        ll_old = -np.inf
        for it in range(iters):
            logp = np.tile(np.log(pi), (N, 1))
            for j in range(J):
                ok = Y[:, j] >= 0
                logp[ok] += np.log(th[j][:, Y[ok, j]].T + 1e-12)
            mx = logp.max(1, keepdims=True); post = np.exp(logp - mx); sm = post.sum(1, keepdims=True); post /= sm
            ll = float((np.log(sm) + mx).sum())
            pi = post.mean(0)
            for j in range(J):
                ok = Y[:, j] >= 0
                th[j] = np.array([[post[ok & (Y[:, j] == v), c].sum() for v in range(cats[j])] for c in range(C)]) + 1e-3
                th[j] /= th[j].sum(1, keepdims=True)
            if ll - ll_old < 1e-6: break
            ll_old = ll
        if best is None or ll > best[0]: best = (ll, pi, th, post)
    ll, pi, th, post = best
    npar = (C - 1) + C * sum(c - 1 for c in cats)
    return dict(C=C, ll=ll, bic=-2 * ll + npar * np.log(N), aic=-2 * ll + 2 * npar, pi=pi, th=th, post=post,
                entropy=float(1 - (-(post * np.log(post + 1e-12)).sum()) / (N * np.log(C))))
lca_fits = [lca(C) for C in range(2, 7)]
for f in lca_fits: print("LCA", f["C"], round(f["bic"]), "entropy", round(f["entropy"], 3))
C_SEL = 4
lf = [f for f in lca_fits if f["C"] == C_SEL][0]
o = np.argsort(-lf["pi"]); lf["pi"] = lf["pi"][o]; lf["th"] = [t[o] for t in lf["th"]]; lf["post"] = lf["post"][:, o]
lca_cls = lf["post"].argmax(1)

# ------------------------------------------------------------ analytical dataset
an = pd.read_csv("data/cleaned.csv")
an["city_tier_code"] = tier; an["skills_possessed_count"] = n_sk; an["skills_demanded_count"] = n_dem; an["skill_gap_count"] = gap
an["ai_adoption_index"] = np.round(ai_idx, 1); an["platform_intent_top2"] = (df.q20_intent <= 1).astype(int)
an["wtp_midpoint_inr"] = wtp_mid; an["paid_intent"] = paid
an["nps_category"] = [["Detractor", "Passive", "Promoter"][c] if c >= 0 else "" for c in nps_cat]
an["sentiment_model"] = [["Negative", "Neutral", "Positive"][s] if s >= 0 else "" for s in sent]
an["themes_model"] = ["; ".join(TH_KEYS[k] for k in range(len(TH_KEYS)) if m >> k & 1) for m in themes]
for k, (nm, _, _) in enumerate(persona_rules): an["persona_" + re.sub(r"[^a-z0-9]+", "_", nm.lower()).strip("_")] = (persona_mask >> k & 1)
an["kmeans_cluster"] = km_lab + 1
for c in range(C_SEL): an[f"lca_p_class{c+1}"] = np.round(lf["post"][:, c], 3)
an["lca_class"] = lca_cls + 1
an["paid_propensity_gbt"] = np.round(prop, 3)
an["model_split"] = np.where(np.isin(np.arange(N), tr), "train", np.where(np.isin(np.arange(N), te), "test", "unlabelled"))
an.to_csv("data/analytical.csv", index=False)

# ------------------------------------------------------------ payload for the browser
def enc(arr):  # single-char codes; '.' = missing; 0-9 then a,b,...
    out = []
    for v in arr:
        if v is None or (isinstance(v, float) and np.isnan(v)) or v == -1: out.append(".")
        else: out.append("0123456789abcdefghijklmnopqrstuvwxyz"[int(v)])
    return "".join(out)

texts_u = list(dict.fromkeys(texts.tolist())); tix = {t: i for i, t in enumerate(texts_u)}
raw_city_u = list(dict.fromkeys(S["raw_city"])); rcix = {t: i for i, t in enumerate(raw_city_u)}
oc_u = list(dict.fromkeys([c for c in S["city_other"] if c])); ocix = {t: i for i, t in enumerate(oc_u)}
fl = S["flags"]
flagbits = (fl["flag_inconsistent_age_exp"].astype(int) | fl["flag_inconsistent_apps_interviews"] << 1 | fl["flag_straightliner"] << 2
            | fl["flag_speeder"] << 3 | fl["flag_possible_duplicate"] << 4 | fl["flag_invalid_corrected"] << 5)
def mask(M, miss=None):
    v = (M * (1 << np.arange(M.shape[1]))).sum(1)
    if miss is not None: v = np.where(miss, -1, v)
    return v.astype(int).tolist()

ts = pd.to_datetime(pd.Series(an.submitted_at))
P8 = np.clip(np.round(P / np.abs(P).max(0) * 120), -127, 127).astype(int)
payload = dict(
    meta=dict(seed=int(SEED), n=N, generated="2026-11-09", engine="Python 3.13 · NumPy · pandas · scikit-learn 1.9", theme_agreement=theme_agreement),
    labels=L, tierOfCity=L["TIER_OF_CITY"],
    cols=dict(q1=enc(df.q1_age), q2=enc(df.q2_edu), q3=enc(df.q3_city), q4=enc(df.q4_status), q5=enc(df.q5_exp), q6=enc(df.q6_difficulty),
              q7=enc(df.q7_challenge), q8=enc(df.q8_apps), q9=enc(df.q9_interviews), q10=enc(df.q10_confidence), q13=enc(df.q13_readiness),
              q14=enc(df.q14_gap), q15=enc(df.q15_learn), q16=enc(df.q16_ai_fam), q17=enc(df.q17_ai_use), q18=enc(df.q18_ai_trust),
              q20=enc(df.q20_intent), q21=enc(df.q21_feature), q22=enc(df.q22_wtp), q23=enc(df.q23_trust), q24=enc(df.q24_nps),
              sent=enc(sent), km=enc(km_lab), lca=enc(lca_cls), ch=enc([L["CHANNEL"].index(c) for c in df.channel])),
    q11=mask(have, smiss), q12=mask(dem, smiss), q19=mask(feat), themes=themes.tolist(), persona=persona_mask.tolist(),
    flags=flagbits.tolist(), dur=S["df"].duration_sec.tolist(), day=((ts - pd.Timestamp("2026-09-01")).dt.total_seconds() // 60).astype(int).tolist(),
    sal=[None if np.isnan(v) else float(v) for v in df.exp_salary_k], prop=[int(round(v * 1000)) for v in prop],
    text=[tix[t] for t in texts.tolist()], texts=texts_u,
    rawCity=[rcix[c] for c in S["raw_city"]], rawCityU=raw_city_u, otherCity=[ocix[c] if c else -1 for c in S["city_other"]], otherCityU=oc_u,
    rawOver=[[r, c, v] for r, c, v in S["raw_over"]],
    lcaPost=base64.b64encode(np.round(lf["post"] * 250).astype(np.uint8).tobytes()).decode(),
    pca=[P8[:, 0].tolist(), P8[:, 1].tolist()], pcaVar=pca.explained_variance_ratio_.tolist(),
    kmZ=i8b64(Zk, 25), kmF=KM_F, kmMu=mu_k.tolist(), kmSd=sd_k.tolist(), kmElbow=elbow, kmK=K_SEL, kmCent=km_cent.tolist(),
    clfZ=i8b64(Zc, 20), clfF=FEATS, clfMu=mu_c.tolist(), clfSd=sd_c.tolist(),
    split=[0 if i in set(tr) else (1 if i in set(te) else 2) for i in range(N)],
    test=te.tolist(), ytest=yte.tolist(),
    scores={k: [int(round(v * 1000)) for v in m["p_test"]] for k, m in models.items()},
    cmp=cmp, knnCurve=knn_curve, bestK=best_k, dtCurve=dt_curve, bestDepth=best_d, tree=tree_json, tree3Test=dt3_test,
    rfCurve=rf_curve, rfImp=rf_imp, rfVotes=base64.b64encode(np.packbits(votes.astype(np.uint8), axis=1).tobytes()).decode(), rfShape=list(votes.shape),
    gbCurve=gb_curve, gbBest=best_r, gbImp=gb_imp,
    lca=dict(C=C_SEL, items=LCA_ITEMS, pi=lf["pi"].tolist(), th=[t.tolist() for t in lf["th"]], fits=[dict(C=f["C"], ll=f["ll"], bic=f["bic"], aic=f["aic"], entropy=f["entropy"]) for f in lca_fits]),
    personas=[dict(name=n, rule=r) for n, _, r in persona_rules], themeKeys=TH_KEYS, themeKw=THEMES, posLex=POS, negLex=NEG,
)
json.dump(payload, open("data/payload.json", "w"), ensure_ascii=False, separators=(",", ":"))
import os; print("payload KB", os.path.getsize("data/payload.json") // 1024)

# cross-check numbers the browser will recompute
chk = dict(
    nps=float(((nps[~np.isnan(nps)] >= 9).mean() - (nps[~np.isnan(nps)] <= 6).mean()) * 100),
    mean_q6=float(np.nanmean(df.q6_difficulty)), mean_q13=float(np.nanmean(df.q13_readiness)), mean_ai=float(np.nanmean(ai_idx)),
    paid_share=float(np.nanmean(paid)), intent_top2=float((df.q20_intent <= 1).mean()),
    gap_pp={L["SKILLS"][j]: float((dem[~smiss, j].mean() - have[~smiss, j].mean()) * 100) for j in range(12)},
)
json.dump(chk, open("data/check.json", "w"), indent=1)
pickle.dump(dict(Xi=Xi, tr=tr, te=te, ytr=ytr, yte=yte, Xk=Xk, Zk=Zk, ai_idx=ai_idx, gap=gap, n_sk=n_sk, intent=intent_score,
                 wtp_mid=wtp_mid, paid=paid, exp_yrs=exp_yrs, learn_mo=learn_mo, tier=tier), open("data/an_state.pkl", "wb"))
