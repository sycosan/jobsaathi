"""
JobSaathi synthetic survey generator.
Fixed seed -> the same 5,000 respondents every run. Writes:
  data/raw.csv          raw responses as captured (label variants, invalid codes, blanks)
  data/cleaned.csv      standardised labels, invalid values -> NA, quality flags kept
  data/analytical.csv   cleaned + derived variables used by the dashboard
  data/gen_state.pkl    arrays for the model step
SYNTHETIC DEMONSTRATION DATA. Not real JobSaathi customers or survey participants.
"""
import json, pickle, re
import numpy as np, pandas as pd

SEED = 20271105
rng = np.random.default_rng(SEED)
N = 5000

AGE = ["18–21", "22–25", "26–30", "31–35", "36–45", "Above 45"]
EDU = ["Class 10", "Class 12", "Diploma", "Undergraduate", "Postgraduate", "Professional certification", "Other"]
CITY = ["Delhi NCR", "Mumbai", "Bengaluru", "Hyderabad", "Pune", "Chennai", "Kolkata", "Ahmedabad",
        "Jaipur", "Lucknow", "Chandigarh", "Other Tier 2/Tier 3 city"]
TIER_OF_CITY = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2]
TIER = ["Metro (Tier 1)", "Tier 2 (named)", "Other Tier 2/3"]
STATUS = ["Student", "Fresher", "Employed", "Unemployed", "Actively looking", "Self-employed", "Career change"]
EXP = ["No experience", "Less than 1 year", "1–3 years", "3–5 years", "5–10 years", "More than 10 years"]
EXP_YRS = [0, 0.5, 2, 4, 7.5, 13]
CHAL = ["Lack of relevant skills", "Lack of work experience", "Limited job opportunities", "Lack of industry knowledge",
        "Poor interview performance", "Lack of professional network", "Salary expectations",
        "Not receiving interview calls", "Other"]
APPS = ["0", "1–5", "6–10", "11–20", "21–50", "More than 50"]
APPS_MID = [0, 3, 8, 15.5, 35, 65]
INTV = ["0", "1–2", "3–5", "6–10", "More than 10"]
INTV_MID = [0, 1.5, 4, 8, 13]
SKILLS = ["Communication", "Excel & data analysis", "Digital marketing", "Financial analysis", "Programming",
          "Artificial Intelligence", "Supply chain management", "Sales", "Project management",
          "Business analytics", "Leadership", "Other"]
GAPQ = ["Yes, frequently", "Yes, occasionally", "Rarely", "Never", "Not sure"]
LEARN = ["Less than 1 month", "1–3 months", "3–6 months", "6–12 months", "More than 1 year"]
LEARN_MO = [0.5, 2, 4.5, 9, 15]
AIUSE = ["Frequently", "Occasionally", "Tried once or twice", "Never"]
FEAT19 = ["AI career guidance", "AI resume builder", "AI interview preparation", "Personalised skill-gap analysis",
          "AI job matching", "Salary estimation", "Personalised learning roadmap", "Candidate employability score",
          "Automated job application assistance"]
INTENT = ["Definitely", "Probably", "Not sure", "Probably not", "Definitely not"]
FEAT21 = ["AI career guidance", "Neural Profile & skill assessment", "Job matching", "Salary estimation",
          "Learning & upskilling recommendations", "Interview preparation", "Job application assistance"]
WTP = ["Free only", "₹99–₹199", "₹200–₹499", "₹500–₹999", "₹1,000–₹1,999", "Above ₹2,000"]
WTP_MID = [0, 149, 349, 749, 1499, 2499]
TRUST = ["Accurate job recommendations", "Verified employer partnerships", "Transparent skill assessments",
         "Data privacy", "Successful placement records", "User reviews", "Human career counselling", "Other"]
OTHER_CITIES = [("Indore", 2), ("Nagpur", 2), ("Patna", 2), ("Bhopal", 2), ("Surat", 2), ("Kochi", 2), ("Coimbatore", 2),
                ("Visakhapatnam", 2), ("Ranchi", 2), ("Dehradun", 2), ("Guwahati", 2), ("Nashik", 2), ("Raipur", 2),
                ("Mysuru", 2), ("Varanasi", 2), ("Bhubaneswar", 2), ("Madurai", 2), ("Ludhiana", 2), ("Agra", 2),
                ("Jodhpur", 2), ("Hubballi", 3), ("Bareilly", 3), ("Gorakhpur", 3), ("Jalandhar", 3), ("Siliguri", 3),
                ("Tirunelveli", 3), ("Bilaspur", 3), ("Sagar", 3), ("Ujjain", 3), ("Kota", 3), ("Muzaffarpur", 3),
                ("Hisar", 3), ("Belagavi", 3), ("Satna", 3), ("Shillong", 3), ("Jammu", 2)]


def pick(p, size=None):
    p = np.asarray(p, float); p = p / p.sum()
    return rng.choice(len(p), size=size, p=p)


def ordinal(latent, cuts):
    """latent -> 0..len(cuts) via thresholds."""
    return np.searchsorted(np.asarray(cuts), latent)


# ---------------------------------------------------------------- profile (Q1–Q5)
age = pick([0.17, 0.27, 0.22, 0.14, 0.13, 0.07], N)
status_by_age = np.array([
    [.56, .18, .05, .07, .09, .02, .03],
    [.13, .26, .20, .12, .18, .03, .08],
    [.03, .05, .37, .12, .20, .07, .16],
    [.01, .01, .41, .12, .18, .10, .17],
    [.005, .005, .45, .13, .15, .13, .13],
    [.005, .005, .42, .16, .14, .17, .10]])
status = np.array([pick(status_by_age[a]) for a in age])
edu_by_age = np.array([
    [.05, .44, .15, .31, .01, .03, .01],
    [.03, .12, .14, .50, .13, .07, .01],
    [.03, .09, .12, .45, .21, .09, .01],
    [.04, .10, .12, .41, .22, .10, .01],
    [.06, .13, .12, .38, .20, .10, .01],
    [.10, .17, .12, .33, .16, .10, .02]])
edu = np.array([pick(edu_by_age[a]) for a in age])
city = pick([.12, .10, .10, .07, .06, .06, .05, .04, .04, .04, .03, .29], N)
tier = np.array([TIER_OF_CITY[c] for c in city])

exp_by_age = np.array([
    [.62, .27, .10, .01, 0, 0],
    [.26, .27, .38, .08, .01, 0],
    [.07, .10, .30, .35, .17, .01],
    [.03, .04, .12, .23, .45, .13],
    [.02, .03, .07, .12, .30, .46],
    [.02, .02, .05, .08, .20, .63]])
exp = np.array([pick(exp_by_age[a]) for a in age])
exp[(status == 0) & (exp > 1)] = rng.choice([0, 1], ((status == 0) & (exp > 1)).sum())
exp[(status == 1) & (exp > 2)] = rng.choice([0, 1, 2], ((status == 1) & (exp > 2)).sum(), p=[.4, .4, .2])

# latent traits (standard-normal-ish)
metro = (tier == 0).astype(float)
edu_lvl = np.array([0, .3, .45, .7, 1.0, .8, .3])[edu]
skill = rng.normal(0, 1, N) + 1.1 * (edu_lvl - .6) + 0.12 * np.array(EXP_YRS)[exp] ** .6 + 0.25 * metro
digital = rng.normal(0, 1, N) - 0.32 * (age - 1.5) + 0.8 * (edu_lvl - .6) + 0.3 * metro
status_distress = np.array([.1, .55, -.65, .85, .7, -.2, .35])[status]

# ---------------------------------------------------------------- Section B (Q6–Q10)
lat6 = 0.9 * status_distress - 0.45 * skill + 0.35 * (tier == 2) + 0.15 * (tier == 1) + rng.normal(0, .75, N)
q6 = ordinal(lat6, [-1.35, -0.45, 0.35, 1.15]) + 1  # 1..5

chal_p = np.zeros((N, 9))
chal_p[:] = [.15, .14, .13, .08, .08, .08, .06, .12, .02]
chal_p[:, 0] += 0.12 * (skill < -.4)
chal_p[:, 1] += np.where(np.isin(status, [0, 1]), .22, 0) + np.where(exp <= 1, .06, 0)
chal_p[:, 2] += np.where(tier == 2, .14, np.where(tier == 1, .07, 0)) + np.where(age >= 4, .06, 0)
chal_p[:, 3] += np.where(status == 6, .12, 0)
chal_p[:, 4] += np.where(skill > .5, .04, 0)
chal_p[:, 5] += np.where(status == 6, .06, 0) + np.where(tier == 2, .04, 0)
chal_p[:, 6] += np.where(exp >= 3, .14, 0)
chal_p[:, 7] += np.where(np.isin(status, [3, 4]), .10, 0)
q7 = np.array([pick(p) for p in chal_p])

apps_p = {0: [.30, .40, .15, .09, .05, .01], 1: [.04, .22, .25, .23, .18, .08], 2: [.42, .33, .13, .07, .04, .01],
          3: [.05, .16, .22, .25, .21, .11], 4: [.02, .10, .19, .27, .26, .16], 5: [.55, .25, .10, .06, .03, .01],
          6: [.06, .24, .27, .22, .15, .06]}
q8 = np.array([pick(apps_p[s]) for s in status])
rate = 1 / (1 + np.exp(-(-2.0 + .55 * skill + .35 * metro - .15 * (tier == 2) + rng.normal(0, .5, N))))
interviews = rng.binomial(np.round(np.array(APPS_MID)[q8]).astype(int), np.clip(rate * 0.68, 0, 1))
q9 = np.digitize(interviews, [1, 3, 6, 11])  # 0..4

lat10 = .5 * skill - .42 * (q6 - 3) + .35 * np.minimum(q9, 3) + np.where(status == 2, .3, 0) + rng.normal(0, .8, N)
q10 = ordinal(lat10, [-1.3, -.35, .6, 1.65]) + 1

# ---------------------------------------------------------------- Section C (Q11–Q15)
base_have = np.array([.55, .40, .17, .13, .21, .08, .08, .23, .14, .11, .19, .07])
base_dem = np.array([.63, .52, .33, .22, .47, .58, .17, .25, .32, .45, .28, .04])
have = np.zeros((N, 12), bool); dem = np.zeros((N, 12), bool)
for j in range(12):
    lg = np.log(base_have[j] / (1 - base_have[j])) + .55 * skill
    if j in (1, 3, 9): lg += .7 * (edu_lvl - .6)
    if j in (2, 4, 5): lg += .35 * digital
    if j in (8, 10): lg += .18 * np.array(EXP_YRS)[exp] ** .7 - .4
    if j == 7: lg += .4 * (status == 5)
    if j == 6: lg += .2 * (edu == 4)
    have[:, j] = rng.random(N) < 1 / (1 + np.exp(-lg))
    ld = np.log(base_dem[j] / (1 - base_dem[j])) + rng.normal(0, .25)
    if j in (4, 5, 9): ld += .3 * digital
    if j in (8, 10): ld += .15 * (exp >= 3)
    dem[:, j] = rng.random(N) < 1 / (1 + np.exp(-ld))
# everybody ticks at least one skill they have
none = ~have.any(1); have[none, 0] = True
none = ~dem.any(1); dem[none, 5] = True
gap_cnt = (dem & ~have).sum(1)
match_cnt = (dem & have).sum(1)

lat13 = .55 * skill + .22 * match_cnt - .18 * gap_cnt + .08 * np.array(EXP_YRS)[exp] ** .7 + rng.normal(0, .75, N)
q13 = ordinal(lat13, [-1.25, -.35, .55, 1.45]) + 1

lat14 = .35 * gap_cnt + .45 * (q6 - 3) - .25 * skill + rng.normal(0, .9, N)
q14 = np.where(rng.random(N) < .06, 4, np.select([lat14 > 1.6, lat14 > .45, lat14 > -.6], [0, 1, 2], 3))

lat15 = .35 * (q14 <= 1) + .25 * np.isin(status, [6, 3, 4]) - .18 * (age - 2) + rng.normal(0, .9, N)
q15 = ordinal(lat15, [-.95, -.05, .75, 1.55])

# ---------------------------------------------------------------- Section D (Q16–Q19)
lat16 = .9 * digital + rng.normal(0, .7, N)
q16 = ordinal(lat16, [-1.3, -.4, .45, 1.35]) + 1
lat17 = .9 * (q16 - 3) + .3 * (age <= 2) + rng.normal(0, .7, N)
q17 = 3 - ordinal(lat17, [-1.0, .1, 1.05])   # 0 Frequently .. 3 Never
priv_skeptic = rng.random(N) < .12
lat18 = .5 * (q16 - 3) + .25 * (3 - q17) / 3 - .9 * priv_skeptic + .15 * (q6 - 3) + rng.normal(0, .85, N)
q18 = ordinal(lat18, [-1.25, -.35, .5, 1.35]) + 1

f_base = np.array([.46, .42, .44, .38, .52, .31, .36, .24, .29])
feat = np.zeros((N, 9), bool)
for j in range(9):
    lg = np.log(f_base[j] / (1 - f_base[j])) + .15 * (q16 - 3)
    if j in (1, 2): lg += .55 * np.isin(status, [0, 1])
    if j == 4: lg += .45 * np.isin(status, [3, 4])
    if j in (0, 6, 3): lg += .55 * (status == 6) + .25 * (q14 <= 1)
    if j == 5: lg += .5 * (status == 2) + .25 * (exp >= 3)
    if j == 8: lg += .4 * (q8 >= 3)
    if j == 7: lg += .2 * (status == 1)
    feat[:, j] = rng.random(N) < 1 / (1 + np.exp(-lg))
none = ~feat.any(1); feat[none, 4] = True

# ---------------------------------------------------------------- Section E (Q20–Q24)
lat20 = (.38 * (q6 - 3) + .3 * (q14 <= 1) + .32 * (q18 - 3) + .2 * (q16 - 3) + .1 * feat.sum(1) - .35
         - .25 * (status == 5) + rng.normal(0, .85, N))
q20 = 4 - ordinal(lat20, [-1.65, -.95, -.05, .85])  # 0 Definitely .. 4 Definitely not

ability = np.array([-.9, -.6, .55, -.55, -.25, .35, .2])[status]
lat22 = (ability + .5 * (2 - np.minimum(q20, 4)) / 2 + .12 * (q18 - 3) + .25 * metro + .12 * np.array(EXP_YRS)[exp] ** .5
         + .15 * (3 - q17) / 3 - 1.0 + rng.normal(0, .8, N))
q22 = ordinal(lat22, [-.6, .42, .86, 1.28, 1.72])

f21_p = np.zeros((N, 7)) + [.18, .14, .2, .07, .15, .14, .08]
f21_p[:, 0] += .12 * (status == 6) + .05 * feat[:, 0]
f21_p[:, 1] += .1 * (q14 <= 1) + .05 * feat[:, 7]
f21_p[:, 2] += .1 * np.isin(status, [3, 4]) + .05 * feat[:, 4]
f21_p[:, 3] += .1 * (status == 2)
f21_p[:, 4] += .08 * (q15 >= 2) + .05 * feat[:, 6]
f21_p[:, 5] += .12 * np.isin(status, [0, 1]) + .05 * feat[:, 2]
f21_p[:, 6] += .08 * (q8 >= 4) + .05 * feat[:, 8]
q21 = np.array([pick(p) for p in f21_p])

t_p = np.zeros((N, 8)) + [.15, .2, .12, .11, .22, .07, .1, .03]
t_p[:, 3] += .25 * priv_skeptic
t_p[:, 6] += .08 * (age >= 4) + .06 * (q16 <= 2)
t_p[:, 1] += .05 * np.isin(status, [3, 4])
q23 = np.array([pick(p) for p in t_p])

lat24 = (6.95 + .9 * (2 - q20) + .38 * (q18 - 3) + .2 * (q16 - 3) - .15 * (q6 - 3) * (q20 > 2)
         + .15 * (q10 - 3) + rng.normal(0, 1.55, N))
q24 = np.clip(np.round(lat24), 0, 10).astype(int)

# derived salary expectation (₹ '000 per month)
sal = np.exp(np.log(14) + .16 * np.array(EXP_YRS)[exp] ** .85 + .35 * (edu_lvl - .6) + .22 * metro
             + .12 * skill + rng.normal(0, .28, N))
sal = np.round(sal, 1)

# ---------------------------------------------------------------- Q25 open text
TEMPL = {
    "jobs": ["There are simply not enough jobs for freshers in my city", "Need more openings in tier 2 cities, everything is in Bangalore or Gurgaon",
             "jobs nahi hai yaar, especially in {c}", "More genuine vacancies. Half the postings are fake or already filled",
             "Companies should hire locally instead of only metro cities", "Limited job oppurtunities outside big cities",
             "more jobs pls", "Government and private sector both need to create more entry level roles"],
    "guidance": ["No one gives proper career guidance after graduation, you are on your own", "koi proper guidance nahi milta college ke baad",
                 "Career counselling in colleges is very weak and outdated", "I wish someone could tell me which career path suits my profile",
                 "Better career guidance for people from non-engineering backgrounds", "Mentorship from industry people, not just motivational talks"],
    "skills": ["Colleges teach theory, companies want practical skills. Big mismatch", "Syllabus is outdated, industry wants AI and data skills now",
               "Skill mismatch between what we learn and what employers need", "Need training that matches actual job requirements",
               "Employers should clearly say which skills they want instead of vague JDs", "Practical skills like excel, analytics should be taught early"],
    "cost": ["Upskilling courses are too expensive for someone without a job", "Good certifications cost lakhs, not affordable for middle class",
             "Affordable training options with real placement support", "Courses are expensive and still dont guarantee a job"],
    "experience": ["Every entry level job asks for 2 years experiance, how will freshers get it?", "Internships should count as experience",
                   "Experience requirement for freshers is unfair", "Give freshers a chance, everyone asks for experience"],
    "interviews": ["I apply to 50+ jobs and get no calls back", "Applications go into a black hole, no response from HR",
                   "At least send rejection mails so we know where we stand", "Getting interview calls is the hardest part",
                   "ATS rejects resumes automatically, very frustrating", "Need feedback after interviews to improve"],
    "ai": ["An AI tool that tells me exactly which skills to learn for a role would be great", "AI based career guidance could really help people like me",
           "Personalised roadmap using AI, with real employer demand data", "AI job matching that actually works, not keyword spam",
           "If AI can assess my skills honestly and suggest jobs I'd use it daily"],
    "transparency": ["Salary transparency in job postings", "Transparent hiring process and timelines",
                     "Companies should publish salary ranges", "Fair and transparent selection, less reference based hiring"],
    "fraud": ["Too many fake job postings and scams asking for money", "Fraud placement agencies should be banned",
              "Verified employers only, I lost money to a fake consultancy"],
    "positive": ["Things are improving, more remote roles now", "The ecosystem is okay, just need better matching", "Happy with my current job but want to grow faster"],
    "neutral": ["Nothing specific", "Not sure", "No comments", "Overall ok", "Can't think of anything right now"],
}
THEME_LABEL = {"jobs": "Lack of jobs", "guidance": "Poor career guidance", "skills": "Skill mismatch", "cost": "Expensive training",
               "experience": "Lack of experience", "interviews": "Difficulty getting interviews", "ai": "Need for AI-powered career guidance",
               "transparency": "Hiring transparency", "fraud": "Fake jobs & fraud", "positive": "Positive outlook", "neutral": "No specific theme"}
SUFFIX = ["", "", "", ".", "!", " !!", "...", " please", " thanks", " 🙏", ""]
PREFIX = ["", "", "", "Honestly, ", "I think ", "IMO ", "Personally ", "Biggest issue - ", ""]


def make_text(i):
    w = {"jobs": .9 + 1.5 * (tier[i] == 2) + 1.0 * (q7[i] == 2), "guidance": 1 + 1.2 * (status[i] in (0, 1, 6)),
         "skills": 1 + 1.4 * (gap_cnt[i] >= 3) + 1.0 * (q7[i] == 0), "cost": .5 + .9 * (q22[i] == 0),
         "experience": .3 + 2.5 * (q7[i] == 1), "interviews": .4 + 2.5 * (q7[i] == 7) + .8 * (q8[i] >= 4),
         "ai": .3 + .9 * (q16[i] >= 4) + .9 * (q20[i] == 0), "transparency": .35 + .5 * (q7[i] == 6), "fraud": .25,
         "positive": .2 + .9 * (status[i] == 2) * (q10[i] >= 4), "neutral": .35}
    keys = list(w); p = np.array([w[k] for k in keys]); p = p / p.sum()
    k = keys[rng.choice(len(keys), p=p)]
    t = TEMPL[k][rng.integers(len(TEMPL[k]))].replace("{c}", CITY[city[i]] if city[i] < 11 else "small towns")
    k2 = None
    if k not in ("neutral",) and rng.random() < .22:
        k2 = keys[rng.choice(len(keys), p=p)]
        if k2 != k and k2 != "neutral":
            t2 = TEMPL[k2][rng.integers(len(TEMPL[k2]))].replace("{c}", "my city")
            t = t + (". Also " if rng.random() < .5 else " and ") + t2[0].lower() + t2[1:]
        else:
            k2 = None
    pre = PREFIX[rng.integers(len(PREFIX))]
    t = pre + (t[0].lower() + t[1:] if (pre or rng.random() < .3) else t)
    if rng.random() < .12: t = t.lower()
    if rng.random() < .03: t = t.upper()
    t = t + SUFFIX[rng.integers(len(SUFFIX))]
    return t, k, k2


texts, th1, th2 = [], [], []
for i in range(N):
    t, a, b = make_text(i); texts.append(t); th1.append(a); th2.append(b)
texts = np.array(texts, dtype=object)

# ---------------------------------------------------------------- metadata
start = np.datetime64("2026-09-01T08:00")
offs = rng.integers(0, 45 * 24 * 60, N)
ts = (start + offs.astype("timedelta64[m]")).astype(str)
duration = np.round(rng.lognormal(np.log(540), .38, N)).astype(int)
speeder = rng.random(N) < .015
duration[speeder] = rng.integers(70, 115, speeder.sum())
channel = pick([.34, .22, .18, .14, .12], N)
CHANNEL = ["Instagram ad", "College partner", "WhatsApp referral", "LinkedIn", "Job fair QR"]

# ---------------------------------------------------------------- assemble clean truth frame
ids = np.array([f"JS-{i:05d}" for i in range(1, N + 1)])
df = pd.DataFrame({
    "respondent_id": ids, "submitted_at": ts, "duration_sec": duration, "channel": [CHANNEL[c] for c in channel],
    "q1_age": age, "q2_edu": edu, "q3_city": city, "q4_status": status, "q5_exp": exp,
    "q6_difficulty": q6, "q7_challenge": q7, "q8_apps": q8, "q9_interviews": q9, "q10_confidence": q10,
    "q13_readiness": q13, "q14_gap": q14, "q15_learn": q15, "q16_ai_fam": q16, "q17_ai_use": q17, "q18_ai_trust": q18,
    "q20_intent": q20, "q21_feature": q21, "q22_wtp": q22, "q23_trust": q23, "q24_nps": q24,
    "exp_salary_k": sal,
}).astype({c: "float" for c in ["q1_age", "q2_edu", "q3_city", "q4_status", "q5_exp", "q6_difficulty", "q7_challenge",
                                  "q8_apps", "q9_interviews", "q10_confidence", "q13_readiness", "q14_gap", "q15_learn",
                                  "q16_ai_fam", "q17_ai_use", "q18_ai_trust", "q20_intent", "q21_feature", "q22_wtp",
                                  "q23_trust", "q24_nps"]})
city_other = np.array([""] * N, dtype=object)
oc = np.where(city == 11)[0]
oc_pick = rng.integers(0, len(OTHER_CITIES), len(oc))
city_other[oc] = [OTHER_CITIES[k][0] for k in oc_pick]
other_tier = np.zeros(N, int); other_tier[oc] = [OTHER_CITIES[k][1] for k in oc_pick]

# ---------------------------------------------------------------- controlled noise
# (a) "unusual but valid" combos injected on purpose
idx = rng.choice(np.where((edu == 4) & (q13 >= 4))[0], 60, replace=False); df.loc[idx, "q10_confidence"] = rng.choice([1, 2], 60)
idx = rng.choice(np.where((status == 1) & (q16 <= 3))[0], 55, replace=False); df.loc[idx, "q16_ai_fam"] = 5; df.loc[idx, "q17_ai_use"] = 0
idx = rng.choice(np.where((exp >= 4) & (q16 >= 3))[0], 60, replace=False); df.loc[idx, "q16_ai_fam"] = 1; df.loc[idx, "q17_ai_use"] = 3
idx = rng.choice(np.where(have.sum(1) >= 4)[0], 50, replace=False); df.loc[idx, "q13_readiness"] = rng.choice([1, 2], 50)

# (b) inconsistent responses (kept, flagged)
inc_ageexp = rng.choice(np.where(age == 0)[0], 22, replace=False); df.loc[inc_ageexp, "q5_exp"] = rng.choice([4, 5], 22)
inc_appint = rng.choice(np.where(df.q8_apps == 0)[0], 48, replace=False); df.loc[inc_appint, "q9_interviews"] = rng.choice([1, 2], 48)
inc_fresh = rng.choice(np.where(status == 1)[0], 14, replace=False); df.loc[inc_fresh, "q5_exp"] = rng.choice([4, 5], 14)

# (c) straight-liners: same value on all 1–5 scale questions
sl = rng.choice(N, 45, replace=False)
for i in sl:
    v = rng.choice([1, 3, 5]); df.loc[i, ["q6_difficulty", "q10_confidence", "q13_readiness", "q16_ai_fam", "q18_ai_trust"]] = v

# (e) missing values (2–5% of selected fields)
miss_rate = {"q2_edu": .021, "q5_exp": .028, "q8_apps": .024, "q9_interviews": .039, "q13_readiness": .022,
             "q15_learn": .026, "q16_ai_fam": .02, "q18_ai_trust": .031, "q22_wtp": .034, "q24_nps": .025,
             "q23_trust": .029, "exp_salary_k": .048}
miss_mask = {}
for c, r in miss_rate.items():
    m = rng.random(N) < r; miss_mask[c] = m; df.loc[m, c] = np.nan
skills_missing = rng.random(N) < .018  # whole multi-select left blank
text_blank = rng.random(N) < .041
texts[text_blank] = ""
junk = rng.choice(np.where(~text_blank)[0], 70, replace=False)
texts[junk] = rng.choice(["NA", "na", "-", ".", "nil", "nothing", "no"], 70)
th1 = np.array(th1, dtype=object); th1[text_blank] = None; th1[junk] = "neutral"

# (d) near-duplicate submissions: answers copied from an earlier record, new ID + timestamp
dup_src = rng.choice(N - 200, 9, replace=False); dup_dst = rng.choice(np.arange(N - 200, N), 9, replace=False)
qcols = [c for c in df.columns if c.startswith("q")] + ["exp_salary_k"]
for s, d in zip(dup_src, dup_dst):
    df.loc[d, qcols] = df.loc[s, qcols].values
    have[d] = have[s]; dem[d] = dem[s]; feat[d] = feat[s]; texts[d] = texts[s]; skills_missing[d] = skills_missing[s]; th1[d] = th1[s]; th2[d] = th2[s]
    for _c, _m in miss_mask.items(): _m[d] = _m[s]
    city_other[d] = city_other[s]; other_tier[d] = other_tier[s]
gap_cnt = (dem & ~have).sum(1)

# (f) invalid codes in raw capture -> become NA in cleaned
raw_over = []  # (row, column, raw value)
for c, bad in [("q6_difficulty", [0, 6, 9]), ("q10_confidence", [0, 6, 7]), ("q24_nps", [11, -1, 12, 99]), ("q13_readiness", [0, 6])]:
    rows = rng.choice(np.setdiff1d(np.where(df[c].notna())[0], dup_dst), int(N * .004), replace=False)
    for r in rows:
        raw_over.append((int(r), c, int(rng.choice(bad))))
invalid_rows = {}
for r, c, v in raw_over:
    invalid_rows.setdefault(r, []).append(c)

# (g) raw city label variants -> standardised in cleaned
VAR = {0: ["Gurgaon", "Noida", "New Delhi", "delhi", "Gurugram", "Delhi-NCR"], 1: ["Bombay", "Navi Mumbai", "mumbai", "Thane"],
       2: ["Bangalore", "bengaluru", "B'lore", "Bengaluru "], 3: ["Hyd", "hyderabad", "Secunderabad"], 4: ["pune", "Pune city"],
       5: ["Madras", "chennai"], 6: ["Calcutta", "kolkata"], 7: ["Ahmedabad (GJ)", "amdavad"], 8: ["jaipur"], 9: ["lucknow"], 10: ["chandigarh", "Mohali", "Panchkula"]}
raw_city = [CITY[int(c)] if c < 11 else (city_other[i] if rng.random() < .7 else "Other") for i, c in enumerate(df.q3_city.astype(int))]
city_var_rows = []
for i in range(N):
    c = int(df.q3_city[i])
    if c < 11 and rng.random() < .075:
        raw_city[i] = VAR[c][rng.integers(len(VAR[c]))]; city_var_rows.append(i)

# ---------------------------------------------------------------- quality flags (cleaned)
flags = {
    "flag_inconsistent_age_exp": ((df.q1_age == 0) & (df.q5_exp >= 4)) | ((df.q4_status == 1) & (df.q5_exp >= 4)),
    "flag_inconsistent_apps_interviews": (df.q8_apps == 0) & (df.q9_interviews >= 1),
    "flag_straightliner": df[["q6_difficulty", "q10_confidence", "q13_readiness", "q16_ai_fam", "q18_ai_trust"]].nunique(axis=1).eq(1)
                          & df[["q6_difficulty", "q10_confidence", "q13_readiness", "q16_ai_fam", "q18_ai_trust"]].notna().all(axis=1),
    "flag_speeder": df.duration_sec < 120,
}
dup_key = (df[qcols].fillna(-9).astype(str).agg("|".join, axis=1) + "|" + pd.Series(texts).astype(str)
           + "|" + pd.Series([have[i].tobytes().hex() + dem[i].tobytes().hex() + feat[i].tobytes().hex() for i in range(N)]))
flags["flag_possible_duplicate"] = dup_key.duplicated(keep="first")
flags = {k: np.asarray(v, bool) for k, v in flags.items()}
flags["flag_invalid_corrected"] = np.isin(np.arange(N), list(invalid_rows.keys()))

core_q = ["q1_age", "q2_edu", "q3_city", "q4_status", "q5_exp", "q6_difficulty", "q7_challenge", "q8_apps", "q9_interviews",
          "q10_confidence", "q13_readiness", "q14_gap", "q15_learn", "q16_ai_fam", "q17_ai_use", "q18_ai_trust", "q20_intent",
          "q21_feature", "q22_wtp", "q23_trust", "q24_nps"]
n_missing = df[core_q].isna().sum(1).values + skills_missing * 2 + (texts == "").astype(int)
inv_mask = np.zeros(N, bool); inv_mask[list(invalid_rows.keys())] = True
for r, c, v in raw_over:  # cleaned value of an invalid raw code = NA
    df.loc[r, c] = np.nan
n_missing = df[core_q].isna().sum(1).values + skills_missing * 2 + (texts == "").astype(int)
hard = flags["flag_inconsistent_age_exp"] | flags["flag_inconsistent_apps_interviews"] | flags["flag_straightliner"] | flags["flag_speeder"] | flags["flag_possible_duplicate"]
dq = np.where(hard, "Flagged", np.where((n_missing > 0) | inv_mask, "Usable – partial", "Complete"))

state = dict(SEED=SEED, N=N, df=df, have=have, dem=dem, feat=feat, skills_missing=skills_missing, texts=texts, th1=th1,
             th2=np.array(th2, dtype=object), raw_city=raw_city, city_other=city_other, other_tier=other_tier, raw_over=raw_over,
             city_var_rows=city_var_rows, flags=flags, dq=dq, n_missing=n_missing, THEME_LABEL=THEME_LABEL)
labels = dict(AGE=AGE, EDU=EDU, CITY=CITY, TIER=TIER, TIER_OF_CITY=TIER_OF_CITY, STATUS=STATUS, EXP=EXP, EXP_YRS=EXP_YRS,
              CHAL=CHAL, APPS=APPS, APPS_MID=APPS_MID, INTV=INTV, INTV_MID=INTV_MID, SKILLS=SKILLS, GAPQ=GAPQ, LEARN=LEARN,
              LEARN_MO=LEARN_MO, AIUSE=AIUSE, FEAT19=FEAT19, INTENT=INTENT, FEAT21=FEAT21, WTP=WTP, WTP_MID=WTP_MID,
              TRUST=TRUST, CHANNEL=CHANNEL)
state["labels"] = labels
pickle.dump(state, open("data/gen_state.pkl", "wb"))

# ---------------------------------------------------------------- write raw / cleaned csv
def lab(col, arr, L):
    return [("" if pd.isna(v) else L[int(v)]) for v in arr]

def multi(m, L, miss):
    return ["" if miss[i] else "; ".join(L[j] for j in np.where(m[i])[0]) for i in range(len(m))]

def build(clean=True):
    out = pd.DataFrame({"respondent_id": ids, "submitted_at": ts, "duration_sec": duration, "channel": df.channel})
    out["Q1_age_group"] = lab("", df.q1_age, AGE)
    out["Q2_education"] = lab("", df.q2_edu, EDU)
    out["Q3_city"] = lab("", df.q3_city, CITY) if clean else raw_city
    if clean:
        out["Q3_other_city_name"] = city_other
        out["city_tier"] = [TIER[TIER_OF_CITY[int(c)]] for c in df.q3_city]
    out["Q4_employment_status"] = lab("", df.q4_status, STATUS)
    out["Q5_experience"] = lab("", df.q5_exp, EXP)
    out["Q6_job_search_difficulty_1to5"] = df.q6_difficulty
    out["Q7_biggest_challenge"] = lab("", df.q7_challenge, CHAL)
    out["Q8_applications_3m"] = lab("", df.q8_apps, APPS)
    out["Q9_interviews"] = lab("", df.q9_interviews, INTV)
    out["Q10_confidence_1to5"] = df.q10_confidence
    out["Q11_skills_possessed"] = multi(have, SKILLS, skills_missing)
    out["Q12_skills_employers_demand"] = multi(dem, SKILLS, skills_missing)
    out["Q13_industry_readiness_1to5"] = df.q13_readiness
    out["Q14_skill_gap_experienced"] = lab("", df.q14_gap, GAPQ)
    out["Q15_learning_time"] = lab("", df.q15_learn, LEARN)
    out["Q16_ai_familiarity_1to5"] = df.q16_ai_fam
    out["Q17_ai_tool_usage"] = lab("", df.q17_ai_use, AIUSE)
    out["Q18_ai_trust_1to5"] = df.q18_ai_trust
    out["Q19_useful_ai_features"] = multi(feat, FEAT19, np.zeros(N, bool))
    out["Q20_would_use_platform"] = lab("", df.q20_intent, INTENT)
    out["Q21_most_valuable_feature"] = lab("", df.q21_feature, FEAT21)
    out["Q22_willingness_to_pay_monthly"] = lab("", df.q22_wtp, WTP)
    out["Q23_trust_driver"] = lab("", df.q23_trust, TRUST)
    out["Q24_likelihood_to_recommend_0to10"] = df.q24_nps
    out["Q25_biggest_improvement_open_text"] = texts
    out["derived_expected_salary_k_per_month"] = df.exp_salary_k
    if not clean:
        for r, c, v in raw_over:
            col = {"q6_difficulty": "Q6_job_search_difficulty_1to5", "q10_confidence": "Q10_confidence_1to5",
                   "q24_nps": "Q24_likelihood_to_recommend_0to10", "q13_readiness": "Q13_industry_readiness_1to5"}[c]
            out.loc[r, col] = v
    else:
        for k, v in flags.items(): out[k] = v
        out["missing_answer_count"] = n_missing
        out["data_quality"] = dq
    return out

raw = build(False); clean = build(True)
raw.to_csv("data/raw.csv", index=False); clean.to_csv("data/cleaned.csv", index=False)
print("raw", raw.shape, "clean", clean.shape, "unique ids", clean.respondent_id.nunique())
print(pd.Series(dq).value_counts())
print({k: int(v.sum()) for k, v in flags.items()})
print("invalid raw codes:", len(raw_over), "city variants:", len(city_var_rows))
